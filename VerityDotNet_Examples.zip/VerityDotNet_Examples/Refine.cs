﻿using System.Text;
using VerityDotNet;

namespace VerityDotNet_Examples {
	internal static class Refine {

		internal static void RefineFile() {
			string txt = "", curDir = "", dirDelim = "", delimChar = "", DQ="\"", delimDict="|";
			string fileName = "", fileUri = "", title = "";
			string fileOut = "", stats = "", hdr = "", fldName="";
			string? lineIn = ""; //nullable
			int nLine = 0, n1=-1, n2=-1, nTrans = -1, nKeys=0;
			bool isCaseSens = false;
			List<string> temp = new();
			List<string> fldVals = new();
			List<Field> outFields = new();
			List<Field> srcFields = new();
			List<string> srcRecs = new();
			List<string> remRecs = new();
			List<string> refineRecs = new();
			List<string> redactRecs = new();
			Dictionary<string, int> hashOutFields = new();
			Dictionary<string, string> settings = new();
			Lookup.LookUpDict lookUpDict = new();
			List<Lookup.LookUpDict> lookUps = new();
			Dictionary<string, int> hashLookups = new();
			List<Transform> transforms = new();
			QualityAnalysis report_asis = new();
			QualityAnalysis report_remediated = new();
			QualityAnalysis report_final = new();
			QualityAnalysis report_refine = new();
			QualityAnalysis report_redact = new();
			List<Dictionary<string, string>> coValues = new();
			StringBuilder sb;
			try {
				Console.WriteLine($"\n\nStarting Refine at {DateFuncs.GetCurrentISODateTime(true)}, version={Program.version}");

				// Set variables for file handling
				curDir = AppContext.BaseDirectory;
				dirDelim = curDir.Contains('\\') ? "\\" : "/";
				if (!curDir.EndsWith(dirDelim)) curDir += dirDelim;
				txt = dirDelim + "bin" + dirDelim; //remove bin part of path if there
				if (curDir.Contains(txt)) {
					curDir = curDir[..(curDir.IndexOf(txt) + 1)];
				}
				curDir += "data" + dirDelim;
				fileName = "IRSMigration_WithErrors_Hdr.csv";
				fileUri = curDir + fileName;
				if (!File.Exists(fileUri)) throw new ArgumentException($"file not found: {fileUri}");
				delimChar = ",";


				// read data file and make list of Field objects and source records							
				using (StreamReader sr = new StreamReader(fileUri)) {
					while (!sr.EndOfStream) {
						lineIn = sr.ReadLine();
						if (lineIn == null) break;
						//we could remove header from record array and then send setting hasHeader=false to Refiner method 
						//but we pass it along in this example
						if (lineIn.Length > 0 && !lineIn.StartsWith("//") && !lineIn.StartsWith('#')) {
							nLine++;
							srcRecs.Add(lineIn);
							if (nLine == 1) {
								if (!lineIn.Contains(delimChar)) throw new ArgumentException($"first line does not have field delimiter: {delimChar}");
								if (lineIn.Contains(DQ)) lineIn = lineIn.Replace(DQ, "");
								temp = lineIn.Split(delimChar).ToList<string>();
								for (int i = 0; i < temp.Count; i++) {
									srcFields.Add(new Field() {
										title = temp[i].Trim(),
									});
								}
							}
						}
					}
				}
				if (srcFields.Count == 0) throw new ArgumentException("no fields");
				if (srcRecs.Count == 0) throw new ArgumentException("no records");


				//add coValue. Each list entry is a dictionary for a new coValue
				//which has keys for 2 or 3 fields to use. AnalyzeQuality.Inspect 
				//method will check title and then assign list indices
				coValues.Add(new Dictionary<string, string>() {
					{"field1", "y1_state" },
					{"field2", "y1_state_name" },
					{"field3", "" },
				});


				//assign datatypes and formats
				for (int i = 0; i < srcFields.Count; i++) {
					fldName = srcFields[i].title.ToLowerInvariant();
					if (fldName == "y1_statefips" || fldName == "y2_statefips") {
						srcFields[i].datatype = "string";
						srcFields[i].fmt_strlen = 2;
						srcFields[i].parseErrorAction = "-missing-";
					}
					else if (fldName == "y1_state") {
						srcFields[i].datatype = "string";
						srcFields[i].fmt_strlen = 2;
						srcFields[i].fmt_strcase = "upper";
						srcFields[i].parseErrorAction = "-missing-";
					}
					else if (fldName == "y1_state_name") {
						srcFields[i].datatype = "string";
						srcFields[i].parseErrorAction = "-missing-";
					}
					else if (fldName == "n1") {
						srcFields[i].datatype = "int";
						srcFields[i].parseErrorAction = "-nv-";
					}
					else if (fldName == "n2") {
						srcFields[i].datatype = "int";
						srcFields[i].parseErrorAction = "-ignore-";
					}
					else if (fldName == "agi") {
						srcFields[i].datatype = "int";
						srcFields[i].parseErrorAction = "-999999";
					}
				}


				//----------------------------
				//ANALYZE AS-IS SOURCE DATA
				//----------------------------
				settings["hasHeader"] = "true"; //we left header line in array when read file
				settings["isQuoted"] = "true";
				settings["isCaseSens"] = "false";
				settings["delim"] = "comma";
				settings["maxuv"] = "100"; //override default limit
				settings["extractFields"] = "false"; //we have Fields from original file so do not want to auto-extract
				settings["useThreads"] = "false";

				//perform Verity Analysis. 
				report_asis = AnalyzeQuality.Inspect(srcFields, coValues, settings, srcRecs);
				if (report_asis.status.StartsWith("notok:")) throw new ArgumentException($"error doing AnalyzeQuality: {report_asis.status[6..]}");



				//------------------------------------------------------------------------
				//REMEDIATE: We have analysis of As-Is so now correct the parsing errors
				//------------------------------------------------------------------------

				//Set parameters
				settings["normalize"] = "true";
				settings["delimOut"] = "pipe"; //change output delimiter to allow embedded input delimiters
				settings["embedDelim"] = "_"; //if any output delimiters in values then replace with underscore
				settings["allowLastEmpty"] = "false"; //disallow Small1 parsing situation
				settings["joinChar"]= "+"; //inserted when joining lines to fix small2 parsing
				settings["ignoreEmpty"] = "true"; //do not use empty lines (after trim)
				settings["pinFields"] = ""; //do not set 'pinned' fields in this example
				settings["ignoreStartStr"] = "#|//"; //patterns that cause line to not be used. These are same as usual comment line prefixes

				remRecs = RemediateParsing.FixRecordFieldSplit(settings, srcFields, srcRecs);
				if (remRecs.Count == 0) throw new ArgumentException("no records from remediation process");
				else if (remRecs[0].StartsWith("notok:")) throw new ArgumentException(remRecs[0][6..]);
				else if (remRecs[0].StartsWith("ok:")) {
					stats = remRecs[0][3..];
					hdr = remRecs[1];
					remRecs.RemoveRange(0, 2); //remove stats and header
					Console.WriteLine($"Remediation stats: {stats}");
					Console.WriteLine($"Header from remediation={hdr}");
				}
				else throw new ArgumentException("Remediation response failed to start with ok:");

				//Write output records to file
				fileOut = curDir + "TestRefine_IRS_outrecs_remediated.dat";
				nLine = 0;
				using (StreamWriter sw = new StreamWriter(fileOut)) {
					sw.WriteLine(hdr); //we removed above
					foreach (string s in remRecs) {
						if (s.Length > 0) {
							sw.WriteLine(s);
							nLine++;
						}
					}
				}
				Console.WriteLine($"Verity output records REMEDIATED: {fileOut}");

				//perform Verity Analysis. Note sending new remediated record array. 
				settings["hasHeader"] = "false"; //we removed header line
				report_remediated = AnalyzeQuality.Inspect(srcFields, coValues, settings, remRecs);
				if (report_remediated.status.StartsWith("notok:")) throw new ArgumentException($"error doing AnalyzeQuality: {report_remediated.status[6..]}");


				//---------------------------------------------------------------------------------------
				//REFINE: We have both As-Is and Remediated results. Now Refine to normalize and enrich
				//---------------------------------------------------------------------------------------

				//Define output field datatypes and formats. Create output Fields 
				//with titles more indicative of their semantics and set mapping to original field name
				for (int i = 0; i < srcFields.Count; i++) {
					if (srcFields[i].title.Equals("y2_statefips", StringComparison.OrdinalIgnoreCase)) {
						outFields.Add(new Field() {
							title = "DestStateCode",
							mapto = srcFields[i].title.ToLowerInvariant(),
							datatype = "string",
							fmt_strlen = 2,
							fmt_strcut = "back",
							fmt_strpad = "front",
							fmt_strpadchar = "0",
						});
					}
					else if (srcFields[i].title.Equals("y1_statefips", StringComparison.OrdinalIgnoreCase)) {
						outFields.Add(new Field() {
							title = "OrigStateCode",
							mapto = srcFields[i].title.ToLowerInvariant(),
							datatype = "string",
							fmt_strlen = 2,
							fmt_strcut = "back",
							fmt_strpad = "front",
							fmt_strpadchar = "0",
						});
					}
					else if (srcFields[i].title.Equals("y1_state", StringComparison.OrdinalIgnoreCase)) {
						outFields.Add(new Field() {
							title = "OrigStateAbbr",
							mapto = srcFields[i].title.ToLowerInvariant(),
							datatype = "string",
							fmt_strlen = 2,
							fmt_strcase = "upper",
							fmt_strcut = "back",
							fmt_strpad = "front",
							fmt_strpadchar = "hyphen",
						});
					}
					else if (srcFields[i].title.Equals("y1_state_name", StringComparison.OrdinalIgnoreCase)) {
						outFields.Add(new Field() {
							title = "OrigStateName",
							mapto = srcFields[i].title.ToLowerInvariant(),
							datatype = "string",
						});
					}
					else if (srcFields[i].title.Equals("n1", StringComparison.OrdinalIgnoreCase)) {
						outFields.Add(new Field() {
							title = "NumReturn",
							mapto = srcFields[i].title.ToLowerInvariant(),
							datatype = "int",
						});
					}
					else if (srcFields[i].title.Equals("n2", StringComparison.OrdinalIgnoreCase)) {
						outFields.Add(new Field() {
							title = "NumExempt",
							mapto = srcFields[i].title.ToLowerInvariant(),
							datatype = "int",
						});
					}
					else if (srcFields[i].title.Equals("agi", StringComparison.OrdinalIgnoreCase)) {
						outFields.Add(new Field() {
							title = "GrossIncome",
							mapto = srcFields[i].title.ToLowerInvariant(),
							datatype = "real",
							fmt_decimal = 2,
						});
					}
					else {
						outFields.Add(new Field() {
							title = srcFields[i].title,
							mapto = srcFields[i].title.ToLowerInvariant(),
							datatype = "string",
						});
					}
					hashOutFields[outFields[i].title.ToLowerInvariant()] = i;
				}

				//Modify coValue with new names
				coValues.Clear();
				coValues.Add(new Dictionary<string, string>() {
					{"field1", "OrigStateAbbr" },
					{"field2", "OrigStateName" },
					{"field3", "" },
				});

				//-------------------------------------------------------------------------------------------
				// ADD ENRICHMENT FIELDS (not in source records but will be in output records)
				outFields.Add(new Field() {
					title = "useAGI", //indicator if record should be included in analytic aggregations
					datatype = "bool",
				});
				hashOutFields[outFields[^1].title.ToLowerInvariant()] = outFields.Count - 1;
				outFields.Add(new Field() {
					title = "DestStateAbbr",
					datatype = "string",
					fmt_strlen = 2,
					fmt_strcase = "upper"
				});
				hashOutFields[outFields[^1].title.ToLowerInvariant()] = outFields.Count - 1;
				outFields.Add(new Field() {
					title = "DestStateName",
					datatype = "string",
				});
				hashOutFields[outFields[^1].title.ToLowerInvariant()] = outFields.Count - 1;
				outFields.Add(new Field() {
					title = "isSubTotal", //indicator record is aggregated sum of filtered records
					datatype = "bool",
				});
				hashOutFields[outFields[^1].title.ToLowerInvariant()] = outFields.Count - 1;



				//-------------------------------------------------------------------------------------------
				// Make Lookup dictionaries for faster processing
				delimDict = "pipe";

				title = "StateAbbr";
				fileName = "StateAbbrfromFIPS_lookup.dat";
				nKeys = 1;
				isCaseSens = false;
				fileUri = curDir + fileName;
				lookUpDict = Lookup.MakeLookUpFromFile(title, fileUri, delimDict, isCaseSens, nKeys);
				if (lookUpDict.title.StartsWith("notok:")) throw new ArgumentException($"error making lookup {fileName}: {lookUpDict.title[6..]}");
				else if (lookUpDict.fields.Count == 0) throw new ArgumentException($"lookup does not have fields {fileName}");
				else if (lookUpDict.recs.Count == 0) throw new ArgumentException($"lookup does not have recs {fileName}");
				lookUps.Add(lookUpDict);
				hashLookups[lookUpDict.title.ToLowerInvariant()] = lookUps.Count - 1;

				title = "StateName";
				fileName = "StateNamefromFIPS_lookup.dat";
				nKeys = 1;
				isCaseSens = false;
				fileUri = curDir + fileName;
				lookUpDict = Lookup.MakeLookUpFromFile(title, fileUri, delimDict, isCaseSens, nKeys);
				if (lookUpDict.title.StartsWith("notok:")) throw new ArgumentException($"error making lookup {fileName}: {lookUpDict.title[6..]}");
				else if (lookUpDict.fields.Count == 0) throw new ArgumentException($"lookup does not have fields {fileName}");
				else if (lookUpDict.recs.Count == 0) throw new ArgumentException($"lookup does not have recs {fileName}");
				lookUps.Add(lookUpDict);
				hashLookups[lookUpDict.title.ToLowerInvariant()] = lookUps.Count - 1;

				
				
				//-------------------------------------------------------------------------------------------
				// DEFINE TRANSFORMS
				// Example: 1st transform sets field 'useAGI' based on source field AGI value since it has some 
				// coded values that should not be included in aggregations per source documentation. 
				// It checks the value of source field 'agi' and tests whether it equals -1. If it does, the final 
				// value is false since we do not want to use this record.
				transforms.Add(new Transform("useAGI")); //this transform is attached to enrichment field useAGI
				nTrans= transforms.Count-1;
				transforms[nTrans].ops.Add(new Transform.Op("setToRef"){ param1= "AGI"});
				transforms[nTrans].ops.Add(new Transform.Op("IfEq"){ param1= "-1"});
				//this is action for 'IfEq' False
				//useAGI = true meaning use AGI value since it does not have code -1
				transforms[nTrans].ops.Add(new Transform.Op("setToValue") { param1 = "true" }); 
				//this is action for 'IfEq' True
				//useAGI = false meaning dont use AGI value since it is code -1
				transforms[nTrans].ops.Add(new Transform.Op("setToValue"){ param1 = "false" }); 

				// transform is for output field 'GrossIncome' which is mapped to source field AGI
				transforms.Add(new Transform("GrossIncome")); 
				nTrans = transforms.Count - 1;
				transforms[nTrans].ops.Add(new Transform.Op("IfNotEq") { param1= "-1" });
				transforms[nTrans].ops.Add(new Transform.Op("NoOp")); //special Op to stop chain processing. This occurs when IfNotEq = false which means value = -1
				//mult automatically cleans number since default = true for param2
				//documentation states AGI is in thousands US Dollar so we convert to actual value by x 1000
				transforms[nTrans].ops.Add(new Transform.Op("mult"){ param1= "1000" }); 

				//this transform is attached to output field DestStateAbbr which is added enrichment field to use lookup dictionary to find destination details from source record FIPS code
				transforms.Add(new Transform("DestStateAbbr")); 
				nTrans = transforms.Count - 1;
				transforms[nTrans].ops.Add(new Transform.Op("setToRef"){ param1 = "y2_statefips" });
				//lookup dict use fixed 2 char long codes
				transforms[nTrans].ops.Add(new Transform.Op("setLength"){
					param1 = "2",
					param2 = "left",
					param3 = "0"
				});
				//short title we assigned to lookup dictionary file
				transforms[nTrans].ops.Add(new Transform.Op("lookup"){ param1 = "StateAbbr" }); 

				transforms.Add(new Transform("DestStateName")); //this transform is attached to output field DestStateName which is added enrichment field to use lookup dictionary to find destination details from source record FIPS code
				nTrans = transforms.Count - 1;
				transforms[nTrans].ops.Add(new Transform.Op("setToRef"){ param1 = "y2_statefips" });
				//lookup dict use fixed 2 char long codes
				transforms[nTrans].ops.Add(new Transform.Op("setLength") {
					param1 = "2",
					param2 = "left",
					param3 = "0"
				});
				//short title we assigned to lookup dictionary file
				transforms[nTrans].ops.Add(new Transform.Op("lookup") { param1 = "StateName" });

				transforms.Add(new Transform("isSubTotal"));
				nTrans = transforms.Count - 1;
				transforms[nTrans].ops.Add(new Transform.Op("setToRef"){ param1 = "y1_state_name" });
				transforms[nTrans].ops.Add(new Transform.Op("IfStrContains"){ param1 = "migra" });
				//this is action for If.. = False
				transforms[nTrans].ops.Add(new Transform.Op("setToValue"){ param1 = "false" });
				//this is action for If.. = True
				transforms[nTrans].ops.Add(new Transform.Op("setToValue"){ param1 = "true" }); 


				//-------------------------------------------------------------------------------------------
				// Generate Refined output
				settings["delim"] = "pipe"; //change since using output fields from remediation
				report_refine = RefineData.DoRefine(outFields, transforms, settings, lookUps, srcFields, remRecs, ref refineRecs);
				if (report_refine.status.StartsWith("notok:")) throw new ArgumentException($"Refine error: {report_refine.status[6..]}");
				else if (report_refine.status.StartsWith("ok:")) Console.WriteLine($"Refine done with {report_refine.status[3..]}");
				if (refineRecs.Count == 0) throw new ArgumentException("no output records");

				// perform Verity Analysis. Note sending new refined record array and output Fields.
				settings["hasHeader"] = "true"; //header line in refined array
				report_final = AnalyzeQuality.Inspect(outFields, coValues, settings, refineRecs);
				if (report_final.status.StartsWith("notok:")) throw new ArgumentException($"error doing AnalyzeQuality: {report_final.status[6..]}");


				//-------------------------------------------------------------------------------------------
				// Ensure output has correct field values.
				temp.Clear();
				if (refineRecs.Count != 1001) temp.Add($"incorrect #output lines {refineRecs.Count}/1001");
				fldVals = refineRecs[0].Split("|").ToList();
				if (fldVals.Count != 11) temp.Add($"incorrect #output fields in header {fldVals.Count}/11");
				else if (fldVals[0] != "DestStateCode") temp.Add($"incorrect output field[0] in header {fldVals[0]}/DestStateCode");
				else if (fldVals[2] != "OrigStateAbbr") temp.Add($"incorrect output field[2] in header {fldVals[2]}/OrigStateAbbr");
				else if (fldVals[6] != "GrossIncome") temp.Add($"incorrect output field[6] in header {fldVals[6]}/GrossIncome");
				else if (fldVals[7] != "useAGI") temp.Add($"incorrect output field[7] in header {fldVals[7]}/useAGI");
				else if (fldVals[9] != "DestStateName") temp.Add($"incorrect output field[9] in header {fldVals[9]}/DestStateName");
				else if (fldVals[10] != "isSubTotal") temp.Add($"incorrect output field[10] in header {fldVals[10]}/isSubTotal");

				fldVals = refineRecs[1].Split("|").ToList();
				if (fldVals.Count != 11) temp.Add($"incorrect #output fields outRecs[1] {fldVals.Count}/11");
				else if (fldVals[0] != "01") temp.Add($"incorrect output field[0] outRecs[1] {fldVals[0]}/01");
				else if (fldVals[1] != "96") temp.Add($"incorrect output field[1] outRecs[1] {fldVals[1]}/96");
				else if (fldVals[2] != "AL") temp.Add($"incorrect output field[2] outRecs[1] {fldVals[2]}/AL");
				else if (fldVals[6] != "1515297000.00") temp.Add($"incorrect output field[6] outRecs[1] {fldVals[6]}/1515297000.00");
				else if (fldVals[7] != "true") temp.Add($"incorrect output field[7] outRecs[1] {fldVals[7]}/true");
				else if (fldVals[9] != "Alabama") temp.Add($"incorrect output field[9] outRecs[1] {fldVals[9]}/Alabama");
				else if (fldVals[10] != "true") temp.Add($"incorrect output field[10] outRecs[1] {fldVals[10]}/true");

				if (temp.Count > 0) {
					Console.WriteLine("ERRORS!    -->  FAIL");
					for (int i = 0; i < temp.Count; i++) {
						Console.WriteLine($"{i}:{temp[i]}");
					}
				}
				else Console.WriteLine("no problems    -->  OK");

				Console.WriteLine($"Sample Refined Output: 10 records (joinChar={settings["joinChar"]})");
				for (int i = 0; i < 11; i++) {
					Console.WriteLine($"{i}:     {refineRecs[i]}");
				}


				//---------------------------------------------------------
				// Write output records
				//---------------------------------------------------------

				// refined
				fileOut = curDir + "TestRefine_IRS_outrecs_refined.dat";
				using (StreamWriter sw = new StreamWriter(fileOut)) {
					foreach (string s in refineRecs) {
						if (s.Length > 0) {
							sw.WriteLine(s);
						}
					}
				}
				Console.WriteLine($"Verity output records REFINED: {fileOut}");

				// Remove records we do not want to use marked by enrichment fields
				fileOut = curDir + "TestRefine_IRS_outrecs_redacted.dat";
				nLine = 0;
				n1 = hashOutFields["useagi"]; // field we use to filter
				n2 = hashOutFields["issubtotal"]; // field we use to filter
				using (StreamWriter sw = new StreamWriter(fileOut)) {
					for (int i= 0; i < refineRecs.Count; i++) {
						if (i==0) {
							redactRecs.Add(refineRecs[i]);
						}
						else {
							temp=  refineRecs[i].Split("|").ToList();
							if (temp[n1].Equals("true", StringComparison.OrdinalIgnoreCase) && !temp[n2].Equals("true", StringComparison.OrdinalIgnoreCase)) {
								redactRecs.Add(refineRecs[i]);
								sw.WriteLine(refineRecs[i]);								
							}
							else nLine++;
						}
					}
				}
				Console.WriteLine($"Verity output records REDACTED: {fileOut}, #out={redactRecs.Count}/{refineRecs.Count-1}, #removed={nLine}");


				//------------------------------------
				// Aanlyze Redacted data
				report_redact = AnalyzeQuality.Inspect(outFields, coValues, settings, redactRecs);
				if (report_redact.status.StartsWith("notok:")) throw new ArgumentException($"error doing AnalyzeQuality: {report_redact.status[6..]}");


				//------------------------------------
				//          Compare Results
				//------------------------------------
				Console.WriteLine("Sample Results Comparing Four Versions:");
				Console.WriteLine($"Number records: As-is={report_asis.numRecs}, Rem={report_remediated.numRecs}, Refine={report_final.numRecs}, Redact={report_redact.numRecs}");
				Console.WriteLine($"Number records errors: As-is= {report_asis.errStats["numrecserr"]}, Rem= {report_remediated.errStats["numrecserr"]}, Refine= {report_final.errStats["numrecserr"]}, Redact={report_redact.errStats["numrecserr"]}");
				Console.WriteLine($"Number records datatype errors: As-is= {report_asis.errStats["numrecserrdatatype"]}, Rem= {report_remediated.errStats["numrecserrdatatype"]}, Refine= {report_final.errStats["numrecserrdatatype"]}, Redact={report_redact.errStats["numrecserrdatatype"]}");
				Console.WriteLine($"Number records format errors: As-is= {report_asis.errStats["numrecserrfmt"]}, Rem= {report_remediated.errStats["numrecserrfmt"]}, Refine= {report_final.errStats["numrecserrfmt"]}, Redact={report_redact.errStats["numrecserrfmt"]}");
				Console.WriteLine($"Number parsing errors Small1: As-is= {report_asis.recParseErrs["small1"]}, Rem= {report_remediated.recParseErrs["small1"]}, Refine= {report_final.recParseErrs["small1"]}, Redact={report_redact.recParseErrs["small1"]}");
				Console.WriteLine($"Number parsing errors Small2: As-is= {report_asis.recParseErrs["small2"]}, Rem= {report_remediated.recParseErrs["small2"]}, Refine= {report_final.recParseErrs["small2"]}, Redact={report_redact.recParseErrs["small2"]}");
				Console.WriteLine($"Number parsing errors Big: As-is= {report_asis.recParseErrs["big"]}, Rem= {report_remediated.recParseErrs["big"]}, Refine= {report_final.recParseErrs["big"]}, Redact={report_redact.recParseErrs["big"]}");

				Console.WriteLine("\nFIELD QUALITY");
				for (int i = 0; i < report_asis.fields.Count; i++) {
					Console.WriteLine($"{report_asis.fields[i].title}: As-is={report_asis.fieldQuality[i]}, Rem={report_remediated.fieldQuality[i]}, Refine={report_final.fieldQuality[i]}, Redact={report_redact.fieldQuality[i]}");
				}
				Console.WriteLine("\nUNIQUE VALUES: Top 5 Per Field");
				sb=new StringBuilder();
				for (int i = 0; i < report_asis.fields.Count; i++) {
					Console.WriteLine($"Field {report_asis.fields[i].title}");
					for (int j = 0; j < 5; j++) {
						sb.Append("As-is:");
						if (j < report_asis.fieldUniqVals[i].Count) sb.Append($"{report_asis.fieldUniqVals[i][j].uv}={report_asis.fieldUniqVals[i][j].count}");
						else sb.Append("-no value-");
						sb.Append(", Rem:");
						if (j < report_remediated.fieldUniqVals[i].Count) sb.Append($"{report_remediated.fieldUniqVals[i][j].uv}={report_remediated.fieldUniqVals[i][j].count}");
						else sb.Append("-no value-");
						sb.Append(", Refine:");
						if (j < report_final.fieldUniqVals[i].Count) sb.Append($"{report_final.fieldUniqVals[i][j].uv}={report_final.fieldUniqVals[i][j].count}");
						else sb.Append("-no value-");
						sb.Append(", Redact:");
						if (j < report_redact.fieldUniqVals[i].Count) sb.Append($"{report_redact.fieldUniqVals[i][j].uv}={report_redact.fieldUniqVals[i][j].count}");
						else sb.Append("-no value-");
						Console.WriteLine(sb.ToString());
					}
				}
				Console.WriteLine("\nUNIQUE VALUES: Bottom 5 Per Field");
				for (int i = 0; i < report_asis.fields.Count; i++) {
					Console.WriteLine($"Field {report_asis.fields[i].title}");
					sb = new StringBuilder();
					for (int j = 0; j < 5; j++) {
						sb.Append("As-is:");
						n1 = report_asis.fieldUniqVals[i].Count - 1 - j;
						if (n1< report_asis.fieldUniqVals[i].Count) sb.Append($"{report_asis.fieldUniqVals[i][n1].uv}={report_asis.fieldUniqVals[i][n1].count}");
						else sb.Append("-no value-");
						sb.Append(", Rem:");
						n1 = report_remediated.fieldUniqVals[i].Count - 1 - j;
						if (n1 < report_remediated.fieldUniqVals[i].Count) sb.Append($"{report_remediated.fieldUniqVals[i][n1].uv}={report_remediated.fieldUniqVals[i][n1].count}");
						else sb.Append("-no value-");
						sb.Append(", Refine:");
						n1 = report_final.fieldUniqVals[i].Count - 1 - j;
						if (n1 < report_final.fieldUniqVals[i].Count) sb.Append($"{report_final.fieldUniqVals[i][n1].uv}={report_final.fieldUniqVals[i][n1].count}");
						else sb.Append("-no value-");
						sb.Append(", Redact:");
						n1 = report_redact.fieldUniqVals[i].Count - 1 - j;
						if (n1 < report_redact.fieldUniqVals[i].Count) sb.Append($"{report_redact.fieldUniqVals[i][n1].uv}={report_redact.fieldUniqVals[i][n1].count}");
						else sb.Append("-no value-");
						Console.WriteLine(sb.ToString());
					}
				}
				Console.WriteLine("\nSPECIAL CHARACTERS");
				sb=new StringBuilder();
				foreach (KeyValuePair<string, long> kv in report_asis.specCharDist) {
					sb.Append($"SpecChar {kv.Key}: As-is={kv.Value}, Rem=");
					sb.Append(report_remediated.specCharDist.ContainsKey(kv.Key) ? $"{report_remediated.specCharDist[kv.Key]}" : "0");
					sb.Append(", Refine=");
					sb.Append(report_final.specCharDist.ContainsKey(kv.Key) ? $"{report_final.specCharDist[kv.Key]}" : "0");
					sb.Append(", Redact=");
					sb.Append(report_redact.specCharDist.ContainsKey(kv.Key) ? $"{report_redact.specCharDist[kv.Key]}" : "0");
					Console.WriteLine(sb.ToString());
				}



				//---------------------------------------------------------
				// Write reports to file
				//---------------------------------------------------------
				fileOut = curDir + "TestRefine_IRS_report_asis.dat";
				nLine = 0;
				using (StreamWriter sw = new StreamWriter(fileOut)) {
					foreach (string s in report_asis.GetJSON(false)) {
						if (s.Length > 0) {
							sw.WriteLine(s);
							nLine++;
						}
					}
				}
				Console.WriteLine($"Verity report ASIS: {fileOut}");
				fileOut = curDir + "TestRefine_IRS_report_remediated.dat";
				nLine = 0;
				using (StreamWriter sw = new StreamWriter(fileOut)) {
					foreach (string s in report_remediated.GetJSON(false)) {
						if (s.Length > 0) {
							sw.WriteLine(s);
							nLine++;
						}
					}
				}
				Console.WriteLine($"Verity report REMEDIATED: {fileOut}");
				fileOut = curDir + "TestRefine_IRS_report_refine.dat";
				nLine = 0;
				using (StreamWriter sw = new StreamWriter(fileOut)) {
					foreach (string s in report_final.GetJSON(false)) {
						if (s.Length > 0) {
							sw.WriteLine(s);
							nLine++;
						}
					}
				}
				Console.WriteLine($"Verity report REFINE: {fileOut}");
				fileOut = curDir + "TestRefine_IRS_report_redact.dat";
				nLine = 0;
				using (StreamWriter sw = new StreamWriter(fileOut)) {
					foreach (string s in report_redact.GetJSON(false)) {
						if (s.Length > 0) {
							sw.WriteLine(s);
							nLine++;
						}
					}
				}
				Console.WriteLine($"Verity report REDACT: {fileOut}");
			}
			catch (ArgumentException ex) { Console.WriteLine("ArgumentException:" + ex.Message); }
			catch (Exception ex) { Console.WriteLine("Exception:" + ex.Message); }
		}


	}
}
