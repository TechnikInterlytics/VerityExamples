﻿

namespace VerityDotNet_Examples {

	public static class Program {

		public static readonly string version = "20241009_0830";

		static void Main() {
			try {
				Console.WriteLine($"STARTING VERITYDOTNET_EXAMPLES version={version}");
				Analyze.AnalyzeFile();
				Refine.RefineFile();
			}
			catch (Exception ex) { Console.WriteLine(ex.ToString()); }
		}

	}

}