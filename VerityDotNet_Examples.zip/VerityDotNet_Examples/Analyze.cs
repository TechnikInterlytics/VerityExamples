﻿using VerityDotNet;


namespace VerityDotNet_Examples {
	internal static class Analyze {


		internal static void AnalyzeFile() {
			string curDir = "", dirDelim = "", delimChar="", fileName = "", fileUri = "";
			string txt = "", DQ = "\"", fldName="";
			string? lineIn = "";
			int nLine = 0, n1=0;
			List<string> temp = new();
			List<string> errs = new();
			List<Field> srcFields = new();
			List<Dictionary<string, string>> coValues = new();
			List<string> recs = new();
			Dictionary<string, string> parameters = new();
			QualityAnalysis qualityAnalysis = new();
			try {
				Console.WriteLine($"Starting AnalyzeFile at {DateFuncs.GetCurrentISODateTime(true)}, version={Program.version}");

				// Set variables for file handling
				curDir = AppContext.BaseDirectory;
				dirDelim = curDir.Contains('\\') ? "\\" : "/";
				if (!curDir.EndsWith(dirDelim)) curDir += dirDelim;
				txt = dirDelim + "bin" + dirDelim; //remove bin part of path if there
				if (curDir.Contains(txt)) {
					curDir = curDir[..(curDir.IndexOf(txt) + 1)];
				}
				curDir += "data" + dirDelim;
				fileName = "IRSMigration_WithErrors_Hdr.csv";
				fileUri = curDir + fileName;
				if (!File.Exists(fileUri)) throw new Exception($"file not found: {fileUri}");
				delimChar = ",";
				//read data file and make list of Field objects and source records
				using (StreamReader sr = new(fileUri)) {
					while (!sr.EndOfStream) {
						lineIn = sr.ReadLine();
						if (lineIn == null) break;
						if (lineIn.Length > 0 && !lineIn.StartsWith("//") && !lineIn.StartsWith("#")) {
							nLine++;
							if (nLine == 1) {
								if (!lineIn.Contains(delimChar)) throw new Exception($"first line does not have field delimiter: {delimChar}");
								if (lineIn.Contains(DQ)) lineIn = lineIn.Replace(DQ, "");
								temp = lineIn.Split(delimChar).ToList<string>();
								for (int i = 0; i < temp.Count; i++) {
									txt = temp[i].Trim();
									srcFields.Add(new Field() {
										title = txt,
									});
									qualityAnalysis.hashFields[txt.ToLowerInvariant()] = srcFields.Count - 1;
								}
							}
							else {
								recs.Add(lineIn);
							}
						}
					}
				}

				//make sure we correctly read file
				if (srcFields.Count == 0) throw new Exception("no fields");
				if (recs.Count == 0) throw new Exception("no records");

				//add coValue. Each list entry is a dictionary for a new coValue
				//which has keys for 2 or 3 fields to use. AnalyzeQuality.Inspect 
				//method will check title and then assign list indices
				coValues.Add(new Dictionary<string, string>() {
					{"field1", "y1_state" },
					{"field2", "y1_state_name" },
					{"field3", "" },
				});

				//assign datatypes and formats
				for (int i = 0; i < srcFields.Count; i++) {
					fldName = srcFields[i].title.ToLowerInvariant();
					if (fldName == "y1_statefips" || fldName == "y2_statefips") {
						srcFields[i].datatype = "string";
						srcFields[i].fmt_strlen = 2;
					}
					else if (fldName == "y1_state") {
						srcFields[i].datatype = "string";
						srcFields[i].fmt_strlen = 2;
						srcFields[i].fmt_strcase = "upper";
					}
					else if (fldName == "y1_state_name") {
						srcFields[i].datatype = "string";
					}
					else if (fldName == "n1" || fldName == "n2" || fldName == "agi") {
						srcFields[i].datatype = "int";
					}
				}


				//--------------------------------------------
				//            TEST 1
				//--------------------------------------------

				//set parameters. 
				parameters["isCaseSens"] = "false";
				parameters["isQuoted"] = "true"; //allows possibility of some quoted field values
				parameters["delim"] = "comma"; // !!! critical to set correct delimiter !!!!
				parameters["maxuv"] = "100"; //override default limit
				parameters["hasHeader"] = "false"; //we removed header line as we read file but could have left it in if desired
				parameters["extractFields"] = "false"; //we have Fields from original file so do not want to auto-extract
				parameters["useThreads"] = "false"; //multi-threading is not used in this example

				//perform Verity Analysis. 
				qualityAnalysis = AnalyzeQuality.Inspect(srcFields, coValues, parameters, recs);
				if (qualityAnalysis.status.StartsWith("notok:")) throw new Exception($"error doing AnalyzeQuality: {qualityAnalysis.status[6..]}");

				n1 = 0;
				foreach (long l1 in qualityAnalysis.fieldsErrDatatypeCount) {
					if (l1 > 0) n1++;
				}
				if (n1 != 3) errs.Add($"incorrect fieldsErrDatatypeCount {n1}/3");
				n1 = 0;
				foreach (long l1 in qualityAnalysis.fieldsErrFmtCount) {
					if (l1 > 0) n1++;
				}
				if (n1 != 3) errs.Add($"incorrect fieldsErrFmtCount {n1}/3");

				if (qualityAnalysis.fieldDatatypeDist.Count != qualityAnalysis.fields.Count) errs.Add($"incorrect fieldDatatypeDist {qualityAnalysis.fieldDatatypeDist.Count}/{qualityAnalysis.fields.Count}");
				if (qualityAnalysis.fieldDatatypeDist[4]["int"] != 998) errs.Add($"incorrect fieldDatatypeDist[4][int] {qualityAnalysis.fieldDatatypeDist[4]["int"]}/998");
				if (qualityAnalysis.fieldDatatypeDist[4]["empty"] != 5) errs.Add($"incorrect fieldDatatypeDist[4][empty] {qualityAnalysis.fieldDatatypeDist[4]["empty"]}/5");

				if (qualityAnalysis.fieldUniqVals.Count != qualityAnalysis.fields.Count) errs.Add($"incorrect fieldUniqVals {qualityAnalysis.fieldUniqVals.Count}/{qualityAnalysis.fields.Count}");
				if (qualityAnalysis.fieldUniqVals[1].Count == 0) errs.Add($"incorrect #fieldUniqVals[1]=0");
				n1 = -1;
				for (int i = 0; i < qualityAnalysis.fieldUniqVals[1].Count; i++) {
					if (qualityAnalysis.fieldUniqVals[1][i].uv == "96") {
						n1 = i; break;
					}
				}
				if (n1 < 0) errs.Add($"fieldUniqVals[1] missing key=96");
				else if (qualityAnalysis.fieldUniqVals[1][n1].count != 18) errs.Add($"key=96 value wrong in fieldUniqVals[1][{n1}] {qualityAnalysis.fieldUniqVals[1][n1].count}/18");

				if (qualityAnalysis.specCharDist.Count != 4) errs.Add($"incorrect specCharDist {qualityAnalysis.specCharDist.Count}/4");
				if (!qualityAnalysis.specCharDist.ContainsKey("unicode_8252")) errs.Add($"missing key=unicode_8252 in specCharDist");
				if (qualityAnalysis.specCharDist["unicode_8252"] != 1) errs.Add($"incorrect key=unicode_8252 in specCharDist {qualityAnalysis.specCharDist["unicode_8252"]}/1");

				if (qualityAnalysis.coValues.Count != 1) errs.Add($"incorrect #coValues {qualityAnalysis.coValues.Count}/1");
				if (qualityAnalysis.coValueUniqVals.Count != 1) errs.Add($"incorrect #coValueUniqVals {qualityAnalysis.coValueUniqVals.Count}/1");
				n1 = -1;
				for (int i = 0; i < qualityAnalysis.coValueUniqVals[0].Count; i++) {
					if (qualityAnalysis.coValueUniqVals[0][i].uv == "nc_north carolina") {
						n1 = i; break;
					}
				}
				if (n1 < 0) errs.Add($"coValueUniqVals[0] missing key=nc_north carolina");
				else if (qualityAnalysis.coValueUniqVals[0][n1].count != 18) errs.Add($"coValueUniqVals[0][{n1}] for key=nc_north carolina wrong {qualityAnalysis.coValueUniqVals[0][n1].count}/18");

				if (qualityAnalysis.fieldQuality.Count != qualityAnalysis.fields.Count) errs.Add($"incorrect fieldQuality {qualityAnalysis.fieldQuality.Count}/{qualityAnalysis.fields.Count}");
				else if (qualityAnalysis.fieldQuality[0] != "95.2") errs.Add($"incorrect fieldQuality[0] {qualityAnalysis.fieldQuality[0]}/95.2");
				else if (qualityAnalysis.fieldQuality[4] != "98.7") errs.Add($"incorrect fieldQuality[4] {qualityAnalysis.fieldQuality[4]}/98.7");
				else if (qualityAnalysis.fieldQuality[5] != "97.8") errs.Add($"incorrect fieldQuality[6] {qualityAnalysis.fieldQuality[5]}/97.8");

				if (errs.Count > 0) {
					Console.WriteLine("Analyze has errors  ---> FAIL");
					for (int i = 0; i < errs.Count; i++) {
						Console.WriteLine($"Error {i}:{errs[i]}");
					}
				}
				else {
					Console.WriteLine("Analyze 0 errors  ---> OK");
				}

				Console.WriteLine("Sample Results:");
				Console.WriteLine($"Number records= {qualityAnalysis.numRecs}");
				Console.WriteLine($"Number records errors= {qualityAnalysis.errStats["numrecserr"]}");
				Console.WriteLine($"Number records datatype errors= {qualityAnalysis.errStats["numrecserrdatatype"]}");
				Console.WriteLine($"Number records format errors= {qualityAnalysis.errStats["numrecserrfmt"]}");
				Console.WriteLine($"Number parsing errors Small1= {qualityAnalysis.recParseErrs["small1"]}");
				Console.WriteLine($"Number parsing errors Small2= {qualityAnalysis.recParseErrs["small2"]}");
				Console.WriteLine($"Number parsing errors Big= {qualityAnalysis.recParseErrs["big"]}");
				for (int i = 0; i < qualityAnalysis.fields.Count; i++) {
					Console.WriteLine($"Field Quality {qualityAnalysis.fields[i].title}={qualityAnalysis.fieldQuality[i]} ");
				}
				Console.WriteLine("UNIQUE VALUES: Top 5 Per Field");
				for (int i = 0; i < qualityAnalysis.fields.Count; i++) {
					Console.WriteLine($"Field {qualityAnalysis.fields[i].title}");
					for (int j = 0; j < 5; j++) {
						if (j >= qualityAnalysis.fieldUniqVals[i].Count) break;
						Console.WriteLine($"UV: {qualityAnalysis.fieldUniqVals[i][j].uv} has {qualityAnalysis.fieldUniqVals[i][j].count} instances");
					}
				}
				Console.WriteLine("UNIQUE VALUES: Bottom 5 Per Field");
				for (int i = 0; i < qualityAnalysis.fields.Count; i++) {
					Console.WriteLine($"Field {qualityAnalysis.fields[i].title}");
					for (int j = 0; j < 5; j++) {
						n1 = qualityAnalysis.fieldUniqVals[i].Count - 1 - j;
						if (n1 < 0) break;
						Console.WriteLine($"UV: {qualityAnalysis.fieldUniqVals[i][n1].uv} has {qualityAnalysis.fieldUniqVals[i][n1].count} instances");
					}
				}
				Console.WriteLine("SPECIAL CHARACTERS");
				foreach (KeyValuePair<string, long> kv in qualityAnalysis.specCharDist) {
					Console.WriteLine($"SpecChar {kv.Key} has {kv.Value} instances");
				}
				Console.WriteLine($"CoValues (20 values max): {qualityAnalysis.coValues[0].title}");
				n1 = 0;
				foreach ((string uv, long count) in qualityAnalysis.coValueUniqVals[0]) {
					Console.WriteLine($"{uv}: {count} instances");
					n1++;
					if (n1 >= 20) break;
				}



				//--------------------------------------------
				// TEST 2  Multi-Threading with Trial License
				//--------------------------------------------
				Console.WriteLine("\n\nTest 2: Multi-thread with TRIAL license");
				//add parameters
				parameters["license"] = "VerityTrial";
				parameters["licenseid"] = "";
				parameters["maxThreads"] = "5"; //will be ignored due to trial license
				parameters["nRecsPerThreadMin"] = "500"; //will be ignored due to trial license
				parameters["nRecsPerThreadMax"] = "10000"; //will be ignored due to trial license
				parameters["useThreads"] = "true"; //multi-threading is used

				errs.Clear();
				//perform Verity Analysis. We do not use coValues in this example so send an empty container
				qualityAnalysis = AnalyzeQuality.Inspect(srcFields, new List<Dictionary<string, string>>(), parameters, recs);
				if (qualityAnalysis.status.StartsWith("notok:")) throw new Exception($"error doing AnalyzeQuality: {qualityAnalysis.status[6..]}");
				else if (!qualityAnalysis.status.StartsWith("license trial:")) throw new Exception($"error doing AnalyzeQuality report status does not start with license trial: {qualityAnalysis.status}");
				else Console.WriteLine($"AnalyzeQuality with threads trial license status: {qualityAnalysis.status}");

				n1 = 0;
				foreach (long l1 in qualityAnalysis.fieldsErrDatatypeCount) {
					if (l1 > 0) n1++;
				}
				if (n1 != 3) errs.Add($"incorrect fieldsErrDatatypeCount {n1}/3");
				n1 = 0;
				foreach (long l1 in qualityAnalysis.fieldsErrFmtCount) {
					if (l1 > 0) n1++;
				}
				if (n1 != 3) errs.Add($"incorrect fieldsErrFmtCount {n1}/3");

				if (qualityAnalysis.fieldDatatypeDist.Count != qualityAnalysis.fields.Count) errs.Add($"incorrect fieldDatatypeDist {qualityAnalysis.fieldDatatypeDist.Count}/{qualityAnalysis.fields.Count}");
				if (qualityAnalysis.fieldDatatypeDist[4]["int"] != 998) errs.Add($"incorrect fieldDatatypeDist[4][int] {qualityAnalysis.fieldDatatypeDist[4]["int"]}/998");
				if (qualityAnalysis.fieldDatatypeDist[4]["empty"] != 5) errs.Add($"incorrect fieldDatatypeDist[4][empty] {qualityAnalysis.fieldDatatypeDist[4]["empty"]}/5");

				if (qualityAnalysis.fieldUniqVals.Count != qualityAnalysis.fields.Count) errs.Add($"incorrect fieldUniqVals {qualityAnalysis.fieldUniqVals.Count}/{qualityAnalysis.fields.Count}");
				if (qualityAnalysis.fieldUniqVals[1].Count == 0) errs.Add($"incorrect #fieldUniqVals[1]=0");
				n1 = -1;
				for (int i = 0; i < qualityAnalysis.fieldUniqVals[1].Count; i++) {
					if (qualityAnalysis.fieldUniqVals[1][i].uv == "96") {
						n1 = i; break;
					}
				}
				if (n1 < 0) errs.Add($"fieldUniqVals[1] missing key=96");
				else if (qualityAnalysis.fieldUniqVals[1][n1].count != 18) errs.Add($"key=96 value wrong in fieldUniqVals[1][{n1}] {qualityAnalysis.fieldUniqVals[1][n1].count}/18");

				if (qualityAnalysis.specCharDist.Count != 4) errs.Add($"incorrect specCharDist {qualityAnalysis.specCharDist.Count}/4");
				if (!qualityAnalysis.specCharDist.ContainsKey("unicode_8252")) errs.Add($"missing key=unicode_8252 in specCharDist");
				if (qualityAnalysis.specCharDist["unicode_8252"] != 1) errs.Add($"incorrect key=unicode_8252 in specCharDist {qualityAnalysis.specCharDist["unicode_8252"]}/1");

				if (errs.Count > 0) {
					Console.WriteLine("Analyze with threads TRIAL license has errors  ---> FAIL");
					for (int i = 0; i < errs.Count; i++) {
						Console.WriteLine($"Error {i}:{errs[i]}");
					}
				}
				else {
					Console.WriteLine("Analyze with threads TRIAL license 0 errors  ---> OK");
				}

			}
			catch (ArgumentException ex) { Console.WriteLine("ArgumentException:" + ex.Message); }
			catch (Exception ex) { Console.WriteLine("Exception:" + ex.Message); }
		}


	}
}
