#!usr/bin/env python

"""Example using VerityPy to analyze data set
"""

from VerityPy.processing import datefuncs, qualityanalysis, analyzequality, field, numfuncs, remediateparsing, refinedata
from VerityPy.transforms import lookup, transform
from VerityPy.utils import reportfuncs

DQ:str="\""
LF:str="\n"


def runtest()->None:
    """Runtest performs example remediation, normalization, enrichment on sample data
    """

    delim:str=","
    title:str=""
    txt:str=""
    txt1:str=""
    stats:str=""
    dtype:str=""
    mapto:str=""
    strcase:str=""
    strcut:str=""
    strpad:str=""
    strpadchar:str=""
    fmtdate:str=""
    curdir:str=""
    file_uri:str=""
    file_name:str=""
    nkeys:int=0
    strlen:int=-1
    numdec:int=-1
    ntrans:int=-1
    nline:int=-1
    nflds_def:int=-1
    flds_hdr:list=[]
    rec_parse:list=[]
    flds:list=[]
    outfields:list=[]
    recs:list=[]
    recs_remediated:list=[]
    covalues:list=[]
    settings:dict={}
    temp:list=[]
    report_asis:qualityanalysis.QualityAnalysis= qualityanalysis.QualityAnalysis()
    report_remediated:qualityanalysis.QualityAnalysis= qualityanalysis.QualityAnalysis()
    report_refined:qualityanalysis.QualityAnalysis= qualityanalysis.QualityAnalysis()
    outrecs:list=[]
    hash_outfields:dict={}
    settings:dict={}
    lookup_dict:lookup.LookUpDict
    lookups:list=[]
    hash_lookups:dict={}
    transforms:list=[]
    report_uris:list=[]
    data_uris:list=[]
    try:
        print("Starting runtest at " + datefuncs.get_current_iso_datetime(True))
        file_name="IRSMigration_WithErrors_Hdr.csv"
        curdir="files\\"
        
        # -----------------------  AS IS: Evaluate source data -----------------------------        
        # read in sample data records and make fields from header line
        file_uri= curdir + file_name
        data_uris.append(file_uri)
        with open(file_uri,"r",encoding="utf-8") as f:
            nline=0
            for line in f:
                if line is None:
                    break
                if line.endswith("\r\n"):
                    line=line[:-2]
                if line.endswith("\r") or line.endswith("\n"):
                    line=line[:-1]
                if len(line)>0 and not line.startswith("#") and not line.startswith("//"):
                    # we ignore empty and comment lines
                    nline += 1
                    if nline==1:
                        # 1st line is header of delimited field names
                        if line.find(DQ)>-1:
                            line=line.replace(DQ,'')
                        temp= line.split(delim)
                        for s in temp:
                            # create list of Field objects
                            flds.append(field.Field(s.strip()))
                    else:
                        # make list of data records after we handled header
                        recs.append(line)

        nflds_def=len(flds)
        # add detail to the Field objects using information from documentation: assign datatypes and formats
        for i in range(nflds_def):
            title= flds[i].title.lower()
            if title in ["y2_statefips","y1_statefips"]:
                flds[i].datatype="string"
                flds[i].fmt_strlen=2 # this specifies that the value should be 2 characters
            elif title=="y1_state":
                flds[i].datatype="string"
                flds[i].fmt_strcase="upper" # this specifies that the value should be uppercase
                flds[i].fmt_strlen=2
            elif title=="y1_state_name":
                flds[i].datatype="string"
            elif title in ["n1","n2"]:
                flds[i].datatype="int"
            elif title=="agi":
                flds[i].datatype="real"
                flds[i].fmt_decimal=0

        covalues.append("y1_state,y1_state_name")

        settings['is_case_sens']="false"
        settings['is_quoted']="true"
        settings['has_header']="false"
        settings['extract_fields']="false"
        settings['delim']="comma"
        settings['maxuv']="100"

        report_asis =analyzequality.do_qualityinspect(flds, covalues, recs, settings)
        if report_asis.status.startswith("notok:"):
            raise ValueError("error from as-is report:" + report_asis.status[6:])
        file_uri= curdir + file_name.replace(".csv","_report.dat")
        report_uris.append(file_uri)
        txt= reportfuncs.save_report_to_file(file_uri, report_asis)
        if txt.startswith("notok:"):
            raise ValueError("error from saving as-is report:" + txt[6:])
        # ------------------    as-is  report saved for later use -------------------------



        # -----------------------  REMEDIATE: Fix parsing errors in source data -----------------------------        
        # use source data records
        stats=""  # will be delimited string of various stats from remediation function
        flds_hdr=[] # will be list of field titles as detected in remediation function
        recs_remediated= remediateparsing.fix_record_field_split(settings, flds, recs)
        if len(recs_remediated)<2:
            raise ValueError("error remediating since did not return stats nor fields")
        elif recs_remediated[0].startswith("notok:"):
            raise ValueError("error remediating:" + recs_remediated[0][6:])
        elif not recs_remediated[0].startswith("ok:"):
            raise ValueError("error remediating since response missing required prefix ok:")
        
        stats= recs_remediated[0][3:]
        flds_hdr= recs_remediated[1].split(",")
        recs_remediated.pop(0)        
        recs_remediated.pop(0)
        
        print(f"Remediated stats: {stats}")
        print(f"Remediated fields: {','.join(flds_hdr)}")

        report_remediated= analyzequality.do_qualityinspect(flds, covalues, recs_remediated, settings)
        if report_remediated.status.startswith("notok:"):
            raise ValueError("error from remediated report:" + report_remediated.status[6:])

        print(f"\nNumber records: as-is={len(recs)}, remediated={len(recs_remediated)}");
        print(f"Parsing errors: as-is: small1={report_asis.rec_parse_errs['small1']}, small2={report_asis.rec_parse_errs['small2']}, big={report_asis.rec_parse_errs['big']}")
        print(f"Parsing errors: remediated: small1={report_remediated.rec_parse_errs['small1']}, small2={report_remediated.rec_parse_errs['small2']}, big={report_remediated.rec_parse_errs['big']}")
        print(f"Number records with errors: as-is={report_asis.err_stats['numrecs_err']}, remediated={report_remediated.err_stats['numrecs_err']}")
        print(f"Number records with datatype errors: as-is={report_asis.err_stats['numrecs_err_datatype']}, remediated={report_remediated.err_stats['numrecs_err_datatype']}")
        print(f"Number records with format errors: as-is={report_asis.err_stats['numrecs_err_fmt']}, remediated={report_remediated.err_stats['numrecs_err_fmt']}")
        print(f"\nAs-is fields with datatype errors: {len(report_asis.err_stats['fields_err_datatype'])}")
        temp=sorted(report_asis.err_stats['fields_err_datatype'])
        for s in temp:
            print(f"  field: {s}, count={report_asis.err_stats['fields_err_datatype'][s]['count']}")
            for r in report_asis.err_stats['fields_err_datatype'][s]['reasons']:
                print(f"      reason={r}, count={report_asis.err_stats['fields_err_datatype'][s]['reasons'][r]}")

        print(f"\nRemediated fields with datatype errors: {len(report_remediated.err_stats['fields_err_datatype'])}")
        temp=sorted(report_remediated.err_stats['fields_err_datatype'])
        for s in temp:
            print(f"  field: {s}, count={report_remediated.err_stats['fields_err_datatype'][s]['count']}")
            for r in report_remediated.err_stats['fields_err_datatype'][s]['reasons']:
                print(f"      reason={r}, count={report_remediated.err_stats['fields_err_datatype'][s]['reasons'][r]}")

        rec_parse=[]
        print("\nRecord Parsing Problems: Small2")
        for i in range(len(report_asis.rec_parse_errs['small2_recs'])):
            txt=report_asis.rec_parse_errs['small2_recs'][i]
            if txt.startswith("("):
                txt1=txt[1:txt.find(")")]
                if numfuncs.is_int(txt1):
                    rec_parse.append(int(txt1))
        if len(rec_parse)>0:
            rec_parse.sort()
            for i in rec_parse:
                # ensure proper indexing per record number (1 based) and array (0-based) by subtracting 1
                print(f"\nasis record {i}: {recs[i-1]}")
                print(f"remediated record {i}: {recs_remediated[i-1]}")
        
        file_uri= curdir + file_name.replace(".csv","_remediated_report.dat")
        report_uris.append(file_uri)
        txt= reportfuncs.save_report_to_file(file_uri, report_remediated)
        if txt.startswith("notok:"):
            raise ValueError("error from saving remediated report:" + txt[6:])
        
        file_uri= curdir + file_name.replace(".csv","_remediated_data.dat")
        data_uris.append(file_uri)
        with open(file_uri,"w", encoding="utf-8") as f:
            f.write(','.join(flds_hdr) + LF)
            for i in range(len(recs_remediated)):
                f.write(recs_remediated[i] + LF)
        # ------------------    remediation report saved for later use -------------------------



        # -----------------------  NORMALIZE & ENRICH: Generate refined data set -----------------------------        
        # use remediated data records
        # use results to adjust specifications and create output fields that include enrichment
        for i in range(len(flds)):
            txt=flds[i].title.lower()
            dtype=""
            if txt.endswith("fips") or txt.startswith("y1_state"):
                dtype="string"
            elif txt in ["n1","n2"]:
                dtype="int"
            elif txt=="agi":
                dtype="real"
            mapto=txt
            strcase=""
            strcut=""
            strpad=""
            strpadchar=""
            strlen=-1
            fmtdate=""
            numdec=-1
            if txt=="y2_statefips":
                title="DestStateCode"
                strlen=2
                strcut="back"
                strpad="front"
                strpadchar="0"
            elif txt=="y1_statefips":
                title="OrigStateCode"
                strlen=2
                strcut="back"
                strpad="front"
                strpadchar="0"
            elif txt=="y1_state":
                title="OrigStateAbbr"
                strlen=2
                strcase="upper"
                strcut="back"
                strpad="front"
                strpadchar="hyphen"
            elif txt=="y1_state_name":
                title="OrigStateName"
            elif txt=="n1":
                title="NumReturn"
            elif txt=="n2":
                title="NumExempt"
            elif txt=="agi":
                title="GrossIncome"
                numdec=2
            else:
                title=flds[i].title

            outfields.append(field.Field(title))
            nfld= len(outfields)-1
            outfields[nfld].mapto=mapto
            outfields[nfld].datatype=dtype
            outfields[nfld].fmt_strlen=strlen
            outfields[nfld].fmt_strcase=strcase
            outfields[nfld].fmt_strcut=strcut
            outfields[nfld].fmt_strpad=strpad
            outfields[nfld].fmt_strpadchar=strpadchar
            outfields[nfld].fmt_date=fmtdate
            outfields[nfld].fmt_decimal=numdec
            hash_outfields[title.lower()]=nfld

        # ADD ENRICHMENT FIELDS (not in source records but will be in output records)
        outfields.append(field.Field("useAGI"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "bool"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        outfields.append(field.Field("DestStateAbbr"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "string"
        outfields[nfld].fmt_strlen= 2
        outfields[nfld].fmt_strcase= "upper"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        outfields.append(field.Field("DestStateName"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "string"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        outfields.append(field.Field("isSubTotal"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "bool"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        #make lookup dictionaries
        title = "StateAbbr"
        nkeys=1
        iscasesens=False
        file_uri= curdir + "StateAbbrfromFIPS_lookup.dat"
        lookup_dict= lookup.LookUpDict()
        lookup_dict= lookup.make_lookup_from_file(title, file_uri, "pipe", iscasesens, nkeys)
        if lookup_dict.title.startswith("notok:"):
            raise ValueError("error making LookUpDict " + title + ": " + lookup_dict.title[6:])
        elif len(lookup_dict.fields)==0:
            raise ValueError("error making LookUpDict since missing fields " + title)
        elif len(lookup_dict.recs)==0:
            raise ValueError("error making LookUpDict since missing recs " + title)
        lookups.append(lookup_dict)
        hash_lookups[lookup_dict.title.lower()]= len(lookups)-1

        title = "StateName"
        nkeys=1
        iscasesens=False
        file_uri= curdir + "StateNamefromFIPS_lookup.dat"
        lookup_dict= lookup.LookUpDict()
        lookup_dict= lookup.make_lookup_from_file(title, file_uri, "pipe", iscasesens, nkeys)
        if lookup_dict.title.startswith("notok:"):
            raise ValueError("error making LookUpDict " + title + ": " + lookup_dict.title[6:])
        elif len(lookup_dict.fields)==0:
            raise ValueError("error making LookUpDict since missing fields " + title)
        elif len(lookup_dict.recs)==0:
            raise ValueError("error making LookUpDict since missing recs " + title)
        lookups.append(lookup_dict)
        hash_lookups[lookup_dict.title.lower()]= len(lookups)-1

        # Define Transforms
        # 1st transform sets useAGI based on source field AGI value since it has some
        # coded values that shoud not be included in aggregations per source documentation
        ntrans=0
        transforms=[]
        transforms.append(transform.Transform("useAGI"))
        transforms[ntrans].ops.append(transform.Op("setToRef", "AGI"))
        transforms[ntrans].ops.append(transform.Op("IfEq", "-1"))
        transforms[ntrans].ops.append(transform.Op("setToValue","true")) # action for False condition
        transforms[ntrans].ops.append(transform.Op("setToValue","false")) # action for True condition, useAGI = false meaning dont use AGI value since it is code -1

        ntrans +=1
        transforms.append(transform.Transform("GrossIncome"))
        transforms[ntrans].ops.append(transform.Op("IfNotEq","-1")) # has coded values we need to handle for useful analytic output records
        transforms[ntrans].ops.append(transform.Op("NoOp")) # do nothing if -1 (since False for IfNotEq)
        transforms[ntrans].ops.append(transform.Op("mult","1000"))  # normalize to true $ unit since in thousands

        ntrans +=1
        transforms.append(transform.Transform("DestStateAbbr"))
        transforms[ntrans].ops.append(transform.Op("setToRef","y2_statefips"))
        transforms[ntrans].ops.append(transform.Op("setLength","2","left","0")) # lookup dict use fixed 2 char long codes
        transforms[ntrans].ops.append(transform.Op("lookup","StateAbbr")) # short title we assigned to lookup dictionary file

        ntrans +=1
        transforms.append(transform.Transform("DestStateName"))
        transforms[ntrans].ops.append(transform.Op("setToRef","y2_statefips"))
        transforms[ntrans].ops.append(transform.Op("setLength","2","left","0")) # lookup dict use fixed 2 char long codes
        transforms[ntrans].ops.append(transform.Op("lookup","StateName"))

        ntrans +=1
        transforms.append(transform.Transform("isSubTotal"))
        transforms[ntrans].ops.append(transform.Op("setToRef","y1_state_name"))
        transforms[ntrans].ops.append(transform.Op("IfStrContains","migra"))
        transforms[ntrans].ops.append(transform.Op("setToValue","false"))
        transforms[ntrans].ops.append(transform.Op("setToValue","true"))

        # Process Source Records: pass settings to Refine module
        settings["has_header"]="false"
        settings["is_quoted"]="true"
        settings["normalize"]="true"
        settings["use_comment"]="false"
        settings["delim"]="comma"
        settings["delim_out"]="pipe"
        settings["embed_delim"]="_"

        outrecs= refinedata.do_refine(outfields, transforms, settings, lookups, flds, recs_remediated)
        if len(outrecs)==0:
            raise ValueError("Refine error: no output records")
        elif outrecs[0].startswith("notok:"):
            raise ValueError("Refine error: " + outrecs[0][6:])

        print("\n\n*****************************   Sample refined Data Records After Transforms, Enrich, Normalize *****************************")
        print(outrecs[0])
        for i in range(1,21):
            print(f"{i}: {outrecs[i]}")

        # remove header
        flds_hdr= outrecs[0].split("|")
        outrecs.pop(0)

        settings['is_case_sens']="false"
        settings['is_quoted']="true"
        settings['has_header']="false"
        settings['extract_fields']="false"
        settings['delim']="pipe"
        settings['maxuv']="100"
        covalues=[]
        covalues.append("OrigStateCode,OrigStateAbbr")
        covalues.append("DestStateCode,DestStateAbbr")

        report_refined= analyzequality.do_qualityinspect(outfields, covalues, outrecs, settings)
        if report_refined.status.startswith("notok:"):
            raise ValueError("error from refined report:" + report_refined.status[6:])

        print(f"\nNumber records: as-is={len(recs)}, remediated={len(recs_remediated)}, refined={len(outrecs)}");
        print(f"Parsing errors: as-is: small1={report_asis.rec_parse_errs['small1']}, small2={report_asis.rec_parse_errs['small2']}, big={report_asis.rec_parse_errs['big']}")
        print(f"Parsing errors: remediated: small1={report_remediated.rec_parse_errs['small1']}, small2={report_remediated.rec_parse_errs['small2']}, big={report_remediated.rec_parse_errs['big']}")
        print(f"Parsing errors: refined: small1={report_refined.rec_parse_errs['small1']}, small2={report_refined.rec_parse_errs['small2']}, big={report_refined.rec_parse_errs['big']}")

        print(f"Number records with errors: as-is={report_asis.err_stats['numrecs_err']}, remediated={report_remediated.err_stats['numrecs_err']}, refined={report_refined.err_stats['numrecs_err']}")
        print(f"Number records with datatype errors: as-is={report_asis.err_stats['numrecs_err_datatype']}, remediated={report_remediated.err_stats['numrecs_err_datatype']}, refined={report_refined.err_stats['numrecs_err_datatype']}")
        print(f"Number records with format errors: as-is={report_asis.err_stats['numrecs_err_fmt']}, remediated={report_remediated.err_stats['numrecs_err_fmt']}, refined={report_refined.err_stats['numrecs_err_fmt']}")

        print(f"\nAs-is fields with datatype errors: {len(report_asis.err_stats['fields_err_datatype'])}")
        temp=sorted(report_asis.err_stats['fields_err_datatype'])
        for s in temp:
            print(f"  field: {s}, count={report_asis.err_stats['fields_err_datatype'][s]['count']}")
            for r in report_asis.err_stats['fields_err_datatype'][s]['reasons']:
                print(f"      reason={r}, count={report_asis.err_stats['fields_err_datatype'][s]['reasons'][r]}")

        print(f"\nRemediated fields with datatype errors: {len(report_remediated.err_stats['fields_err_datatype'])}")
        temp=sorted(report_remediated.err_stats['fields_err_datatype'])
        for s in temp:
            print(f"  field: {s}, count={report_remediated.err_stats['fields_err_datatype'][s]['count']}")
            for r in report_remediated.err_stats['fields_err_datatype'][s]['reasons']:
                print(f"      reason={r}, count={report_remediated.err_stats['fields_err_datatype'][s]['reasons'][r]}")

        print(f"\nRefined fields with datatype errors: {len(report_refined.err_stats['fields_err_datatype'])}");
        temp=sorted(report_refined.err_stats['fields_err_datatype'])
        for s in temp:
            print(f"  field: {s}, count={report_refined.err_stats['fields_err_datatype'][s]['count']}")
            for r in report_refined.err_stats['fields_err_datatype'][s]['reasons']:
                print(f"      reason={r}, count={report_refined.err_stats['fields_err_datatype'][s]['reasons'][r]}")


        print("\n\nField Quality")
        print("As-Is")
        for i in range(len(report_asis.fields)):
            print(f"field {report_asis.fields[i].title}: {report_asis.field_quality[i]}")
        print("\nRemediated")
        for i in range(len(report_remediated.fields)):
            print(f"field {report_remediated.fields[i].title}: {report_remediated.field_quality[i]}")
        print("\nRefined")
        for i in range(len(report_refined.fields)):
            print(f"field {report_refined.fields[i].title}: {report_refined.field_quality[i]}")

        file_uri= curdir + file_name.replace(".csv","_refined_report.dat")
        report_uris.append(file_uri)
        txt= reportfuncs.save_report_to_file(file_uri, report_refined)
        if txt.startswith("notok:"):
            raise ValueError("error from saving Refined report:" + txt[6:])
        
        # save Refined data
        file_uri= curdir + file_name.replace(".csv","_refined_data.dat")
        data_uris.append(file_uri)
        with open(file_uri, "w", encoding="utf-8") as f:
            f.write("|".join(flds_hdr) + LF)
            for i in range(len(outrecs)):
                f.write(outrecs[i] + LF)
        # ------------------    final report and data set saved for later use -------------------------

        print("\nData and Reports Saved to Files:")
        print(f"AS-IS:   data (delim is comma)= {data_uris[0]},  report= {report_uris[0]}")
        print(f"REMEDIATED:   data (delim is comma)= {data_uris[1]},  report= {report_uris[1]}")
        print(f"REFINED:   data (delim is pipe)= {data_uris[2]},  report= {report_uris[2]}")

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR! " + str(err))



if __name__ == "__main__":
    runtest()
