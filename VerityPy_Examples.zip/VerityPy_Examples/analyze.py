#!usr/bin/env python

"""Example using VerityPy to analyze data set
"""

import os
from VerityPy.processing import datefuncs, qualityanalysis, analyzequality, field

DQ:str="\""
LF:str="\n"
CR:str="\r"
CRLF:str=CR+LF


def runtest()->None:
    """Runtest performs example analysis on sample data
    """

    delim:str=","
    title:str=""
    curdir:str=""
    dir_delim:str=""
    txt:str=""
    txt1:str=""
    nline:int=-1
    temp:list=[]
    flds:list=[]
    recs:list=[]
    covalues:list=[]
    settings:dict={}
    report:qualityanalysis.QualityAnalysis= qualityanalysis.QualityAnalysis()
    try:
        print("Starting runtest at " + datefuncs.get_current_iso_datetime(True))

        curdir= os.path.dirname(os.path.realpath(__file__))
        print("current file dir=" + curdir)
        if "\\" in curdir:
            dir_delim="\\"
        else:
            dir_delim="/"
        if not curdir.endswith(dir_delim):
            curdir += dir_delim
        if curdir.endswith("tests" + dir_delim):
            curdir= curdir[:curdir.find("tests"+dir_delim)]
        curdir += "files" + dir_delim
        print("data file dir=" + curdir)

        # read in sample data records and make fields from header line
        print("reading=" + curdir + "IRSMigration_WithErrors_Hdr.csv")
        with open(curdir + "IRSMigration_WithErrors_Hdr.csv","r",encoding="utf-8") as f:
            nline=0
            for line in f:
                if line is None:
                    break
                if line.endswith(CRLF):
                    line=line[:-2]
                if line.endswith(CR) or line.endswith(LF):
                    line=line[:-1]
                if len(line)>0 and not line.startswith("#") and not line.startswith("//"):
                    # we ignore empty and comment lines
                    nline += 1
                    if nline==1:
                        # 1st line is header of delimited field names
                        if line.find(DQ)>-1:
                            line=line.replace(DQ,'')
                        temp= line.split(delim)
                        for s in temp:
                            # create list of Field objects
                            flds.append(field.Field(s.strip()))
                    else:
                        # make list of data records after we handled header
                        recs.append(line)

        # add detail to the Field objects using information from documentation: assign datatypes and formats
        for f in flds:
            title= f.title.lower()
            if title in ["y2_statefips","y1_statefips"]:
                f.datatype="string"
                f.fmt_strlen=2 # this specifies that the value should be 2 characters
            elif title=="y1_state":
                f.datatype="string"
                f.fmt_strcase="upper" # this specifies that the value should be uppercase
                f.fmt_strlen=2
            elif title=="y1_state_name":
                f.datatype="string"
            elif title in ["n1","n2"]:
                f.datatype="int"
            elif title=="agi":
                f.datatype="real"
                f.fmt_decimal=0

        covalues.append("y1_state,y1_state_name")

        settings['is_case_sens']="false"
        settings['is_quoted']="true"
        settings['has_header']="false"
        settings['extract_fields']="false"
        settings['delim']="comma"
        settings['maxuv']="100"

        report=analyzequality.do_qualityinspect(flds, covalues, recs, settings)
        if report.status.startswith("notok:"):
            raise ValueError("error from report:" + report.status[6:])

        print(f"Number of fields = {len(report.fields)}")
        print(f"field titles:{','.join(x.title for x in report.fields)}")
        print(f"Number of records = {report.numrecs}")
        print(f"Number of records with errors = {report.err_stats['numrecs_err']}")
        print(f"Number of records with datatype errors = {report.err_stats['numrecs_err_datatype']}")
        print(f"Number of records with format errors = {report.err_stats['numrecs_err_fmt']}")

        print("\nField Quality:")
        for i,f in enumerate(report.fields):
            print(f"field {f.title} has {report.field_quality[i]} quality metric")

        if report.err_stats['numrecs_err_datatype']>0:
            print("\nDatatype Errors per Field:")
            for fldname in report.err_stats['fields_err_datatype']:
                print(f"\nfield {fldname} had {report.err_stats['fields_err_datatype'][fldname]['count']} datatype errors")
                for reason in report.err_stats['fields_err_datatype'][fldname]['reasons']:
                    print(f"    reason={reason} {report.err_stats['fields_err_datatype'][fldname]['reasons'][reason]} times")

            print("\n10 Datatype Error Examples as (nline)[field:reason:value]|[field:reason:value].....")
            for i,ex in enumerate(report.err_datatype_examples):
                if i>10:
                    break
                print(ex)

        if report.err_stats['numrecs_err_fmt']>0:
            print("\nFormat Error Details:")
            for fldname in report.err_stats['fields_err_fmt']:
                print(f"\nfield {fldname} had {report.err_stats['fields_err_fmt'][fldname]['count']} format errors")
                for reason in report.err_stats['fields_err_fmt'][fldname]['reasons']:
                    print(f"    reason={reason} {report.err_stats['fields_err_fmt'][fldname]['reasons'][reason]} times")

            print("\n10 Format Error Examples as (nline)[field:reason:value]|[field:reason:value].....")
            for i,ex in enumerate(report.err_fmt_examples):
                if i>10:
                    break
                print(ex)

        print("\nParsing Errors- examples are (nRec)linein:")
        # limit to 4 examples
        print(f"Small1= {report.rec_parse_errs['small1']}")
        if len(report.rec_parse_errs['small1_recs'])>0:
            for i in range(len(report.rec_parse_errs['small1_recs'])):
                if i>4:
                    break
                print(f"    example:{report.rec_parse_errs['small1_recs'][i]}")
        print(f"Small2= {report.rec_parse_errs['small2']}")
        if len(report.rec_parse_errs['small2_recs'])>0:
            for i in range(len(report.rec_parse_errs['small2_recs'])):
                if i>4:
                    break
                print(f"    example:{report.rec_parse_errs['small2_recs'][i]}")
        print(f"Big= {report.rec_parse_errs['big']}")
        if len(report.rec_parse_errs['big_recs'])>0:
            for i in range(len(report.rec_parse_errs['big_recs'])):
                if i>4:
                    break
                print(f"    example:{report.rec_parse_errs['big_recs'][i]}")


        print("\nTop 5 Unique Values per Field (excluding -other-):")
        for i,f in enumerate(report.fields):
            nline=0 # counter
            print(f"\nfield {f.title} has {len(report.field_uniqvals[i])} unique values")
            for j in range(len(report.field_uniqvals[i])):
                title= report.field_uniqvals[i][j][0]
                if title != "-other-":
                    nline +=1
                    if nline > 5:
                        break
                    print(f"{title} has {report.field_uniqvals[i][j][1]} instances")

        print("\nBottom 5 Unique Values per Field (excluding -other-):")
        for i,f in enumerate(report.fields):
            nline=0 # counter
            print(f"\nfield {f.title}")
            for j in range(len(report.field_uniqvals[i])-1,-1,-1):
                title= report.field_uniqvals[i][j][0]
                if title != "-other-":
                    nline +=1
                    if nline > 5:
                        break
                    print(f"{title} has {report.field_uniqvals[i][j][1]} instances")


        print("\nTop 5 Unique Values per CoValue (excluding -other-):")
        for i,f in enumerate(report.covalues):
            nline=0 # counter
            print(f"CoValue {f.title} has {len(report.covalue_uniqvals[i])} unique values")
            for j in range(len(report.covalue_uniqvals[i])):
                title= report.covalue_uniqvals[i][j][0]
                if title != "-other-":
                    nline +=1
                    if nline > 5:
                        break
                    print(f"{title} has {report.covalue_uniqvals[i][j][1]} instances")

        print("\nBottom 5 Unique Values per CoValue (excluding -other-):")
        for i,f in enumerate(report.covalues):
            nline=0 # counter
            print(f"CoValue {f.title}")
            for j in range(len(report.covalue_uniqvals[i])-1,-1,-1):
                title= report.covalue_uniqvals[i][j][0]
                if title != "-other-":
                    nline +=1
                    if nline > 5:
                        break
                    print(f"{title} has {report.covalue_uniqvals[i][j][1]} instances")


        print("\nSpecial Characters:")
        for sc,n in report.spec_char_dist.items():
            print(f"special character {sc} has {n} instances")

        print("\nSpecial Character Examples:")
        for s in report.spec_char_examples:
            txt= s[1:s.find(")")]
            txt1= s[s.find("[")+1:s.find("]")]
            print(f"nline={txt}, spchars={txt1}, linein={s[s.find(']')+1:]}")

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR! " + str(err))



if __name__ == "__main__":
    runtest()
