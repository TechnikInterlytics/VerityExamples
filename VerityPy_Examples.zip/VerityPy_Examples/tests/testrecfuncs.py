#!/usr/bin/env python
"""
Test Record Functions

Run variety of tests to functions in recfuncs module
"""


__all__ = ['do_test_recfuncs']
__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240701'

import math
import datetime
from VerityPy.processing import recfuncs, field

def do_test_recfuncs():
    """
    Test Record Functions

    Do variety of test cases and check results for expected versus actual
    """


    print("TEST RECORD FUNCTIONS\n")

    # note: for import to work while doing local debugging there should be launch.json with setting for:
    # "env": {"PYTHONPATH": "${workspaceRoot}"}, within the configuration used

    val:str=""
    dtype:str=""
    datefmt:str=""
    delim:str=""
    resexp:str=""
    resact:str=""
    status:str=""
    dq:str= "\""
    reason:str=""
    fmt:str=""
    bval:bool=False
    allow_empty:bool=False
    outrecs:list=[]
    outexp:list=[]
    ign:dict={}
    datatype_dist_fields:list=[]
    datatype_dist:dict={}
    settings:dict={}
    fld:field.Field=field.Field("test")

    print("Current dateTime= " + str(datetime.datetime.now()))

    print("\nTest: is_math_alias")
    for i in range(5):
        if i==0:
            val="071175"
            resexp="False"
        elif i==1:
            val="mathpi"
            resexp="False"
        elif i==2:
            val="-MATHPI-"
            resexp="True"
        elif i==3:
            val="-mathe-"
            resexp="True"
        elif i==4:
            val="-MAthe"
            resexp="False"
        resact= str(recfuncs.is_math_alias(val))
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: get_math_alias")
    for i in range(5):
        if i==0:
            val="071175"
            resexp=val
        elif i==1:
            val="mathpi"
            resexp=val
        elif i==2:
            val="-MATHPI-"
            resexp= str(math.pi)
        elif i==3:
            val="-mathe-"
            resexp=str(math.e)
        elif i==4:
            val="-MAthe"
            resexp=val
        resact= recfuncs.get_math_alias(val)
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: delim_get_char")
    for i in range(6):
        if i==0:
            val="071175"
            resexp="false"
        elif i==1:
            val="comma"
            resexp=","
        elif i==2:
            val="tab"
            resexp= "\t"
        elif i==3:
            val="pipe"
            resexp= "|"
        elif i==4:
            val="hyphen"
            resexp="-"
        elif i==5:
            val="-hyphen"
            resexp= "false"
        resact= recfuncs.delim_get_char(val)
        if resexp=="false" and resact.startswith("false"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: convert_special_notation")
    for i in range(19):
        if i==0:
            val="071175"
            resexp=val
        elif i==1:
            val="-comma-"
            resexp=","
        elif i==2:
            val="-tab-"
            resexp= "\t"
        elif i==3:
            val="-pipe-"
            resexp= "|"
        elif i==4:
            val="pipe"
            resexp= val
        elif i==5:
            val="-space-"
            resexp= " "
        elif i==6:
            val="-bslash-"
            resexp= "\\"
        elif i==7:
            val="-fslash-"
            resexp= "/"
        elif i==8:
            val="-lparen-"
            resexp= "("
        elif i==9:
            val="-rparen-"
            resexp= ")"
        elif i==10:
            val="-lcurly-"
            resexp= "{"
        elif i==11:
            val="-rcurly-"
            resexp= "}"
        elif i==12:
            val="-lsquare-"
            resexp= "["
        elif i==13:
            val="-rsquare-"
            resexp= "]"
        elif i==14:
            val="-mathpi-"
            resexp= str(math.pi)
        elif i==15:
            val="-mathe-"
            resexp= str(math.e)
        elif i==16:
            val="-rcurly"
            resexp= val
        elif i==17:
            val="tab comma"
            resexp= val
        elif i==18:
            val="-crlf-"
            resexp= "\r\n"
        resact= recfuncs.convert_special_notation(val)
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: convert_char_aliases")
    for i in range(8):
        if i==0:
            val="071175"
            resexp=val
        elif i==1:
            val="-comma-"
            resexp=","
        elif i==2:
            val="dogs are fun-comma-cats are cool"
            resexp= "dogs are fun,cats are cool"
        elif i==3:
            val="field1-pipe-field2-pipe-field3"
            resexp= "field1|field2|field3"
        elif i==4:
            val="-lparen- HELLO -rparen-"
            resexp= "( HELLO )"
        elif i==5:
            val="-dblquote-This is quoted-dblquote-"
            resexp= "\"This is quoted\""
        elif i==6:
            val="-bslash-escape:-lsquare--mathpi--rsquare-"
            resexp= "\\escape:[" + str(math.pi) + "]"
        elif i==7:
            val = "-lparen--pipe-HELLO-rsquare--rparen-"
            resexp = "(|HELLO])"
        resact= recfuncs.convert_char_aliases(val)
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: extract_char_aliases")
    for i in range(8):
        ign={}
        if i==0:
            val="071175"
            resexp=val
        elif i==1:
            resexp="-comma-"
            val=","
        elif i==2:
            resexp="dogs are fun-comma-cats are cool"
            val= "dogs are fun,cats are cool"
        elif i==3:
            resexp="field1-pipe-field2-pipe-field3"
            val= "field1|field2|field3"
        elif i==4:
            resexp="-lparen- HELLO -rparen-"
            val= "( HELLO )"
        elif i==5:
            resexp="-dblquote-This is quoted-dblquote-"
            val= "\"This is quoted\""
        elif i==6:
            resexp="-bslash-escape:-lsquare--tab--rsquare-"
            val= "\\escape:[\t]"
        elif i==7:
            resexp="-lparen-|HELLO]-rparen-"
            val= "(|HELLO])"
            ign["|"]=True
            ign["]"]=True
        resact= recfuncs.extract_char_aliases(val,ign)
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: split_quoted_line")
    for i in range(4):
        if i==0:
            val="dogs are fun,cats are cool|" + dq + "cats are smart|dogs run" + dq
            delim="pipe"
        elif i==1:
            val= "field1,field2," + dq + "has comma, behind" + dq + ",field3"
            delim="comma"
        elif i==2:
            val="dogs are fun,cats are cool|cats are smart|dogs run"
            delim="pipe"
        elif i==3:
            val="071175"
            delim="comma"
        outrecs= recfuncs.split_quoted_line(val, delim)
        print("\nvalue=" + val + ",delim=" + delim + ", Result [")
        for j in range(len(outrecs)):
            print(str(j) + ":" + outrecs[j])
        print("]")

    print("\nTest: detect_datatype")
    for i in range(14):
        if i==0:
            val="71175e2"
            resexp="int"
        elif i==1:
            val="1.2345e-2"
            resexp="real"
        elif i==2:
            val="123egg"
            resexp="string"
        elif i==3:
            val="/12-01-2024"
            resexp="string"
        elif i==4:
            val="12-01-2024"
            resexp="date"
        elif i==5:
            val="01-23-23T11:00"
            resexp="date"
        elif i==6:
            val="01-00-23T11:00"
            resexp="string"
        elif i==7:
            val=".251"
            resexp= "real"
        elif i==8:
            val=".25.1"
            resexp= "string"
        elif i==9:
            val="25.1"
            resexp= "real"
        elif i==10:
            val="251"
            resexp= "int"
        elif i==11:
            val="TRUE"
            resexp= "bool"
        elif i==12:
            val="0032"
            resexp= "string"
        elif i==13:
            val="032"
            resexp= "int"
        resact= recfuncs.detect_datatype(val)
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)


    print("\nTest: assign_datatype")
    for i in range(6):
        if i==0:
            datatype_dist={"int":40,"real":10,"bool":0,"date":0,"string":10,"empty":0}
            settings={"include_empty":"true","minfrac":""}
            resexp="real"
        elif i==1:
            datatype_dist={"int":30,"real":10,"bool":5,"date":0,"string":15,"empty":0}
            settings={"include_empty":"true","minfrac":"50"}
            resexp="int"
        elif i==2:
            datatype_dist={"int":30,"real":10,"bool":5,"date":0,"string":15,"empty":40}
            settings={"include_empty":"true","minfrac":".55"}
            resexp="string"
        elif i==3:
            datatype_dist={"int":5,"real":10,"bool":30,"date":0,"string":15,"empty":40}
            settings={"include_empty":"false","minfrac":".5"}
            resexp="bool"
        elif i==4:
            datatype_dist={"int":5,"real":10,"bool":30,"date":0,"string":15,"empty":40}
            settings={"include_empty":"true","minfrac":""}
            resexp=""
        elif i==5:
            datatype_dist={"int":35,"real":0,"bool":0,"date":70,"string":15,"empty":40}
            settings={"include_empty":"false","minfrac":"41"}
            resexp="date"

        resact= recfuncs.assign_datatype(datatype_dist, settings)
        val=""
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
            val= "index=" + str(i) + ", "
        print(val + "Result [" + resexp + "]=" + resact + " ------>  " + status)


    print("\nTest: assign_datatype_to_fields")
    settings={"include_empty":"true","minfrac":"50"}
    print("Settings: " + str(settings))
    datatype_dist_fields.append({"int":40,"real":10,"bool":0,"date":0,"string":10,"empty":0})
    datatype_dist_fields.append({"int":40,"real":10,"bool":0,"date":0,"string":10,"empty":30})
    datatype_dist_fields.append({"int":0,"real":25,"bool":0,"date":0,"string":0,"empty":20})
    datatype_dist_fields.append({"int":10,"real":0,"bool":0,"date":35,"string":10,"empty":0})
    datatype_dist_fields.append({"int":10,"real":0,"bool":37,"date":0,"string":0,"empty":10})
    outexp=["int","real","real","date","bool"]
    outrecs= recfuncs.assign_datatype_to_fields(datatype_dist_fields, settings)
    for i in range(len(outrecs)):
        status= "OK" if outrecs[i]==outexp[i] else "FAIL"
        print(str(i) + ": dist=" + str(datatype_dist_fields[i]) + ",  dtype=" + outrecs[i] + "   -----> " + status)

    print("\nTest: is_field_its_datatype")
    for i in range(20):
        if i == 0:
            val = "123"
            dtype = "int"
            resexp = "true"
        elif i == 1:
            val = "123"
            dtype = "real"
            resexp = "true"
        elif i == 2:
            val = "123.205"
            dtype = "real"
            resexp = "true"
        elif i == 3:
            val = "123.205"
            dtype = "int"
            resexp = "false"
        elif i == 4:
            val = "123.205"
            dtype = "string"
            resexp = "true"
        elif i == 5:
            val = "123.205"
            dtype = "bool"
            resexp = "false"
        elif i == 6:
            val = "123.205"
            dtype = "bool"
            resexp = "false"
        elif i == 7:
            val = "tRUE"
            dtype = "bool"
            resexp = "true"
        elif i == 8:
            val = "tRU"
            dtype = "bool"
            resexp = "false"
        elif i == 9:
            val = "FALSE"
            dtype = "bool"
            resexp = "true"
        elif i == 10:
            val = "false"
            dtype = "bool"
            resexp = "true"
        elif i == 11:
            val = "20240630T1235"
            dtype = "datetime"
            datefmt = "iso"
            resexp = "true"
        elif i == 12:
            val = "20240630 1235"
            dtype = "datetime"
            datefmt = "iso"
            resexp = "true"
        elif i == 13:
            val = "20240630T1235"
            dtype = "date"
            datefmt = "iso"
            resexp = "true"
        elif i == 14:
            val = "20240630"
            dtype = "date"
            datefmt = "yyyyddmm"
            resexp = "false"
        elif i == 15:
            val = "20240630"
            dtype = "date"
            datefmt = "yyyymmdd"
            resexp = "true"
        elif i == 16:
            val = "06302024"
            dtype = "date"
            datefmt = "yyyymmdd"
            resexp = "false"
        elif i == 17:
            val = "06302024"
            dtype = "date"
            datefmt = "mmddyyyy"
            resexp = "true"
        elif i == 18:
            val = "06302024"
            dtype = "date"
            datefmt = "mmddyy"
            resexp = "false"
        elif i == 19:
            val = "063024"
            dtype = "date"
            datefmt = "mmddyy"
            resexp = "true"
        else:
            break

        if i<=10:
            bval= recfuncs.is_field_its_datatype(dtype, val)
        else:
            bval= recfuncs.is_field_its_datatype(dtype, val, datefmt)

        txt=str(i) + ": val=" + val + ",dtype=" + dtype + ",resexp=" + resexp + ",resact=" + str(bval)
        if resexp == str(bval).lower():
            txt += "   ------------->  OK"
        else:
            txt += "   ------------->  FAIL"
        print(txt)


    print("\nTest: is_field_its_format")
    for i in range(20):
        if i == 0:
            val = "123"
            fld.datatype = "int"
            allow_empty = False
            resexp = "true"
        elif i == 1:
            val = "123"
            fld.datatype = "real"
            allow_empty = False
            resexp = "true"
        elif i == 2:
            val = "123.205"
            fld.datatype = "real"
            allow_empty = False
            resexp = "true"
        elif i == 3:
            val = "123.205"
            fld.datatype = "int"
            allow_empty = False
            resexp = "false"
        elif i == 4:
            val = ""
            fld.datatype = "real"
            allow_empty = False
            resexp = "false"
        elif i == 5:
            val = ""
            fld.datatype = "real"
            allow_empty = True
            resexp = "true"
        elif i == 6:
            val = "123.205"
            fld.datatype = "real"
            fld.fmt_decimal = 2
            allow_empty = False
            resexp = "false"
        elif i == 7:
            val = "123.205"
            fld.datatype = "real"
            fld.fmt_decimal = 3
            allow_empty = False
            resexp = "true"
        elif i == 8:
            val = "dog and CATS"
            fld.datatype = "string"
            allow_empty = False
            resexp = "true"
        elif i == 9:
            val = "dog and CATS"
            fld.datatype = "string"
            fld.fmt_strcase = "upper"
            allow_empty = False
            resexp = "false"
        elif i == 10:
            val = "dog and CATS".upper()
            fld.datatype = "string"
            fld.fmt_strcase = "upper"
            allow_empty = False
            resexp = "true"
        elif i == 11:
            val = "dog and CATS".lower()
            fld.datatype = "string"
            fld.fmt_strcase = "lower"
            allow_empty = False
            resexp = "true"
        elif i == 12:
            val = ""
            fld.datatype = "string"
            fld.fmt_strcase = ""
            allow_empty = False
            resexp = "false"
        elif i == 13:
            val = ""
            fld.datatype = "string"
            fld.fmt_strcase = ""
            allow_empty = True
            resexp = "true"
        elif i == 14:
            val = "dog and CATS"
            fld.datatype = "string"
            fld.fmt_strcase = ""
            fld.fmt_strlen = 12
            allow_empty = False
            resexp = "true"
        elif i == 14:
            val = "dog and CATS"
            fld.datatype = "string"
            fld.fmt_strcase = ""
            fld.fmt_strlen = 10
            allow_empty = False
            resexp = "false"
        elif i == 15:
            val = "06302024"
            fld.datatype = "date"
            datefmt = "yyyymmdd"
            allow_empty = False
            resexp = "false"
        elif i == 16:
            val = "06302024"
            fld.datatype = "date"
            fld.fmt_date= "mmddyyyy"
            allow_empty = False
            resexp = "true"
        elif i == 17:
            val = "06302024"
            fld.datatype = "date"
            fld.fmt_date = "mmddyy"
            allow_empty = False
            resexp = "false"
        elif i == 18:
            val = "063024"
            fld.datatype = "date"
            fld.fmt_date = "mmddyy"
            allow_empty = False
            resexp = "true"
        else:
             break

        resact = recfuncs.is_field_its_format(val, fld, allow_empty)
        reason = ""
        if ":" in resact:
            reason=resact[(resact.find(":")+1):]
            resact= resact[:resact.find(":")]
        
        fmt = ""
        if fld.datatype == "real":
            fmt = str(fld.fmt_decimal)
        elif fld.datatype == "date":
            fmt = fld.fmt_date
        elif fld.datatype == "string":
            fmt = "case=" + fld.fmt_strcase + ",len=" + str(fld.fmt_strlen)

        txt= str(i) + ": val=" + val + ",dtype=" + fld.datatype + ",fmt=" + fmt + ",resexp=" + resexp + ",resact=" + resact
        if resexp == resact:
            txt += "   ------------->  OK"
        else:
            txt += "   ------------->  FAIL-" + reason
        print(txt)
				






if __name__ == '__main__':
    do_test_recfuncs()
