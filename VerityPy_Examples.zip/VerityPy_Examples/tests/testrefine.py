#!/usr/bin/env python
"""
Test Refine

Run test on refinedata.py
"""


__all__ = []
__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240922'

import os
import datetime
from VerityPy.processing import field, recfuncs, refinedata
from VerityPy.transforms import lookup, transform

DQ:str="\""


def do_refine():
    """
    Run test of refine function in refinedata.py
    """

    file_uri:str=""
    file_name:str=""
    curdir:str=""
    datadir:str=""
    dir_delim:str=""
    delim:str="comma"
    delim_char:str=","
    txt:str=""
    title:str=""
    dtype:str=""
    mapto:str=""
    parse_error:str=""
    strcase:str=""
    strcut:str=""
    strpad:str=""
    strpadchar:str=""
    fmtdate:str=""
    file_out:str=""
    nkeys:int=0
    strlen:int=-1
    numdec:int=-1
    ntrans:int=-1
    nfld:int=-1
    nline:int=0
    iscasesens:bool=False
    temp:list=[]
    fldvals:list=[]
    outfields:list=[]
    srcfields:list=[]
    srcrecs:list=[]
    outrecs:list=[]
    hash_outfields:dict={}
    settings:dict={}
    lookup_dict:lookup.LookUpDict
    lookups:list=[]
    hash_lookups:dict={}
    transforms:list=[]
    try:
        print("TEST REFINE DATA\n")
        print("Current dateTime= " + str(datetime.date.today()))

        curdir= os.path.dirname(os.path.realpath(__file__))
        print("current file dir=" + curdir)
        if "\\" in curdir:
            dir_delim="\\"
        else:
            dir_delim="/"
        if not curdir.endswith(dir_delim):
            curdir += dir_delim
        datadir= curdir.replace("tests","files")
        print("data file dir=" + datadir)

        delim_char= recfuncs.delim_get_char(delim)

        # Test 1: source data does not have broken records
        file_name="IRSMigration_WithErrors_NoBrk_Hdr.csv"
        file_uri=datadir + file_name
        with open(file_uri,"r",encoding="utf-8") as f:
            nline=0
            for line in f:
                if line is None:
                    break
                if line.endswith("\r\n"):
                    line=line[:-2]
                if line.endswith("\n") or line.endswith("\r"):
                    line=line[:-1]
                if len(line)>0 and not line.startswith("#") and not line.startswith("//"):
                    nline += 1
                    srcrecs.append(line) # we could not include header if we coordinated setting 'hasheader' sent to Refine module
                    if nline==1:
                        if line.find(delim_char)<1:
                            raise ValueError("first data line does not contain delimiter: " + delim_char)
                        if line.find(DQ)>-1:
                            line=line.replace(DQ,'')
                        temp= line.split(delim_char)
                        if len(temp)==0:
                            raise ValueError("no fields found with delim=" + delim_char)
                        for i in range(len(temp)):
                            srcfields.append(field.Field(temp[i]))
        if len(srcfields)==0:
            raise ValueError("no source fields in file header")
        if len(srcrecs)==0:
            raise ValueError("no source records")

        # Define output fields
        for i in range(len(srcfields)):
            txt=srcfields[i].title.lower()
            dtype=""
            if txt.endswith("fips") or txt.startswith("y1_state"):
                dtype="string"
            elif txt in ["n1","n2"]:
                dtype="int"
            elif txt=="agi":
                dtype="real"
            mapto=txt
            strcase=""
            strcut=""
            strpad=""
            strpadchar=""
            strlen=-1
            fmtdate=""
            numdec=-1
            if txt=="y2_statefips":
                title="DestStateCode"
                strlen=2
                strcut="back"
                strpad="front"
                strpadchar="0"
            elif txt=="y1_statefips":
                title="OrigStateCode"
                strlen=2
                strcut="back"
                strpad="front"
                strpadchar="0"
            elif txt=="y1_state":
                title="OrigStateAbbr"
                strlen=2
                strcase="upper"
                strcut="back"
                strpad="front"
                strpadchar="hyphen"
            elif txt=="y1_state_name":
                title="OrigStateName"
            elif txt=="n1":
                title="NumReturn"
            elif txt=="n2":
                title="NumExempt"
            elif txt=="agi":
                title="GrossIncome"
                numdec=2
            else:
                title=srcfields[i].title

            outfields.append(field.Field(title))
            nfld= len(outfields)-1
            outfields[nfld].mapto=mapto
            outfields[nfld].datatype=dtype
            outfields[nfld].fmt_strlen=strlen
            outfields[nfld].fmt_strcase=strcase
            outfields[nfld].fmt_strcut=strcut
            outfields[nfld].fmt_strpad=strpad
            outfields[nfld].fmt_strpadchar=strpadchar
            outfields[nfld].fmt_date=fmtdate
            outfields[nfld].fmt_decimal=numdec
            hash_outfields[title.lower()]=nfld

        # ADD ENRICHMENT FIELDS (not in source records but will be in output records)
        outfields.append(field.Field("useAGI"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "bool"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        outfields.append(field.Field("DestStateAbbr"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "string"
        outfields[nfld].fmt_strlen= 2
        outfields[nfld].fmt_strcase= "upper"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        outfields.append(field.Field("DestStateName"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "string"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        outfields.append(field.Field("isSubTotal"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "bool"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        # make lookups
        title="lookup_3field"
        file_name="lookup_3field_test.dat"
        nkeys=3
        iscasesens=True
        file_uri= datadir + file_name
        lookup_dict= lookup.LookUpDict()
        lookup_dict= lookup.make_lookup_from_file(title, file_uri, "pipe", iscasesens, nkeys)
        if lookup_dict.title.startswith("notok:"):
            raise ValueError("error making LookUpDict " + title + ": " + lookup_dict.title[6:])
        elif len(lookup_dict.fields)==0:
            raise ValueError("error making LookUpDict since missing fields " + title)
        elif len(lookup_dict.recs)==0:
            raise ValueError("error making LookUpDict since missing recs " + title)
        lookups.append(lookup_dict)
        hash_lookups[lookup_dict.title.lower()]= len(lookups)-1

        title = "FIPS_State_County"
        file_name = "FIPS_stateCountyCodes.dat"
        nkeys=2
        iscasesens=False
        file_uri= datadir + file_name
        lookup_dict= lookup.LookUpDict()
        lookup_dict= lookup.make_lookup_from_file(title, file_uri, "comma", iscasesens, nkeys)
        if lookup_dict.title.startswith("notok:"):
            raise ValueError("error making LookUpDict " + title + ": " + lookup_dict.title[6:])
        elif len(lookup_dict.fields)==0:
            raise ValueError("error making LookUpDict since missing fields " + title)
        elif len(lookup_dict.recs)==0:
            raise ValueError("error making LookUpDict since missing recs " + title)
        lookups.append(lookup_dict)
        hash_lookups[lookup_dict.title.lower()]= len(lookups)-1

        title = "USStatesNormalize"
        file_name = "USStatesNormalize.dat"
        nkeys=1
        iscasesens=False
        file_uri= datadir + file_name
        lookup_dict= lookup.LookUpDict()
        lookup_dict= lookup.make_lookup_from_file(title, file_uri, "pipe", iscasesens, nkeys)
        if lookup_dict.title.startswith("notok:"):
            raise ValueError("error making LookUpDict " + title + ": " + lookup_dict.title[6:])
        elif len(lookup_dict.fields)==0:
            raise ValueError("error making LookUpDict since missing fields " + title)
        elif len(lookup_dict.recs)==0:
            raise ValueError("error making LookUpDict since missing recs " + title)
        lookups.append(lookup_dict)
        hash_lookups[lookup_dict.title.lower()]= len(lookups)-1

        title = "StateAbbr"
        file_name = "StateAbbrfromFIPS_lookup.dat"
        nkeys=1
        iscasesens=False
        file_uri= datadir + file_name
        lookup_dict= lookup.LookUpDict()
        lookup_dict= lookup.make_lookup_from_file(title, file_uri, "pipe", iscasesens, nkeys)
        if lookup_dict.title.startswith("notok:"):
            raise ValueError("error making LookUpDict " + title + ": " + lookup_dict.title[6:])
        elif len(lookup_dict.fields)==0:
            raise ValueError("error making LookUpDict since missing fields " + title)
        elif len(lookup_dict.recs)==0:
            raise ValueError("error making LookUpDict since missing recs " + title)
        lookups.append(lookup_dict)
        hash_lookups[lookup_dict.title.lower()]= len(lookups)-1

        title = "StateName"
        file_name = "StateNamefromFIPS_lookup.dat"
        nkeys=1
        iscasesens=False
        file_uri= datadir + file_name
        lookup_dict= lookup.LookUpDict()
        lookup_dict= lookup.make_lookup_from_file(title, file_uri, "pipe", iscasesens, nkeys)
        if lookup_dict.title.startswith("notok:"):
            raise ValueError("error making LookUpDict " + title + ": " + lookup_dict.title[6:])
        elif len(lookup_dict.fields)==0:
            raise ValueError("error making LookUpDict since missing fields " + title)
        elif len(lookup_dict.recs)==0:
            raise ValueError("error making LookUpDict since missing recs " + title)
        lookups.append(lookup_dict)
        hash_lookups[lookup_dict.title.lower()]= len(lookups)-1

        # lookup from list
        title="3field"
        nkeys=3
        temp=[]
        temp.append("field1|field2|field3|value")
        temp.append("Med*-and-*ary*-and-*-1-not- Sum-not-*#*|BL*-and-*ue*-not-* paper|Me*-and-*ar*-and-*L-1-not-*care |REC0")
        temp.append("Med*-and-*ary*-and-*-1-not- Sum-not-*#1*|BL*-and-*ue*-and-* paper-not-S*-not-*#|123*-and-*9A-not-*care |REC1")
        temp.append("Med*-and-*ary*-and-*-1-not- Sum-not-*#0*|BL*-and-*ue*-and-* paper|123*-and-*9A-not-*care *|REC2")
        lookup_dict= lookup.LookUpDict()
        lookup_dict= lookup.make_lookup_from_list(title, temp, "pipe", iscasesens, nkeys)
        if lookup_dict.title.startswith("notok:"):
            raise ValueError("error making LookUpDict " + title + ": " + lookup_dict.title[6:])
        elif len(lookup_dict.fields)==0:
            raise ValueError("error making LookUpDict since missing fields " + title)
        elif len(lookup_dict.recs)==0:
            raise ValueError("error making LookUpDict since missing recs " + title)
        lookups.append(lookup_dict)
        hash_lookups[lookup_dict.title.lower()]= len(lookups)-1


        # Define Transforms
        # 1st transform sets useAGI based on source field AGI value since it has some
        # coded values that shoud not be included in aggregations per source documentation
        ntrans=0
        transforms=[]
        transforms.append(transform.Transform("useAGI"))
        transforms[ntrans].ops.append(transform.Op("setToRef", "AGI"))
        transforms[ntrans].ops.append(transform.Op("IfEq", "-1"))
        transforms[ntrans].ops.append(transform.Op("setToValue","true")) # action for False condition
        transforms[ntrans].ops.append(transform.Op("setToValue","false")) # action for True condition, useAGI = false meaning dont use AGI value since it is code -1

        ntrans +=1
        transforms.append(transform.Transform("GrossIncome"))
        transforms[ntrans].ops.append(transform.Op("IfNotEq","-1")) # has coded values we need to handle for useful analytic output records
        transforms[ntrans].ops.append(transform.Op("NoOp")) # do nothing if -1 (since False for IfNotEq)
        transforms[ntrans].ops.append(transform.Op("mult","1000"))  # normalize to true $ unit since in thousands

        ntrans +=1
        transforms.append(transform.Transform("DestStateAbbr"))
        transforms[ntrans].ops.append(transform.Op("setToRef","y2_statefips"))
        transforms[ntrans].ops.append(transform.Op("setLength","2","left","0")) # lookup dict use fixed 2 char long codes
        transforms[ntrans].ops.append(transform.Op("lookup","StateAbbr")) # short title we assigned to lookup dictionary file

        ntrans +=1
        transforms.append(transform.Transform("DestStateName"))
        transforms[ntrans].ops.append(transform.Op("setToRef","y2_statefips"))
        transforms[ntrans].ops.append(transform.Op("setLength","2","left","0")) # lookup dict use fixed 2 char long codes
        transforms[ntrans].ops.append(transform.Op("lookup","StateName"))

        ntrans +=1
        transforms.append(transform.Transform("isSubTotal"))
        transforms[ntrans].ops.append(transform.Op("setToRef","y1_state_name"))
        transforms[ntrans].ops.append(transform.Op("IfStrContains","migra"))
        transforms[ntrans].ops.append(transform.Op("setToValue","false"))
        transforms[ntrans].ops.append(transform.Op("setToValue","true"))


        # ------  Process Source Records --------------
        # pass settings to Refine module
        settings["has_header"]="true"
        settings["is_quoted"]="true"
        settings["normalize"]="true"
        settings["use_comment"]="false"
        settings["delim"]="comma"
        settings["delim_out"]="pipe"
        settings["embed_delim"]="_"

        outrecs= refinedata.do_refine(outfields, transforms, settings, lookups, srcfields, srcrecs)
        if len(outrecs)==0:
            raise ValueError("Refine error: no output records")
        elif outrecs[0].startswith("notok:"):
            raise ValueError("Refine error: " + outrecs[0][6:])

        # write to file
        file_out= datadir + "TestRefine_IRS_NoBrk_output.dat"
        with open(file_out, "w", encoding="utf-8") as f:
            for s in outrecs:
                f.write(s+"\n")

        print("Output records in: " + file_out)
        temp=[]
        nline= len(outrecs)
        if nline!=1001:
            temp.append("incorrect #output lines(1001): " + str(len(outrecs)))
        fldvals= outrecs[0].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields(11) recs[0]: " + str(len(fldvals)))
        elif fldvals[0]!="DestStateCode":
            temp.append("incorrect #output field[0](DestStateCode): " + fldvals[0])
        elif fldvals[2]!="OrigStateAbbr":
            temp.append("incorrect #output field[2](OrigStateAbbr): " + fldvals[2])
        elif fldvals[6]!="GrossIncome":
            temp.append("incorrect #output field[6](GrossIncome): " + fldvals[6])
        elif fldvals[7]!="useAGI":
            temp.append("incorrect #output field[7](useAGI): " + fldvals[7])
        elif fldvals[9]!="DestStateName":
            temp.append("incorrect #output field[9](DestStateName): " + fldvals[9])
        elif fldvals[10]!="isSubTotal":
            temp.append("incorrect #output field[10](isSubTotal): " + fldvals[10])

        fldvals= outrecs[1].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[1](11): " + str(len(fldvals)))
        elif fldvals[0]!="01":
            temp.append("incorrect #output field[0] recs[1](01): " + fldvals[0])
        elif fldvals[1]!="96":
            temp.append("incorrect #output field[1] recs[1](96): " + fldvals[1])
        elif fldvals[2]!="AL":
            temp.append("incorrect #output field[2] recs[1](AL): " + fldvals[2])
        elif fldvals[6]!="1515297000.00":
            temp.append("incorrect #output field[6] recs[1](1515297000.00): " + fldvals[6])
        elif fldvals[7]!="true":
            temp.append("incorrect #output field[7] recs[1](true): " + fldvals[7])
        elif fldvals[9]!="Alabama":
            temp.append("incorrect #output field[9] recs[1](Alabama): " + fldvals[9])
        elif fldvals[10]!="true":
            temp.append("incorrect #output field[10] recs[1](true): " + fldvals[10])

        fldvals= outrecs[14].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[14](11): " + str(len(fldvals)))
        elif fldvals[0]!="01":
            temp.append("incorrect #output field[0] recs[14](01): " + fldvals[0])
        elif fldvals[2]!="FR":
            temp.append("incorrect #output field[2] recs[14](FR): " + fldvals[2])
        elif fldvals[6]!="48079000.00":
            temp.append("incorrect #output field[6] recs[14](48079000.00): " + fldvals[6])
        elif fldvals[7]!="true":
            temp.append("incorrect #output field[7] recs[14](true): " + fldvals[7])
        elif fldvals[9]!="Alabama":
            temp.append("incorrect #output field[9] recs[14](Alabama): " + fldvals[9])

        fldvals= outrecs[726].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[726](11): " + str(len(fldvals)))
        elif fldvals[0]!="16":
            temp.append("incorrect #output field[0] recs[726](16): " + fldvals[0])
        elif fldvals[2]!="DE":
            temp.append("incorrect #output field[2] recs[726](DE): " + fldvals[2])
        elif fldvals[6]!="-1.00":
            temp.append("incorrect #output field[6] recs[726](-1.00): " + fldvals[6])
        elif fldvals[7]!="false":
            temp.append("incorrect #output field[7] recs[726](false): " + fldvals[7])
        elif fldvals[9]!="Idaho":
            temp.append("incorrect #output field[9] recs[726](Idaho): " + fldvals[9])

        fldvals= outrecs[1000].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[1000](11): " + str(len(fldvals)))
        elif fldvals[0]!="21":
            temp.append("incorrect #output field[0] recs[1000](21): " + fldvals[0])
        elif fldvals[2]!="WY":
            temp.append("incorrect #output field[2] recs[1000](WY): " + fldvals[2])
        elif fldvals[6]!="2980000.00":
            temp.append("incorrect #output field[6] recs[1000](2980000.00): " + fldvals[6])
        elif fldvals[7]!="true":
            temp.append("incorrect #output field[7] recs[1000](true): " + fldvals[7])
        elif fldvals[9]!="Kentucky":
            temp.append("incorrect #output field[9] recs[1000](Kentucky): " + fldvals[9])
        elif fldvals[10]!="false":
            temp.append("incorrect #output field[10] recs[1000](false): " + fldvals[10])

        if len(temp)>0:
            print("ERRORS    -------------->   FAIL")
            for s in temp:
                print(s)
        else:
            print("no problems    -------------->   OK")




        # ------------------   Test 2   -------------------------------
        # 2nd test file with broken lines causing parsing errors.
        # We use special handling attribute field.parse_error_action
        # READ DATA FILE and extract source fields from header
        file_name = "IRSMigration_WithErrors_Hdr.csv"
        file_uri= datadir + file_name
        print("TEST 2 file= " + file_name)

        srcfields=[]
        srcrecs=[]
        outfields=[]
        outrecs=[]
        hash_outfields={}

        with open(file_uri,"r",encoding="utf-8") as f:
            nline=0
            for line in f:
                if line is None:
                    break
                if line.endswith("\r\n"):
                    line=line[:-2]
                if line.endswith("\n") or line.endswith("\r"):
                    line=line[:-1]
                if len(line)>0 and not line.startswith("#") and not line.startswith("//"):
                    nline += 1
                    srcrecs.append(line)
                    if nline==1:
                        if line.find(delim_char)<1:
                            raise ValueError("first data line does not contain delimiter: " + delim_char)
                        if line.find(DQ)>-1:
                            line=line.replace(DQ,'')
                        temp= line.split(delim_char)
                        if len(temp)==0:
                            raise ValueError("no fields found with delim=" + delim_char)
                        for i in range(len(temp)):
                            srcfields.append(field.Field(temp[i]))
                            txt=temp[i].lower()
                            parse_error="" # default equivalent to code -use-
                            if txt in ["y1_statefips","y1_state","y1_state_name"]:
                                parse_error="-missing-" # string to assign to field value if parsing error
                            elif txt=="n1":
                                parse_error="-nv-"
                            elif txt=="n2":
                                parse_error="-ignore-"  # code causing parsing error to be recognized but no further action taken
                            elif txt=="agi":
                                parse_error="-999999" # value to assign
                            srcfields[i].parse_error_action= parse_error
        if len(srcfields)==0:
            raise ValueError("no source fields in file header")
        if len(srcrecs)==0:
            raise ValueError("no source records")

        # Define output fields
        for i in range(len(srcfields)):
            txt=srcfields[i].title.lower()
            dtype=""
            if txt.endswith("fips") or txt.startswith("y1_state"):
                dtype="string"
            elif txt in ["n1","n2"]:
                dtype="int"
            elif txt=="agi":
                dtype="real"
            mapto=txt
            strcase=""
            strcut=""
            strpad=""
            strpadchar=""
            strlen=-1
            fmtdate=""
            numdec=-1
            if txt=="y2_statefips":
                title="DestStateCode"
                strlen=2
                strcut="back"
                strpad="front"
                strpadchar="0"
            elif txt=="y1_statefips":
                title="OrigStateCode"
                strlen=2
                strcut="back"
                strpad="front"
                strpadchar="0"
            elif txt=="y1_state":
                title="OrigStateAbbr"
                strlen=2
                strcase="upper"
                strcut="back"
                strpad="front"
                strpadchar="hyphen"
            elif txt=="y1_state_name":
                title="OrigStateName"
            elif txt=="n1":
                title="NumReturn"
            elif txt=="n2":
                title="NumExempt"
            elif txt=="agi":
                title="GrossIncome"
                numdec=2
            else:
                title=srcfields[i].title

            outfields.append(field.Field(title))
            nfld= len(outfields)-1
            outfields[nfld].mapto=mapto
            outfields[nfld].datatype=dtype
            outfields[nfld].fmt_strlen=strlen
            outfields[nfld].fmt_strcase=strcase
            outfields[nfld].fmt_strcut=strcut
            outfields[nfld].fmt_strpad=strpad
            outfields[nfld].fmt_strpadchar=strpadchar
            outfields[nfld].fmt_date=fmtdate
            outfields[nfld].fmt_decimal=numdec
            hash_outfields[title.lower()]=nfld

        # ADD ENRICHMENT FIELDS (not in source records but will be in output records)
        outfields.append(field.Field("useAGI"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "bool"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        outfields.append(field.Field("DestStateAbbr"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "string"
        outfields[nfld].fmt_strlen= 2
        outfields[nfld].fmt_strcase= "upper"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        outfields.append(field.Field("DestStateName"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "string"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        outfields.append(field.Field("isSubTotal"))
        nfld= len(outfields)-1
        outfields[nfld].datatype= "bool"
        hash_outfields[outfields[nfld].title.lower()]=nfld

        # ------  Process Source Records --------------
        # pass settings to Refine module
        settings["has_header"]="true"
        settings["is_quoted"]="true"
        settings["normalize"]="true"
        settings["use_comment"]="false"
        settings["delim"]="comma"
        settings["delim_out"]="pipe"
        settings["embed_delim"]="_"

        outrecs= refinedata.do_refine(outfields, transforms, settings, lookups, srcfields, srcrecs)
        if len(outrecs)==0:
            raise ValueError("Refine error: no output records")
        elif outrecs[0].startswith("notok:"):
            raise ValueError("Refine error: " + outrecs[0][6:])

        # write to file
        file_out= datadir + "TestRefine_IRS_output.dat"
        with open(file_out, "w", encoding="utf-8") as f:
            for s in outrecs:
                f.write(s+"\n")

        print("Output records in: " + file_out)
        temp=[]
        nline= len(outrecs)
        if nline!=1004:
            temp.append("incorrect #output lines(1004): " + str(len(outrecs)))
        fldvals= outrecs[0].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields(11) recs[0]: " + str(len(fldvals)))
        elif fldvals[0]!="DestStateCode":
            temp.append("incorrect #output field[0](DestStateCode): " + fldvals[0])
        elif fldvals[2]!="OrigStateAbbr":
            temp.append("incorrect #output field[2](OrigStateAbbr): " + fldvals[2])
        elif fldvals[6]!="GrossIncome":
            temp.append("incorrect #output field[6](GrossIncome): " + fldvals[6])
        elif fldvals[7]!="useAGI":
            temp.append("incorrect #output field[7](useAGI): " + fldvals[7])
        elif fldvals[9]!="DestStateName":
            temp.append("incorrect #output field[9](DestStateName): " + fldvals[9])
        elif fldvals[10]!="isSubTotal":
            temp.append("incorrect #output field[10](isSubTotal): " + fldvals[10])

        fldvals= outrecs[1].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[1](11): " + str(len(fldvals)))
        elif fldvals[0]!="01":
            temp.append("incorrect #output field[0] recs[1](01): " + fldvals[0])
        elif fldvals[1]!="96":
            temp.append("incorrect #output field[1] recs[1](96): " + fldvals[1])
        elif fldvals[2]!="AL":
            temp.append("incorrect #output field[2] recs[1](AL): " + fldvals[2])
        elif fldvals[6]!="1515297000.00":
            temp.append("incorrect #output field[6] recs[1](1515297000.00): " + fldvals[6])
        elif fldvals[7]!="true":
            temp.append("incorrect #output field[7] recs[1](true): " + fldvals[7])
        elif fldvals[9]!="Alabama":
            temp.append("incorrect #output field[9] recs[1](Alabama): " + fldvals[9])
        elif fldvals[10]!="true":
            temp.append("incorrect #output field[10] recs[1](true): " + fldvals[10])

        fldvals= outrecs[5].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[5](11): " + str(len(fldvals)))
        elif fldvals[0]!="St":  # this is wrong value due to parsing
            temp.append("incorrect #output field[0] recs[5](St): " + fldvals[0])
        elif fldvals[2]!="95":
            temp.append("incorrect #output field[2] recs[5](95): " + fldvals[1])
        elif fldvals[4]!="-nv-":
            temp.append("incorrect #output field[4] recs[5](-nv-): " + fldvals[2])
        elif fldvals[5]!="":
            temp.append("incorrect #output field[5] recs[5](''): " + fldvals[10])
        elif fldvals[6]!="-999999":
            temp.append("incorrect #output field[6] recs[5](-999999): " + fldvals[6])
        elif fldvals[7]!="true":
            temp.append("incorrect #output field[7] recs[5](true): " + fldvals[7])
        elif fldvals[9]!="te":
            temp.append("incorrect #output field[9] recs[5](te): " + fldvals[9])

        fldvals= outrecs[7].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[7](11): " + str(len(fldvals)))
        elif fldvals[0]!="No":  # this is wrong value due to parsing
            temp.append("incorrect #output field[0] recs[7](No): " + fldvals[0])
        elif fldvals[2]!="-missing-":
            temp.append("incorrect #output field[2] recs[7](-missing-): " + fldvals[1])
        elif fldvals[4]!="-nv-":
            temp.append("incorrect #output field[4] recs[7](-nv-): " + fldvals[2])
        elif fldvals[5]!="":
            temp.append("incorrect #output field[5] recs[7](''): " + fldvals[10])
        elif fldvals[6]!="-999999":
            temp.append("incorrect #output field[6] recs[7](-999999): " + fldvals[6])
        elif fldvals[7]!="true":
            temp.append("incorrect #output field[7] recs[7](true): " + fldvals[7])
        elif fldvals[9]!="n-":
            temp.append("incorrect #output field[9] recs[7](n-): " + fldvals[9])

        fldvals= outrecs[14].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[14](11): " + str(len(fldvals)))
        elif fldvals[0]!="01":
            temp.append("incorrect #output field[0] recs[14](01): " + fldvals[0])
        elif fldvals[2]!="CA":
            temp.append("incorrect #output field[2] recs[14](CA): " + fldvals[2])
        elif fldvals[6]!="55689000.00":
            temp.append("incorrect #output field[6] recs[14](55689000.00): " + fldvals[6])
        elif fldvals[7]!="true":
            temp.append("incorrect #output field[7] recs[14](true): " + fldvals[7])
        elif fldvals[9]!="Alabama":
            temp.append("incorrect #output field[9] recs[14](Alabama): " + fldvals[9])

        fldvals= outrecs[17].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[17](11): " + str(len(fldvals)))
        elif fldvals[0]!="01":
            temp.append("incorrect #output field[0] recs[17](01): " + fldvals[0])
        elif fldvals[2]!="FR":
            temp.append("incorrect #output field[2] recs[17](FR): " + fldvals[2])
        elif fldvals[6]!="48079000.00":
            temp.append("incorrect #output field[6] recs[17](48079000.00): " + fldvals[6])
        elif fldvals[7]!="true":
            temp.append("incorrect #output field[7] recs[17](true): " + fldvals[7])
        elif fldvals[9]!="Alabama":
            temp.append("incorrect #output field[9] recs[17](Alabama): " + fldvals[9])

        fldvals= outrecs[729].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[729](11): " + str(len(fldvals)))
        elif fldvals[0]!="16":
            temp.append("incorrect #output field[0] recs[729](16): " + fldvals[0])
        elif fldvals[2]!="DE":
            temp.append("incorrect #output field[2] recs[729](DE): " + fldvals[2])
        elif fldvals[6]!="-1.00":
            temp.append("incorrect #output field[6] recs[729](-1.00): " + fldvals[6])
        elif fldvals[7]!="false":
            temp.append("incorrect #output field[7] recs[729](false): " + fldvals[7])
        elif fldvals[9]!="Idaho":
            temp.append("incorrect #output field[9] recs[729](Idaho): " + fldvals[9])

        fldvals= outrecs[1003].split("|")
        if len(fldvals)!=11:
            temp.append("incorrect #output fields recs[1003](11): " + str(len(fldvals)))
        elif fldvals[0]!="21":
            temp.append("incorrect #output field[0] recs[1003](21): " + fldvals[0])
        elif fldvals[2]!="WY":
            temp.append("incorrect #output field[2] recs[1003](WY): " + fldvals[2])
        elif fldvals[6]!="2980000.00":
            temp.append("incorrect #output field[6] recs[1003](2980000.00): " + fldvals[6])
        elif fldvals[7]!="true":
            temp.append("incorrect #output field[7] recs[1003](true): " + fldvals[7])
        elif fldvals[9]!="Kentucky":
            temp.append("incorrect #output field[9] recs[1003](Kentucky): " + fldvals[9])
        elif fldvals[10]!="false":
            temp.append("incorrect #output field[10] recs[1003](false): " + fldvals[10])

        if len(temp)>0:
            print("ERRORS    -------------->   FAIL")
            for s in temp:
                print(s)
        else:
            print("no problems    -------------->   OK")

    except (ValueError, RuntimeError, OSError) as err:
        print("ERROR! " + str(err))


if __name__=="__main__":
    do_refine()
