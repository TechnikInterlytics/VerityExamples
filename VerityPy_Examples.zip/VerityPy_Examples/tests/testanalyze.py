#!/usr/bin/env python
"""
Test Analyze

Run variety of tests to functions in analyzequality module
"""


__all__ = []
__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240724'

import os
import datetime
from VerityPy.processing import analyzequality, qualityanalysis, field
from VerityPy.utils import reportfuncs

DQ:str="\""


def do_test_analyze():
    """
    Test analyze quality function in analyzequality.py.
    """

    file_uri:str=""
    file_out_uri:str=""
    file_name:str=""
    curdir:str=""
    dir_delim:str=""
    delim_char:str=","
    txt:str=""
    fld:dict={}
    recs:list=[]
    fields:list=[]
    hash_fields:dict={}
    covalues:list=[]
    nline:int=-1
    settings:dict={}
    report:qualityanalysis.QualityAnalysis= qualityanalysis.QualityAnalysis()
    report_from_file:qualityanalysis.QualityAnalysis= qualityanalysis.QualityAnalysis()
    temp:list=[]
    errs:list=[]
    try:
        print("TEST ANALYZE QUALITY\n")
        print("Current dateTime= " + str(datetime.date.today()))

        curdir= os.path.dirname(os.path.realpath(__file__))
        print("file dir=" + curdir)
        if "\\" in curdir:
            dir_delim="\\"
        else:
            dir_delim="/"
        if curdir.endswith(dir_delim + "tests"):
            curdir=curdir[:-6]
        if not curdir.endswith(dir_delim):
            curdir += dir_delim
        curdir += "files" + dir_delim
        file_name="IRSMigration_WithErrors_Hdr.csv"
        file_uri=curdir + file_name
        with open(file_uri, "r", encoding="utf-8") as f:
            nline=0
            for line in f:
                if line is None:
                    break
                if line.endswith("\r\n"):
                    line=line[:-2]
                if line.endswith("\n") or line.endswith("\r"):
                    line=line[:-1]
                if len(line)>0 and not line.startswith("#") and not line.startswith("//"):
                    nline += 1
                    if nline==1:
                        if line.find(delim_char)<1:
                            raise ValueError("first data line does not contain delimiter: " + delim_char)
                        if line.find(DQ)>-1:
                            line=line.replace(DQ,'')
                        temp= line.split(delim_char)
                        if len(temp)==0:
                            raise ValueError("no fields found with delim=" + delim_char)
                        for i in range(len(temp)):
                            fields.append(field.Field(temp[i]))
                    else:
                        recs.append(line)
        if len(fields)==0:
            raise ValueError("no fields")
        settings["is_case_sens"]="false"
        settings["is_quoted"]="true"
        settings["has_header"]="false"
        settings["extract_fields"]="false"
        settings["delim"]="comma"
        settings["maxuv"]="100"
        covalues.append("y1_state,y1_state_name")
        # assign datatypes and formats
        for i in range(len(fields)):
            fld= fields[i].title.lower()
            if fld in ["y2_statefips","y1_statefips"]:
                fields[i].datatype="string"
                fields[i].fmt_strlen=2
            elif fld=="y1_state":
                fields[i].datatype="string"
                fields[i].fmt_strcase="upper"
                fields[i].fmt_strlen=2
            elif fld=="y1_state_name":
                fields[i].datatype="string"
            elif fld in ["n1","n2","agi"]:
                fields[i].datatype="int"
        
        # send to analysis function and receive report object
        report=analyzequality.do_qualityinspect(fields, covalues, recs, settings)
        if report.status.startswith("notok:"):
            raise ValueError("error from report:" + report.status[6:])
        report.title=file_name
        
        file_out_uri=file_uri[:file_uri.find(".")] + "_report.dat"
        txt= reportfuncs.save_report_to_file(file_out_uri, report)
        if txt.startswith("notok:"):
            raise ValueError(txt[6:])
        print("Report in: " + file_out_uri)

        if len(report.fields) != len(fields):
            errs.append("incorrect #fields " + str(len(report.fields)) + "/" + str(len(fields)))
        if report.numrecs != 1003:
            errs.append("incorrect #recs " + str(report.numrecs) + "/1003")
        if "numrecs_err" not in report.err_stats or report.err_stats["numrecs_err"] !=19:
            errs.append("incorrect numrecs_err [act=19]")
        if "numrecs_err_datatype" not in report.err_stats or report.err_stats["numrecs_err_datatype"] !=14:
            errs.append("incorrect numrecs_err_datatype [act=14]")
        if "numrecs_err_fmt" not in report.err_stats or report.err_stats["numrecs_err_fmt"] !=9:
            errs.append("incorrect numrecs_err_fmt [act=9]")
        if "fields_err_datatype" not in report.err_stats or len(report.err_stats["fields_err_datatype"]) !=3:
            errs.append("incorrect #fields_err_datatype [act=3]")
        if "fields_err_fmt" not in report.err_stats or len(report.err_stats["fields_err_fmt"]) !=3:
            errs.append("incorrect #fields_err_fmt [act=3]")

        if len(report.field_datatype_dist) != len(report.fields):
            errs.append("incorrect #field_datatype_dist " + str(len(report.field_datatype_dist)) + "/" + str(len(report.fields)))
        elif report.field_datatype_dist[4]["int"] != 998:
            errs.append("incorrect #field_datatype_dist[4][int] " + str(report.field_datatype_dist[4]["int"]) + "/998")
        elif report.field_datatype_dist[4]["empty"] != 5:
            errs.append("incorrect #field_datatype_dist[4][empty] " + str(report.field_datatype_dist[4]["empty"]) + "/5")

        if len(report.field_uniqvals) != len(report.fields):
            errs.append("incorrect #field_uniqvals " + str(len(report.field_uniqvals)) + "/" + str(len(report.fields)))
        elif len(report.field_uniqvals[1])==0:
            errs.append("incorrect #field_uniqvals[1]=0")
        elif report.field_uniqvals[1][1][0]!="96":
            errs.append("missing uv 96 in field_uniqvals[1][1]")
        elif report.field_uniqvals[1][1][1]!=18:
            errs.append("incorrect uv count field_uniqvals[1][1] " + str(report.field_uniqvals[1][1][1]) + "/18")

        if len(report.spec_char_dist) != 4:
            errs.append("incorrect #spec_char_dist " + str(len(report.spec_char_dist)) + "/4")
        elif "unicode_8252" not in report.spec_char_dist:
            errs.append("missing dict key=unicode_8252 in spec_char_dist")
        elif report.spec_char_dist["unicode_8252"]!=1:
            errs.append("incorrect spec_char_dist[unicode_8252] " + str(report.spec_char_dist["unicode_8252"]) + "/1")

        if len(report.rec_size_dist) == 0:
            errs.append("incorrect #rec_size_dist=0")
        elif "31" not in report.rec_size_dist:
            errs.append("missing dict key=31 in rec_size_dist")
        elif report.rec_size_dist["31"]!=119:
            errs.append("incorrect rec_size_dist[31] " + str(report.rec_size_dist["31"]) + "/119")

        if len(report.rec_parse_dist) != 3:
            errs.append("incorrect #rec_parse_dist " + str(len(report.rec_parse_dist)) + "/3")
        elif "7" not in report.rec_parse_dist:
            errs.append("missing dict key=7 in rec_parse_dist")
        elif report.rec_parse_dist["7"]!=998:
            errs.append("incorrect rec_parse_dist[7] " + str(report.rec_parse_dist["7"]) + "/998")

        if "small1" not in report.rec_parse_errs:
            errs.append("missing dict key=small1 in rec_parse_errs")
        elif report.rec_parse_errs["small1"]!=0:
            errs.append("incorrect rec_parse_errs[small1] " + str(report.rec_parse_errs["small1"]) + "/0")
        if "small2" not in report.rec_parse_errs:
            errs.append("missing dict key=small2 in rec_parse_errs")
        elif report.rec_parse_errs["small2"]!=5:
            errs.append("incorrect rec_parse_errs[small2] " + str(report.rec_parse_errs["small2"]) + "/5")
        if "big" not in report.rec_parse_errs:
            errs.append("missing dict key=big in rec_parse_errs")
        elif report.rec_parse_errs["big"]!=0:
            errs.append("incorrect rec_parse_errs[big] " + str(report.rec_parse_errs["big"]) + "/0")
        if "small2_recs" not in report.rec_parse_errs:
            errs.append("missing dict key=small2_recs in rec_parse_errs")
        elif len(report.rec_parse_errs["small2_recs"])!=5:
            errs.append("incorrect rec_parse_errs[small2_recs] " + str(len(report.rec_parse_errs["small2_recs"])) + "/5")

        if len(report.covalues) != 1:
            errs.append("incorrect #covalues " + str(len(report.covalues)) + "/1")
        elif len(report.covalue_uniqvals) != 1:
            errs.append("incorrect #covalue_uniqvals " + str(len(report.covalue_uniqvals)) + "/1")
        elif report.covalue_uniqvals[0][4][0]!="nc_north carolina":
            errs.append("missing dict key=nc_north carolina in covalue_uniqvals[0][4]")

        if len(report.field_quality) != len(report.fields):
            errs.append("incorrect #field_quality " + str(len(report.field_quality)) + "/" + str(len(report.fields)))
        elif report.field_quality[0] != "95.2":
            errs.append("incorrect #field_quality[0] " + str(report.field_quality[4]) + "/95.2")
        elif report.field_quality[4] != "99.5":
            errs.append("incorrect #field_quality[4] " + str(report.field_quality[4]) + "/99.5")
        elif report.field_quality[6] != "97.8":
            errs.append("incorrect #field_quality[6] " + str(report.field_quality[6]) + "/97.8")

        if len(report.spec_char_examples)!=4:
            errs.append("incorrect #spec char examples " + str(len(report.spec_char_examples)) + "/4")
        elif report.spec_char_examples[1]!="(25)[AGI:unicode_8252]01,08,CO,Colorado,473,932,24958‼":
            errs.append("incorrect #spec char examples[1]:" + report.spec_char_examples[1])

        if len(report.err_datatype_examples)!=14:
            errs.append("incorrect #err_datatype_examples " + str(len(report.err_datatype_examples)) + "/14")
        elif report.err_datatype_examples[1]!="(4)[n1:empty:-empty-]|[n2:empty:-empty-]|[agi:empty:-empty-]":
            errs.append("incorrect #err_datatype_examples[1]:" + report.err_datatype_examples[1])

        if len(report.err_fmt_examples)!=9:
            errs.append("incorrect #err_fmt_examples " + str(len(report.err_fmt_examples)) + "/9")
        elif report.err_fmt_examples[1]!="(7)[y2_statefips:string incorrect length:Non-]|[y1_statefips:string incorrect length:-empty-]|[y1_state:string incorrect length:-empty-]":
            errs.append("incorrect #err_fmt_examples[1]:" + report.err_fmt_examples[1])

        if len(errs)>0:
            print("Analyze Quality with Fields has Errors -->  FAIL")
            for i in range(len(errs)):
                print("Error " + str(i) + ": " + errs[i])
        else:
            print("Analyze Quality using Fields list has 0 Errors -->  OK")



        # set to extract fields which causes submitted fields list to be ignored
        settings["extract_fields"]=True
        settings["has_header"]=True
        errs=[]
        txt=""
        for i in range(len(fields)):
            if i>0:
                txt += ","
            txt += fields[i].title

        recs.insert(0, txt)
        report=analyzequality.do_qualityinspect(fields, covalues, recs, settings)
        if report.status.startswith("notok:"):
            raise ValueError("error from report:" + report.status[6:])
        report.title=file_name

        file_out_uri=file_uri[:file_uri.find(".")] + "_report_extractfields.dat"
        txt= reportfuncs.save_report_to_file(file_out_uri, report)
        if txt.startswith("notok:"):
            raise ValueError(txt[6:])
        print("Report in: " + file_out_uri)

        hash_fields={}
        if len(report.fields) != 7:
            errs.append("incorrect #fields " + str(len(report.fields)) + "/7")
        for i in range(len(report.fields)):
            hash_fields[report.fields[i].title]=i
        for i in range(len(fields)):
            if fields[i].title not in hash_fields:
                errs.append("field missing in report: " + fields[i].title)

        if report.numrecs != 1003:
            errs.append("incorrect #recs " + str(report.numrecs) + "/1003")
        if "numrecs_err" not in report.err_stats or report.err_stats["numrecs_err"] !=19:
            errs.append("incorrect numrecs_err [act=19]")
        if "numrecs_err_datatype" not in report.err_stats or report.err_stats["numrecs_err_datatype"] !=14:
            errs.append("incorrect numrecs_err_datatype [act=14]")
        if "numrecs_err_fmt" not in report.err_stats or report.err_stats["numrecs_err_fmt"] !=9:
            errs.append("incorrect numrecs_err_fmt [act=9]")
        if "fields_err_datatype" not in report.err_stats or len(report.err_stats["fields_err_datatype"]) !=3:
            errs.append("incorrect #fields_err_datatype [act=3]")
        if "fields_err_fmt" not in report.err_stats or len(report.err_stats["fields_err_fmt"]) !=3:
            errs.append("incorrect #fields_err_fmt [act=3]")

        if len(report.field_datatype_dist) != len(report.fields):
            errs.append("incorrect #field_datatype_dist " + str(len(report.field_datatype_dist)) + "/" + str(len(report.fields)))
        elif report.field_datatype_dist[4]["int"] != 998:
            errs.append("incorrect #field_datatype_dist[4][int] " + str(report.field_datatype_dist[4]["int"]) + "/998")
        elif report.field_datatype_dist[4]["empty"] != 5:
            errs.append("incorrect #field_datatype_dist[4][empty] " + str(report.field_datatype_dist[4]["empty"]) + "/5")

        if len(report.field_uniqvals) != 7:
            errs.append("incorrect #field_uniqvals " + str(len(report.field_uniqvals)) + "/7")
        elif len(report.field_uniqvals[1])==0:
            errs.append("incorrect #field_uniqvals[1]=0")
        elif report.field_uniqvals[1][1][0]!="96":
            errs.append("missing uv 96 in field_uniqvals[1][1]")
        elif report.field_uniqvals[1][1][1]!=18:
            errs.append("incorrect uv count field_uniqvals[1][1] " + str(report.field_uniqvals[1][1][1]) + "/18")

        if len(report.spec_char_dist) != 4:
            errs.append("incorrect #spec_char_dist " + str(len(report.spec_char_dist)) + "/4")
        elif "unicode_8252" not in report.spec_char_dist:
            errs.append("missing dict key=unicode_8252 in spec_char_dist")
        elif report.spec_char_dist["unicode_8252"]!=1:
            errs.append("incorrect spec_char_dist[unicode_8252] " + str(report.spec_char_dist["unicode_8252"]) + "/1")

        if len(report.rec_size_dist) == 0:
            errs.append("incorrect #rec_size_dist=0")
        elif "31" not in report.rec_size_dist:
            errs.append("missing dict key=31 in rec_size_dist")
        elif report.rec_size_dist["31"]!=119:
            errs.append("incorrect rec_size_dist[31] " + str(report.rec_size_dist["31"]) + "/119")

        if len(report.rec_parse_dist) != 3:
            errs.append("incorrect #rec_parse_dist " + str(len(report.rec_parse_dist)) + "/3")
        elif "7" not in report.rec_parse_dist:
            errs.append("missing dict key=7 in rec_parse_dist")
        elif report.rec_parse_dist["7"]!=998:
            errs.append("incorrect rec_parse_dist[7] " + str(report.rec_parse_dist["7"]) + "/998")

        if "small2" not in report.rec_parse_errs:
            errs.append("missing dict key=small2 in rec_parse_errs")
        elif report.rec_parse_errs["small2"]!=5:
            errs.append("incorrect rec_parse_errs[small2] " + str(report.rec_parse_errs["small2"]) + "/5")

        if len(report.covalues) != 1:
            errs.append("incorrect #covalues " + str(len(report.covalues)) + "/1")
        elif len(report.covalue_uniqvals) != 1:
            errs.append("incorrect #covalue_uniqvals " + str(len(report.covalue_uniqvals)) + "/1")
        elif report.covalue_uniqvals[0][4][0]!="nc_north carolina":
            errs.append("missing dict key=nc_north carolina in covalue_uniqvals[0][4]")

        if len(report.field_quality) != len(report.fields):
            errs.append("incorrect #field_quality " + str(len(report.field_quality)) + "/" + str(len(report.fields)))
        elif report.field_quality[0] != "95.2":
            errs.append("incorrect #field_quality[0] " + str(report.field_quality[4]) + "/95.2")
        elif report.field_quality[4] != "99.5":
            errs.append("incorrect #field_quality[4] " + str(report.field_quality[4]) + "/99.5")
        elif report.field_quality[6] != "97.8":
            errs.append("incorrect #field_quality[6] " + str(report.field_quality[6]) + "/97.8")

        if len(report.spec_char_examples)!=4:
            errs.append("incorrect #spec char examples " + str(len(report.spec_char_examples)) + "/4")
        elif report.spec_char_examples[1]!="(26)[AGI:unicode_8252]01,08,CO,Colorado,473,932,24958‼":
            errs.append("incorrect spec char examples[1]:" + report.spec_char_examples[1])

        if len(report.err_datatype_examples)!=14:
            errs.append("incorrect #err_datatype_examples " + str(len(report.err_datatype_examples)) + "/14")
        elif report.err_datatype_examples[1]!="(5)[n1:empty:-empty-]|[n2:empty:-empty-]|[agi:empty:-empty-]":
            errs.append("incorrect err_datatype_examples[1]:" + report.err_datatype_examples[1])

        if len(report.err_fmt_examples)!=9:
            errs.append("incorrect #err_fmt_examples " + str(len(report.err_fmt_examples)) + "/9")
        elif report.err_fmt_examples[1]!="(8)[y2_statefips:string incorrect length:Non-]|[y1_statefips:string incorrect length:-empty-]|[y1_state:string incorrect length:-empty-]":
            errs.append("incorrect err_fmt_examples[1]:" + report.err_fmt_examples[1])

        if len(errs)>0:
            print("Analyze Quality Extract Fields has Errors -->  FAIL")
            for i in range(len(errs)):
                print("Error " + str(i) + ": " + errs[i])
        else:
            print("Analyze Quality with Extract Fields has 0 Errors -->  OK")



        print("--------------  READ REPORT FROM FILE -------------")
        report_from_file= reportfuncs.make_report_from_file(file_out_uri)
        if report_from_file.status.startswith("notok:"):
            raise ValueError(report_from_file.status[6:])
        print("Read report from: " + file_out_uri)

        errs=[]
        hash_fields={}
        if len(report_from_file.fields) != 7:
            errs.append("incorrect #fields " + str(len(report_from_file.fields)) + "/7")
        for i in range(len(report_from_file.fields)):
            hash_fields[report_from_file.fields[i].title]=i
        for i in range(len(fields)):
            if fields[i].title not in hash_fields:
                errs.append("field missing in report_from_file: " + fields[i].title)

        if report_from_file.numrecs != 1003:
            errs.append("incorrect #recs " + str(report_from_file.numrecs) + "/1003")
        if "numrecs_err" not in report_from_file.err_stats or report_from_file.err_stats["numrecs_err"] !=19:
            errs.append("incorrect numrecs_err [act=19]")
        if "numrecs_err_datatype" not in report_from_file.err_stats or report_from_file.err_stats["numrecs_err_datatype"] !=14:
            errs.append("incorrect numrecs_err_datatype [act=14]")
        if "numrecs_err_fmt" not in report_from_file.err_stats or report_from_file.err_stats["numrecs_err_fmt"] !=9:
            errs.append("incorrect numrecs_err_fmt [act=9]")
        if "fields_err_datatype" not in report_from_file.err_stats or len(report_from_file.err_stats["fields_err_datatype"]) !=3:
            errs.append("incorrect #fields_err_datatype [act=3]")
        if "fields_err_fmt" not in report_from_file.err_stats or len(report_from_file.err_stats["fields_err_fmt"]) !=3:
            errs.append("incorrect #fields_err_fmt [act=3]")

        if len(report_from_file.field_datatype_dist) != len(report_from_file.fields):
            errs.append("incorrect #field_datatype_dist " + str(len(report_from_file.field_datatype_dist)) + "/" + str(len(report_from_file.fields)))
        elif report_from_file.field_datatype_dist[4]["int"] != 998:
            errs.append("incorrect #field_datatype_dist[4][int] " + str(report_from_file.field_datatype_dist[4]["int"]) + "/998")
        elif report_from_file.field_datatype_dist[4]["empty"] != 5:
            errs.append("incorrect #field_datatype_dist[4][empty] " + str(report_from_file.field_datatype_dist[4]["empty"]) + "/5")

        if len(report_from_file.field_uniqvals) != 7:
            errs.append("incorrect #field_uniqvals " + str(len(report_from_file.field_uniqvals)) + "/7")
        elif len(report_from_file.field_uniqvals[1])==0:
            errs.append("incorrect #field_uniqvals[1]=0")
        elif report.field_uniqvals[1][1][0]!="96":
            errs.append("missing uv 96 in field_uniqvals[1][1]")
        elif report.field_uniqvals[1][1][1]!=18:
            errs.append("incorrect uv count field_uniqvals[1][1] " + str(report.field_uniqvals[1][1][1]) + "/18")

        if len(report_from_file.spec_char_dist) != 4:
            errs.append("incorrect #spec_char_dist " + str(len(report_from_file.spec_char_dist)) + "/4")
        elif "unicode_8252" not in report_from_file.spec_char_dist:
            errs.append("missing dict key=unicode_8252 in spec_char_dist")
        elif report_from_file.spec_char_dist["unicode_8252"]!=1:
            errs.append("incorrect spec_char_dist[unicode_8252] " + str(report_from_file.spec_char_dist["unicode_8252"]) + "/1")

        if len(report_from_file.rec_size_dist) == 0:
            errs.append("incorrect #rec_size_dist=0")
        elif "31" not in report_from_file.rec_size_dist:
            errs.append("missing dict key=31 in rec_size_dist")
        elif report_from_file.rec_size_dist["31"]!=119:
            errs.append("incorrect rec_size_dist[31] " + str(report_from_file.rec_size_dist["31"]) + "/119")

        if len(report_from_file.rec_parse_dist) != 3:
            errs.append("incorrect #rec_parse_dist " + str(len(report_from_file.rec_parse_dist)) + "/3")
        elif "7" not in report_from_file.rec_parse_dist:
            errs.append("missing dict key=7 in rec_parse_dist")
        elif report_from_file.rec_parse_dist["7"]!=998:
            errs.append("incorrect rec_parse_dist[7] " + str(report_from_file.rec_parse_dist["7"]) + "/998")

        if "small2" not in report_from_file.rec_parse_errs:
            errs.append("missing dict key=small2 in rec_parse_errs")
        elif report_from_file.rec_parse_errs["small2"]!=5:
            errs.append("incorrect rec_parse_errs[small2] " + str(report_from_file.rec_parse_errs["small2"]) + "/5")
        elif "small2_recs" not in report_from_file.rec_parse_errs:
            errs.append("missing dict key=small2_recs in rec_parse_errs")

        if len(report_from_file.covalues) != 1:
            errs.append("incorrect #covalues " + str(len(report_from_file.covalues)) + "/1")
        elif report_from_file.covalues[0].title !="y1_state,y1_state_name":
            errs.append("incorrect covalue[0].title " + report_from_file.covalues[0].title + "/y1_state,y1_state_name")
        elif report_from_file.covalues[0].numfields !=2:
            errs.append("incorrect covalue[0].numfields " + str(report_from_file.covalues[0].numfields) + "/2")
        elif len(report_from_file.covalue_uniqvals) != 1:
            errs.append("incorrect #covalue_uniqvals " + str(len(report_from_file.covalue_uniqvals)) + "/1")
        elif report.covalue_uniqvals[0][4][0]!="nc_north carolina":
            errs.append("missing dict key=nc_north carolina in covalue_uniqvals[0][4]")
        elif report.covalue_uniqvals[0][4][1]!=18:
            errs.append("incorrect covalue_uniqvals[0][4]: " + str(report_from_file.covalue_uniqvals[0][4][1]) + "/18")

        if len(report_from_file.field_quality) != len(report_from_file.fields):
            errs.append("incorrect #field_quality " + str(len(report_from_file.field_quality)) + "/" + str(len(report_from_file.fields)))
        elif report_from_file.field_quality[0] != "95.2":
            errs.append("incorrect #field_quality[0] " + str(report_from_file.field_quality[4]) + "/95.2")
        elif report_from_file.field_quality[4] != "99.5":
            errs.append("incorrect #field_quality[4] " + str(report_from_file.field_quality[4]) + "/99.5")
        elif report_from_file.field_quality[6] != "97.8":
            errs.append("incorrect #field_quality[6] " + str(report_from_file.field_quality[6]) + "/97.8")

        if len(report.spec_char_examples)!=4:
            errs.append("incorrect #spec char examples " + str(len(report.spec_char_examples)) + "/4")
        elif report.spec_char_examples[1]!="(26)[AGI:unicode_8252]01,08,CO,Colorado,473,932,24958‼":
            errs.append("incorrect spec char examples[1]:" + report.spec_char_examples[1])

        if len(report.err_datatype_examples)!=14:
            errs.append("incorrect #err_datatype_examples " + str(len(report.err_datatype_examples)) + "/14")
        elif report.err_datatype_examples[1]!="(5)[n1:empty:-empty-]|[n2:empty:-empty-]|[agi:empty:-empty-]":
            errs.append("incorrect err_datatype_examples[1]:" + report.err_datatype_examples[1])

        if len(report.err_fmt_examples)!=9:
            errs.append("incorrect #err_fmt_examples " + str(len(report.err_fmt_examples)) + "/9")
        elif report.err_fmt_examples[1]!="(8)[y2_statefips:string incorrect length:Non-]|[y1_statefips:string incorrect length:-empty-]|[y1_state:string incorrect length:-empty-]":
            errs.append("incorrect err_fmt_examples[1]:" + report.err_fmt_examples[1])

        if len(errs)>0:
            print("Errors -->  FAIL")
            for i in range(len(errs)):
                print("Error " + str(i) + ": " + errs[i])
        else:
            print("No Problems -->  OK")

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR: " + str(err))

if __name__=="__main__":
    do_test_analyze()
