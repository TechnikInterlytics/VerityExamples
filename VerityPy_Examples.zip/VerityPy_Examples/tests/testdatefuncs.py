#!/usr/bin/env python
"""
Test Date Functions

Run variety of test to functions in datefuncs module
"""


__all__ = ['do_test_dates']

__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240619'

from VerityPy.processing import datefuncs


def do_test_dates():
    """
    Run variety of test calls to Date functions and check responses.
    """


    print("TEST DATE FUNCTIONS\n")

    # note: for import to work while doing local debugging there should be launch.json with setting for:
    # "env": {"PYTHONPATH": "${workspaceRoot}"}, within the configuration used

    dt:str=""
    fmt:str=""
    resexp:str=""
    resact:str=""
    status:str=""

    print("Test: get_current_iso_datetime")
    dt=datefuncs.get_current_iso_datetime(True)
    print("Current dateTime= " + dt)
    dt=datefuncs.get_current_iso_datetime(True, "-5")
    print("Current dateTime (tz= -5) = " + dt)
    dt=datefuncs.get_current_iso_datetime(True, "5.5")
    print("Current dateTime (tz= +5.5) = " + dt)

    print("\nTest: is_iso_date_str")
    resact=datefuncs.is_iso_date_str(dt, True)
    status= "OK" if resact.startswith("true") else "FAIL"
    print("dt=" + dt + ", Result(timereq=T)=" + resact + " -->" + status)
    resact=datefuncs.is_iso_date_str(dt, False)
    status= "OK" if resact.startswith("true") else "FAIL"
    print("dt=" + dt + ", Result(timereq=F)=" + resact + " -->" + status)

    dt=datefuncs.get_current_iso_datetime(False)
    resact=datefuncs.is_iso_date_str(dt, True)
    status= "OK" if resact.startswith("false") else "FAIL"
    print("dt=" + dt + ", Result(timereq=T)=" + resact + " -->" + status)
    resact=datefuncs.is_iso_date_str(dt, False)
    status= "OK" if resact.startswith("true") else "FAIL"
    print("dt=" + dt + ", Result(timereq=F)=" + resact + " -->" + status)

    print("\nTest: convert_excel_date_to_iso")
    for i in range(4):
        if i==0:
            dt="21012"
            resexp="19570711"
        elif i==1:
            dt="45393"
            resexp="20240411"
        elif i==2:
            dt="1"
            resexp="19000101"
        elif i==3:
            dt="-5"
            resexp="notok"
        resact=datefuncs.convert_excel_date_to_iso(dt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ", Result [" + resexp + "]=" + resact + " -->" + status)


    print("\nTest: is_year_leap")
    for i in range(4):
        if i==0:
            dt="2024"
            resexp="True"
        elif i==1:
            dt="2023"
            resexp="False"
        elif i==2:
            dt="2000"
            resexp="True"
        elif i==3:
            dt="1900"
            resexp="False"
        resact=str(datefuncs.is_year_leap(int(dt)))
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("dt=" + dt + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: convert_date_to_iso")
    # * format
    dt="1112024"
    fmt="dd*myyyy"
    resexp="20240111"
    resact=datefuncs.convert_date_to_iso(dt,fmt)
    status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
    resexp="true"
    resact = str(datefuncs.is_date_format(dt,fmt)).lower()
    status ="OK" if resexp==resact else "FAIL"
    print("IsDateFormat --> " + status)

    # mmddyy
    fmt="mmddyy"
    for i in range(5):
        if i==0:
            dt="071175"
            resexp="19750711"
        elif i==1:
            dt="111924"
            resexp="20241119"
        elif i==2:
            dt="131924"
            resexp="notok"
        elif i==3:
            dt="114924"
            resexp="notok"
        elif i==4:
            dt="11192024"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # mmddyyyy
    fmt="mmddyyyy"
    for i in range(4):
        if i==0:
            dt="07111957"
            resexp="19570711"
        elif i==1:
            dt="11192024"
            resexp="20241119"
        elif i==2:
            dt="13192024"
            resexp="notok"
        elif i==3:
            dt="11492024"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # mmdyy
    fmt="mmdyy"
    for i in range(4):
        if i==0:
            dt="07175"
            resexp="19750701"
        elif i==1:
            dt="11924"
            resexp="20241109"
        elif i==2:
            dt="13924"
            resexp="notok"
        elif i==3:
            dt="11192024"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # mmdyyyy
    fmt="mmdyyyy"
    for i in range(4):
        if i==0:
            dt="0711957"
            resexp="19570701"
        elif i==1:
            dt="1192024"
            resexp="20241109"
        elif i==2:
            dt="13924"
            resexp="notok"
        elif i==3:
            dt="1592024"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # mddyy
    fmt="mddyy"
    for i in range(5):
        if i==0:
            dt="71157"
            resexp="20570711"
        elif i==1:
            dt="71175"
            resexp="19750711"
        elif i==2:
            dt="01175"
            resexp="notok"
        elif i==3:
            dt="74175"
            resexp="notok"
        elif i==4:
            dt="7111975"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # mddyyyy
    fmt="mddyyyy"
    for i in range(5):
        if i==0:
            dt="7112057"
            resexp="20570711"
        elif i==1:
            dt="7111975"
            resexp="19750711"
        elif i==2:
            dt="0111975"
            resexp="notok"
        elif i==3:
            dt="7411975"
            resexp="notok"
        elif i==4:
            dt="71175"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # mdyy
    fmt="mdyy"
    for i in range(4):
        if i==0:
            dt="7157"
            resexp="20570701"
        elif i==1:
            dt="5575"
            resexp="19750505"
        elif i==2:
            dt="0975"
            resexp="notok"
        elif i==3:
            dt="0712057"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # mdyyyy
    fmt="mdyyyy"
    for i in range(4):
        if i==0:
            dt="712057"
            resexp="20570701"
        elif i==1:
            dt="551975"
            resexp="19750505"
        elif i==2:
            dt="01975"
            resexp="notok"
        elif i==3:
            dt="0712057"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # ddmmyy
    fmt="ddmmyy"
    for i in range(5):
        if i==0:
            dt="111224"
            resexp="20241211"
        elif i==1:
            dt="110124"
            resexp="20240111"
        elif i==2:
            dt="110024"
            resexp="notok"
        elif i==3:
            dt="112124"
            resexp="notok"
        elif i==4:
            dt="1112024"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # ddmmyyyy
    fmt="ddmmyyyy"
    for i in range(5):
        if i==0:
            dt="11122024"
            resexp="20241211"
        elif i==1:
            dt="11012024"
            resexp="20240111"
        elif i==2:
            dt="11002024"
            resexp="notok"
        elif i==3:
            dt="11212024"
            resexp="notok"
        elif i==4:
            dt="4112024"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # ddmyy
    fmt="ddmyy"
    for i in range(4):
        if i==0:
            dt="11224"
            resexp="20240211"
        elif i==1:
            dt="31224"
            resexp="notok"
        elif i==2:
            dt="11024"
            resexp="notok"
        elif i==3:
            dt="1122024"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # ddmyyyy
    fmt="ddmyyyy"
    for i in range(4):
        if i==0:
            dt="1112024"
            resexp="20240111"
        elif i==1:
            dt="2191975"
            resexp="19750921"
        elif i==2:
            dt="4112024"
            resexp="notok"
        elif i==3:
            dt="2101975"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # dmmyy
    fmt="dmmyy"
    for i in range(4):
        if i==0:
            dt="11024"
            resexp="20241001"
        elif i==1:
            dt="10524"
            resexp="20240501"
        elif i==2:
            dt="00524"
            resexp="notok"
        elif i==3:
            dt="13524"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # dmmyyyy
    fmt="dmmyyyy"
    for i in range(4):
        if i==0:
            dt="1112024"
            resexp="20241101"
        elif i==1:
            dt="8012024"
            resexp="20240108"
        elif i==2:
            dt="08012024"
            resexp="notok"
        elif i==3:
            dt="80124"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # dmyy
    fmt="dmyy"
    for i in range(4):
        if i==0:
            dt="1124"
            resexp="20240101"
        elif i==1:
            dt="1775"
            resexp="19750701"
        elif i==2:
            dt="1075"
            resexp="notok"
        elif i==3:
            dt="171975"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # dmyyyy
    fmt="dmyyyy"
    for i in range(4):
        if i==0:
            dt="112024"
            resexp="20240101"
        elif i==1:
            dt="171975"
            resexp="19750701"
        elif i==2:
            dt="1075"
            resexp="notok"
        elif i==3:
            dt="101975"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyddmm
    fmt="yyddmm"
    for i in range(3):
        if i==0:
            dt="751205"
            resexp="19750512"
        elif i==1:
            dt="752902"
            resexp="notok"
        elif i==2:
            dt="570713"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyddm
    fmt="yyddm"
    for i in range(4):
        if i==0:
            dt="57273"
            resexp="20570327"
        elif i==1:
            dt="75071"
            resexp="19750107"
        elif i==2:
            dt="57732"
            resexp="notok"
        elif i==3:
            dt="19750107"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yydmm
    fmt="yydmm"
    for i in range(4):
        if i==0:
            dt="57211"
            resexp="20571102"
        elif i==1:
            dt="75703"
            resexp="19750307"
        elif i==2:
            dt="57011"
            resexp="notok"
        elif i==3:
            dt="75713"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yydm
    fmt="yydm"
    for i in range(4):
        if i==0:
            dt="5721"
            resexp="20570102"
        elif i==1:
            dt="7599"
            resexp="19750909"
        elif i==2:
            dt="7509"
            resexp="notok"
        elif i==3:
            dt="57213"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyyddmm
    fmt="yyyyddmm"
    for i in range(4):
        if i==0:
            dt="20570102"
            resexp="20570201"
        elif i==1:
            dt="19750909"
            resexp="19750909"
        elif i==2:
            dt="20573901"
            resexp="notok"
        elif i==3:
            dt="570713"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyyddm
    fmt="yyyyddm"
    for i in range(4):
        if i==0:
            dt="1975125"
            resexp="19750512"
        elif i==1:
            dt="2057273"
            resexp="20570327"
        elif i==2:
            dt="20570713"
            resexp="notok"
        elif i==3:
            dt="2057373"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyydmm
    fmt="yyyydmm"
    for i in range(4):
        if i==0:
            dt="2057211"
            resexp="20571102"
        elif i==1:
            dt="1975703"
            resexp="19750307"
        elif i==2:
            dt="2057011"
            resexp="notok"
        elif i==3:
            dt="1975713"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyydm
    fmt="yyyydm"
    for i in range(4):
        if i==0:
            dt="205721"
            resexp="20570102"
        elif i==1:
            dt="197599"
            resexp="19750909"
        elif i==2:
            dt="197509"
            resexp="notok"
        elif i==3:
            dt="2057213"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yymmdd
    fmt="yymmdd"
    for i in range(3):
        if i==0:
            dt="570713"
            resexp="20570713"
        elif i==1:
            dt="751205"
            resexp="19751205"
        elif i==2:
            dt="751200"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yymmd
    fmt="yymmd"
    for i in range(3):
        if i==0:
            dt="57073"
            resexp="20570703"
        elif i==1:
            dt="75125"
            resexp="19751205"
        elif i==2:
            dt="75135"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yymdd
    fmt="yymdd"
    for i in range(3):
        if i==0:
            dt="57713"
            resexp="20570713"
        elif i==1:
            dt="75713"
            resexp="19750713"
        elif i==2:
            dt="57631"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yymd
    fmt="yymd"
    for i in range(3):
        if i==0:
            dt="5773"
            resexp="20570703"
        elif i==1:
            dt="7573"
            resexp="19750703"
        elif i==2:
            dt="7503"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyymmdd
    fmt="yyyymmdd"
    for i in range(4):
        if i==0:
            dt="19751205"
            resexp="19751205"
        elif i==1:
            dt="20570703"
            resexp="20570703"
        elif i==2:
            dt="20570737"
            resexp="notok"
        elif i==3:
            dt="570713"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyymmd
    fmt="yyyymmd"
    for i in range(4):
        if i==0:
            dt="1975125"
            resexp="19751205"
        elif i==1:
            dt="2057073"
            resexp="20570703"
        elif i==2:
            dt="2057173"
            resexp="notok"
        elif i==3:
            dt="570713"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyymdd
    fmt="yyyymdd"
    for i in range(4):
        if i==0:
            dt="1975125"
            resexp="19750125"
        elif i==1:
            dt="2057703"
            resexp="20570703"
        elif i==2:
            dt="2057173"
            resexp="notok"
        elif i==3:
            dt="2057030"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyymd
    fmt="yyyymd"
    for i in range(4):
        if i==0:
            dt="197515"
            resexp="19750105"
        elif i==1:
            dt="205773"
            resexp="20570703"
        elif i==2:
            dt="205703"
            resexp="notok"
        elif i==3:
            dt="205730"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # delimiter -
    fmt="yyyymd"
    for i in range(4):
        if i==0:
            dt="1975-1-5"
            resexp="19750105"
        elif i==1:
            dt="2057-7-3"
            resexp="20570703"
        elif i==2:
            dt="2057-0-3"
            resexp="notok"
        elif i==3:
            dt="205730"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # delimiter /
    fmt="yyyymd"
    for i in range(4):
        if i==0:
            dt="1975/1/5"
            resexp="19750105"
        elif i==1:
            dt="2057/7/3"
            resexp="20570703"
        elif i==2:
            dt="2057/0/3"
            resexp="notok"
        elif i==3:
            dt="205730"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # delimiter .
    fmt="yyyymd"
    for i in range(4):
        if i==0:
            dt="1975.1.5"
            resexp="19750105"
        elif i==1:
            dt="2057.7.3"
            resexp="20570703"
        elif i==2:
            dt="2057.0.3"
            resexp="notok"
        elif i==3:
            dt="205730"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyyddd
    fmt="yyyyddd"
    for i in range(3):
        if i==0:
            dt="2024125"
            resexp="20240504"
        elif i==1:
            dt="1975202"
            resexp="19750721"
        elif i==2:
            dt="20571205"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # monthdd,yyyy
    fmt="monthdd,yyyy"
    for i in range(6):
        if i==0:
            dt="JANUARY25,2024"
            resexp="20240125"
        elif i==1:
            dt="JAN25,2024"
            resexp="20240125"
        elif i==2:
            dt="feb8,1975"
            resexp="19750208"
        elif i==3:
            dt="feb18,1975"
            resexp="19750218"
        elif i==4:
            dt="feb38,1975"
            resexp="notok"
        elif i==5:
            dt="feb"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # ddmonth,yyyy
    fmt="ddmonth,yyyy"
    for i in range(6):
        if i==0:
            dt="25JANUARY,2024"
            resexp="20240125"
        elif i==1:
            dt="25JAN,2024"
            resexp="20240125"
        elif i==2:
            dt="8feb,1975"
            resexp="19750208"
        elif i==3:
            dt="18feb,1975"
            resexp="19750218"
        elif i==4:
            dt="38feb,1975"
            resexp="notok"
        elif i==5:
            dt="feb"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # ddmonthyyyy
    fmt="ddmonthyyyy"
    for i in range(6):
        if i==0:
            dt="25JANUARY2024"
            resexp="20240125"
        elif i==1:
            dt="25JAN2024"
            resexp="20240125"
        elif i==2:
            dt="18feb1975"
            resexp="19750218"
        elif i==3:
            dt="12Dec1975"
            resexp="19751212"
        elif i==4:
            dt="38feb1975"
            resexp="notok"
        elif i==5:
            dt="18fbb1975"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # ddmonthyy
    fmt="ddmonthyy"
    for i in range(6):
        if i==0:
            dt="25JANUARY24"
            resexp="20240125"
        elif i==1:
            dt="25JAN24"
            resexp="20240125"
        elif i==2:
            dt="18feb75"
            resexp="19750218"
        elif i==3:
            dt="12Dec75"
            resexp="19751212"
        elif i==4:
            dt="38feb75"
            resexp="notok"
        elif i==5:
            dt="18fbb75"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yyyymonthdd
    fmt="yyyymonthdd"
    for i in range(6):
        if i==0:
            dt="2024JANUARY25"
            resexp="20240125"
        elif i==1:
            dt="2024JAN25"
            resexp="20240125"
        elif i==2:
            dt="1975feb18"
            resexp="19750218"
        elif i==3:
            dt="1975Dec02"
            resexp="19751202"
        elif i==4:
            dt="1975feb0"
            resexp="notok"
        elif i==5:
            dt="1975fbb18"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # yymonthdd
    fmt="yymonthdd"
    for i in range(6):
        if i==0:
            dt="24JANUARY25"
            resexp="20240125"
        elif i==1:
            dt="24JAN25"
            resexp="20240125"
        elif i==2:
            dt="75feb18"
            resexp="19750218"
        elif i==3:
            dt="75Dec02"
            resexp="19751202"
        elif i==4:
            dt="75feb0"
            resexp="notok"
        elif i==5:
            dt="75fbb18"
            resexp="notok"
        resact=datefuncs.convert_date_to_iso(dt,fmt)
        status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
        print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
        resexp="false" if resexp=="notok" else "true"
        resact = str(datefuncs.is_date_format(dt,fmt)).lower()
        status ="OK" if resexp==resact else "FAIL"
        print("IsDateFormat --> " + status)

    # ------------------------------------------------------
    # no format
    print("\nNO FORMAT")
    dt="11-15-2024"
    fmt=""
    resexp="notok"
    resact=datefuncs.convert_date_to_iso(dt,fmt,False)
    status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)

    dt="07111957"
    fmt=""
    resexp="notok"
    resact=datefuncs.convert_date_to_iso(dt,fmt)
    status ="OK" if resexp==resact or resact.startswith(resexp) else "FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result=" + resact + "  --> " + status)
    resexp="false"
    resact = str(datefuncs.is_date_format(dt,fmt)).lower()
    status ="OK" if resexp==resact else "FAIL"
    print("IsDateFormat --> " + status)

    # ------------------------------------------------------
    # detect format
    print("\nDETECT FORMAT")
    dt="11-15-2024"
    fmt=""
    resexp="20241115"
    resact=datefuncs.convert_date_to_iso(dt,fmt,True)
    if "(" in resact:
        fmt=resact[resact.find("(")+1:-1]
        resact=resact[:resact.find("(")]
    if resexp==resact:
        status="OK"
    else:
        status="FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result [" + resexp + "]=" + resact + "   --> " + status)

    dt="18-1-2024"
    fmt=""
    resexp="20240118"
    resact=datefuncs.convert_date_to_iso(dt,fmt,True)
    if "(" in resact:
        fmt=resact[resact.find("(")+1:-1]
        resact=resact[:resact.find("(")]
    if resexp==resact:
        status="OK"
    else:
        status="FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result [" + resexp + "]=" + resact + "   --> " + status)

    dt="11-15-24"
    fmt=""
    resexp="20241115"
    resact=datefuncs.convert_date_to_iso(dt,fmt,True)
    if "(" in resact:
        fmt=resact[resact.find("(")+1:-1]
        resact=resact[:resact.find("(")]
    if resexp==resact:
        status="OK"
    else:
        status="FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result [" + resexp + "]=" + resact + "   --> " + status)

    dt="01/10/2024"
    fmt=""
    resexp="20240110"
    resact=datefuncs.convert_date_to_iso(dt,fmt,True)
    if "(" in resact:
        fmt=resact[resact.find("(")+1:-1]
        resact=resact[:resact.find("(")]
    if resexp==resact:
        status="OK"
    else:
        status="FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result [" + resexp + "]=" + resact + "   --> " + status)

    dt="28/10/2024"
    fmt=""
    resexp="20241028"
    resact=datefuncs.convert_date_to_iso(dt,fmt,True)
    if "(" in resact:
        fmt=resact[resact.find("(")+1:-1]
        resact=resact[:resact.find("(")]
    if resexp==resact:
        status="OK"
    else:
        status="FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result [" + resexp + "]=" + resact + "   --> " + status)

    dt="38/10/2024"
    fmt=""
    resexp="notok"
    resact=datefuncs.convert_date_to_iso(dt,fmt,True)
    if "(" in resact:
        fmt=resact[resact.find("(")+1:-1]
        resact=resact[:resact.find("(")]
    elif resact.startswith("notok:"):
        resact="notok"
    if resexp==resact:
        status="OK"
    else:
        status="FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result [" + resexp + "]=" + resact + "   --> " + status)

    dt="08/00/2024"
    fmt=""
    resexp="notok"
    resact=datefuncs.convert_date_to_iso(dt,fmt,True)
    if "(" in resact:
        fmt=resact[resact.find("(")+1:-1]
        resact=resact[:resact.find("(")]
    elif resact.startswith("notok:"):
        resact="notok"
    if resexp==resact:
        status="OK"
    else:
        status="FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result [" + resexp + "]=" + resact + "   --> " + status)

    dt="08/41/2024"
    fmt=""
    resexp="notok"
    resact=datefuncs.convert_date_to_iso(dt,fmt,True)
    if "(" in resact:
        fmt=resact[resact.find("(")+1:-1]
        resact=resact[:resact.find("(")]
    elif resact.startswith("notok:"):
        resact="notok"
    if resexp==resact:
        status="OK"
    else:
        status="FAIL"
    print("dt=" + dt + ",fmt=" + fmt + ", Result [" + resexp + "]=" + resact + "   --> " + status)


if __name__ == '__main__':
    do_test_dates()
