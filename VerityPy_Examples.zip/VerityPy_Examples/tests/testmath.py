#!/usr/bin/env python
"""
Test Math Transforms

Run variety of tests with exectransform.py
"""


__all__ = ['do_test_transforms_math']
__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240722'

import math
from VerityPy.processing import datefuncs, exectransform
from VerityPy.transforms import transform

def do_test_transforms_math():
    """
    Test Transform Math Functions

    Do variety of test cases and check results for expected versus actual
    """


    fields:list=[]
    hash_fields:dict={}
    field_datatypes:list=[]
    field_values:list=[]
    lookup_dicts:list=[]
    hash_lookup_dicts:dict={}
    func:str=""
    transform_obj:transform.Transform= transform.Transform("test_transform")
    initial_value:str=""
    result_datatype:str=""
    expval:str=""
    actval:str=""
    status:str=""
    try :
        print("TEST MATH TRANSFORMS")
        print("Current dateTime= " + datefuncs.get_current_iso_datetime(True))

        # make field names
        for i in range(10):
            fields.append("field_" + str(i))
            hash_fields[fields[i]]=i

        field_values.clear()
        field_datatypes.clear()
        field_values.append("0.16")
        field_datatypes.append("integer")
        field_values.append("-1")
        field_datatypes.append("integer")
        field_values.append("3.56789")
        field_datatypes.append("real")
        field_values.append("-mathpi-")
        field_datatypes.append("real")
        field_values.append("5.4e3")
        field_datatypes.append("integer")
        field_values.append("newhampshore")
        field_datatypes.append("integer")
        field_values.append("BLue paper")
        field_datatypes.append("string")
        field_values.append("Geoffrey Malafsky" + "\r\n" + "Fairview, TX 75069")
        field_datatypes.append("string")
        field_values.append("85")
        field_datatypes.append("string")
        field_values.append("123mh9A")
        field_datatypes.append("string")

        transform_obj.ops.clear()
        transform_obj.ops.append(transform.Op(""))
        transform_obj.ops[0].order=0

        func="MultByRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_3"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "3"
        result_datatype= "integer"
        expval= str(9)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="MultByRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_3"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "3"
        result_datatype= "real"
        expval= str(3*math.pi)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="DivByRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "200.5"
        result_datatype= "real"
        expval= str(200.5/85)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",p1=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="DivByRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2=""  # default is to clean number
        transform_obj.ops[0].param3=""
        initial_value= "xx200.5"
        result_datatype= "real"
        expval= str(200.5/85)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="DivByRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2="false"  # do not clean number
        transform_obj.ops[0].param3=""
        initial_value= "xx200.5"
        result_datatype= "real"
        expval= "0.0"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="DivFromRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "200.5"
        result_datatype= "real"
        expval= str(85/200.5)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="DivByRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "0"
        result_datatype= "real"
        expval= "0.0"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="DivFromRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "xx200.5"
        result_datatype= "real"
        expval= str(85/200.5)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="DivByRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2="false"
        transform_obj.ops[0].param3=""
        initial_value= "xx200.5"
        result_datatype= "real"
        expval= "0.0"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="DivFromRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "0"
        result_datatype= "real"
        expval= str(9.99e10)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="AddByRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "200.5"
        result_datatype= "real"
        expval= str(200.5+85)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SubtractByRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "200.5"
        result_datatype= "real"
        expval= str(200.5-85)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SubtractFromRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_8"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "200.5"
        result_datatype= "real"
        expval= str(85-200.5)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="MultRefs"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_0"
        transform_obj.ops[0].param2="field_1,field_3"
        transform_obj.ops[0].param3=""
        initial_value= ""
        result_datatype= "real"
        expval= str(.16*-1*math.pi)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="MultRefs"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_0"
        transform_obj.ops[0].param2="field_1,field_3,field_9"
        transform_obj.ops[0].param3=""
        initial_value= ""
        result_datatype= "real"
        expval= str(.16*-1*math.pi*123)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2 + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="MultRefs"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_0"
        transform_obj.ops[0].param2="field_1,field_3,field_9"
        transform_obj.ops[0].param3="false" # do not clean numbers
        initial_value= ""
        result_datatype= "real"
        expval= "0"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2
               + ",p3=" + transform_obj.ops[0].param3
               + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="AddRefs"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_0"
        transform_obj.ops[0].param2="field_1,field_3"
        transform_obj.ops[0].param3=""
        initial_value= ""
        result_datatype= "real"
        expval= str(.16-1+math.pi)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2
               + ",p3=" + transform_obj.ops[0].param3
               + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="AddRefs"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_0"
        transform_obj.ops[0].param2="field_1,field_3,field_9"
        transform_obj.ops[0].param3=""
        initial_value= ""
        result_datatype= "real"
        expval= str(.16-1+math.pi+123)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2
               + ",p3=" + transform_obj.ops[0].param3
               + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="AddRefs"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_0"
        transform_obj.ops[0].param2="field_1,field_3,field_9"
        transform_obj.ops[0].param3="false"
        initial_value= ""
        result_datatype= "real"
        expval= str(.16-1+math.pi)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2
               + ",p3=" + transform_obj.ops[0].param3
               + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Mult"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="-mathpi-"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "3"
        result_datatype= "real"
        expval= str(3*math.pi)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Mult"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="-4.5"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(100.203*-4.5)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Mult"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="$-4.5"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "#100.203USD"
        result_datatype= "real"
        expval= str(100.203*-4.5)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Mult"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="$-4.5"
        transform_obj.ops[0].param2="false"
        transform_obj.ops[0].param3=""
        initial_value= "#100.203USD"
        result_datatype= "real"
        expval= "0"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
               + ",p2=" + transform_obj.ops[0].param2
               + ",p3=" + transform_obj.ops[0].param3
               + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Mult"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="fred"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(100.203*0)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Div"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="3.76"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(100.203/3.76)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Div"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(9.99e10)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="DivFrom"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="3.76"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(3.76/100.203)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="DivFrom"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="3.76"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "0"
        result_datatype= "real"
        expval= str(9.99e10)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="Subtract"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="3.76"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(100.203-3.76)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SubtractFrom"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="3.76"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(3.76-100.203)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Abs"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "-100.203"
        result_datatype= "real"
        expval= str(100.203)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Negate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(-100.203)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Log"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        transform_obj.ops[0].param1=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(math.log10(100.203))
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Log"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "-100.203"
        result_datatype= "real"
        expval= str(-10e6)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Log"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "integer"
        expval= str(math.floor(math.log10(100.203)))
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Ln"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "100.203"
        result_datatype= "real"
        expval= str(math.log(100.203))
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Pow10"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "0"
        result_datatype= "real"
        expval= str(1)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Pow10"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "3.12"
        result_datatype= "real"
        expval= str(math.pow(10,3.12))
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="PowE"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3=""
        initial_value= "3.12"
        result_datatype= "real"
        expval= str(math.exp(3.12))
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func
              + ", Result [" + expval + "]=" + actval + " -->" + status)

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR: " + str(err))


if __name__ == '__main__':
    do_test_transforms_math()
