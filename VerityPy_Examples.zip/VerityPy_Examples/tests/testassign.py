#!/usr/bin/env python
"""
Test Assignment functions

Run variety of tests with exectransform.py
"""


__all__ = ['do_test_transforms_assign']

__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240725'

import math
from VerityPy.processing import datefuncs, exectransform
from VerityPy.transforms import transform


def do_test_transforms_assign():
    """
    Test Transform Assignment Functions

    Do variety of test cases and check results for expected versus actual
    """


    fields:list=[]
    hash_fields:dict={}
    field_datatypes:list=[]
    field_values:list=[]
    lookup_dicts:list=[]
    hash_lookup_dicts:dict={}
    func:str=""
    transform_obj:transform.Transform= transform.Transform("test_transform")
    initial_value:str=""
    result_datatype:str=""
    expval:str=""
    actval:str=""
    status:str=""
    try :
        print("TEST ASSIGNMENT TRANSFORMS")
        print("Current dateTime= " + datefuncs.get_current_iso_datetime(True))

        # make field names
        for i in range(10):
            fields.append("field_" + str(i))
            hash_fields[fields[i]]=i

        transform_obj.ops.append(transform.Op(""))
        transform_obj.ops[0].order=0

        field_values.clear()
        field_datatypes.clear()
        field_values.clear()
        field_values.append("0.16")
        field_datatypes.append("integer")
        field_values.append("-1")
        field_datatypes.append("integer")
        field_values.append("3.56789")
        field_datatypes.append("real")
        field_values.append("-mathpi-")
        field_datatypes.append("real")
        field_values.append("5.4e3")
        field_datatypes.append("integer")
        field_values.append("newhampshore")
        field_datatypes.append("integer")
        field_values.append("BLue paper")
        field_datatypes.append("string")
        field_values.append("Technik Interlytics," + "\r\n" + "Fairview, TX 75069")
        field_datatypes.append("string")
        field_values.append("85")
        field_datatypes.append("string")
        field_values.append("123mh9A")
        field_datatypes.append("string")


        func="SetToValue"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="-35"
        initial_value= ""
        result_datatype= ""
        expval= "-35"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToValue"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="-mathe-"
        initial_value= ""
        result_datatype= ""
        expval= str(math.e)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToValue"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="Technik Interlytics"
        initial_value= ""
        result_datatype= ""
        expval= "Technik Interlytics"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToIndex"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= ""
        result_datatype= "int"
        expval= "1"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts, 1, -1)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",p1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToIndex"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="x"
        initial_value= ""
        result_datatype= "int"
        expval= "1"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts, 1, -1)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",p1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToIndex"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= ""
        result_datatype= "int"
        expval= "3"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts, 3, -1)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",p1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToIndex"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="10"
        initial_value= ""
        result_datatype= "int"
        expval= "16"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts, 6, -1)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",p1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToIndex"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="-10"
        initial_value= ""
        result_datatype= "int"
        expval= "0"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts, -6, -1)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",p1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_6"
        initial_value= ""
        result_datatype= ""
        expval= field_values[6]
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= ""
        result_datatype= ""
        expval= "-novalue-"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToRandom"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= ""
        result_datatype= ""
        expval= ""
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        expval=actval #since random
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToRandom"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="1"
        transform_obj.ops[0].param2="2"
        initial_value= ""
        result_datatype= ""
        expval= ""
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        expval=actval #since random
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToRandom"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="2"
        initial_value= ""
        result_datatype= ""
        expval= ""
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        expval=actval #since random
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToFreqList"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="2|7|.5|9"
        transform_obj.ops[0].param2="BLUE|red|Yellow|oranGE"
        transform_obj.ops[0].param3="field_0"
        initial_value= ""
        result_datatype= ""
        expval= "red"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToFreqList"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="2|7|.5|9"
        transform_obj.ops[0].param2="BLUE|red|Yellow|oranGE"
        transform_obj.ops[0].param3=".5"
        initial_value= ""
        result_datatype= ""
        expval= "Yellow"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="today"
        initial_value= ""
        result_datatype= ""
        expval= datefuncs.get_current_iso_datetime()
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="now"
        initial_value= ""
        result_datatype= ""
        expval= datefuncs.get_current_iso_datetime(True)
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetToIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="20191125T091135"
        initial_value= ""
        result_datatype= ""
        expval= "20191125T091135"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="SetDecimal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="2"
        initial_value= "2019.1125"
        result_datatype= ""
        expval= "2019.11"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="SetDecimal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="3"
        initial_value= "2019.1125"
        result_datatype= ""
        expval= "2019.112"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetDecimal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="0"
        initial_value= "2019.1125"
        result_datatype= ""
        expval= "2019"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetDecimal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="6"
        initial_value= "2019.1125"
        result_datatype= ""
        expval= "2019.112500"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR: " + str(err))


if __name__ == '__main__':
    do_test_transforms_assign()
