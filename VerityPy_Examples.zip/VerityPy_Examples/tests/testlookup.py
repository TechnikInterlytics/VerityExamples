#!/usr/bin/env python
"""
Test Lookup

Run variety of tests with lookup.py
"""


__all__ = ['do_test_lookupfuncs']

__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240722'

import os
from VerityPy.processing import datefuncs, exectransform
from VerityPy.transforms import lookup, transform

def do_test_lookupfuncs():
    """
    Test Lookup Functions

    Do variety of test cases and check results for expected versus actual
    """

    lookups_toget:list=[]
    lookup_dicts:list=[]
    hash_lookup_dicts:dict={}
    temp_list:list=[]
    temp_obj:dict={}
    lookup_dict:lookup.LookUpDict
    fields:list=[]
    hash_fields:dict={}
    field_datatypes:list=[]
    field_values:list=[]
    n1:int=-1
    curdir:str=""
    dir_delim:str=""
    transform_obj:transform.Transform
    initial_value:str=""
    result_datatype:str=""
    expval:str=""
    actval:str=""
    status:str=""
    try :
        print("TEST LOOKUP FUNCTIONS\n")
        print("Current dateTime= " + datefuncs.get_current_iso_datetime(True))

        curdir= os.path.dirname(os.path.realpath(__file__))
        print("current file dir=" + curdir)
        if "\\" in curdir:
            dir_delim="\\"
        else:
            dir_delim="/"
        if not curdir.endswith(dir_delim):
            curdir += dir_delim
        if curdir.endswith("tests" + dir_delim):
            curdir= curdir[:curdir.find("tests"+dir_delim)]
        curdir += "files" + dir_delim
        print("lookup file dir=" + curdir)

        lookup_dict=lookup.LookUpDict()
        lookup_dict.title="lookup_3field"
        lookup_dict.file_uri= curdir + "lookup_3field_test.dat"
        lookup_dict.is_case_sens=True
        lookup_dict.num_keys=3
        lookup_dict.delim="pipe"
        lookups_toget.append(lookup_dict)

        lookup_dict=lookup.LookUpDict()
        lookup_dict.title="FIPS_State_County"
        lookup_dict.file_uri= curdir + "FIPS_stateCountyCodes.dat"
        lookup_dict.is_case_sens=False
        lookup_dict.num_keys=2
        lookup_dict.delim="comma"
        lookups_toget.append(lookup_dict)

        lookup_dict=lookup.LookUpDict()
        lookup_dict.title="USStatesNormalize"
        lookup_dict.file_uri= curdir + "USStatesNormalize.dat"
        lookup_dict.is_case_sens=False
        lookup_dict.num_keys=1
        lookup_dict.delim="pipe"
        lookups_toget.append(lookup_dict)

        temp_obj=lookup.make_lookups(lookups_toget)
        lookup_dicts= temp_obj['dicts']
        hash_lookup_dicts= temp_obj['hash']

        # also make LookUpDict from list
        temp_list=[]
        temp_list.append("field1|field2|field3|value")
        temp_list.append("Med*-and-*ary*-and-*-1-not- Sum-not-*#*|BL*-and-*ue*-not-* paper|"
                         + "Me*-and-*ar*-and-*L-1-not-*care |REC0")
        temp_list.append("Med*-and-*ary*-and-*-1-not- Sum-not-*#1*|BL*-and-*ue*-and-* paper-not-S*-not-*#|"
                         +"123*-and-*9A-not-*care |REC1")
        temp_list.append("Med*-and-*ary*-and-*-1-not- Sum-not-*#0*|BL*-and-*ue*-and-* paper|"
                         +"123*-and-*9A-not-*care *|REC2")
        lookup_dict=lookup.LookUpDict()
        lookup_dict= lookup.make_lookup_from_list("3field", temp_list, "pipe", True, 3)
        lookup_dicts.append(lookup_dict)

        hash_lookup_dicts.clear()
        n1=0
        for lk in lookup_dicts:
            if lk.title.startswith("notok:"):
                raise ValueError("lookup had error: " + lk.title[6:])
            n1 += 1
            hash_lookup_dicts[lk.title.lower()]= n1-1

        # make a record. hash field names
        for i in range(10):
            fields.append("field_" + str(i))
            hash_fields[fields[i]]=i

        field_values.append("0.16")
        field_datatypes.append("integer")
        field_values.append("-1")
        field_datatypes.append("integer")
        field_values.append("3.56789")
        field_datatypes.append("real")
        field_values.append("-mathpi-")
        field_datatypes.append("real")
        field_values.append("5.4e3")
        field_datatypes.append("integer")
        field_values.append("newhampshore")
        field_datatypes.append("integer")
        field_values.append("BLue paper")
        field_datatypes.append("string")
        field_values.append("Geoffrey Malafsky" + "\r\n" + "Fairview, TX 75069")
        field_datatypes.append("string")
        field_values.append("085")
        field_datatypes.append("string")
        field_values.append("123mh9A")
        field_datatypes.append("string")

        transform_obj= transform.Transform("test_lookup_1")
        transform_obj.ops.append(transform.Op("Lookup"))
        transform_obj.ops[0].order=0
        transform_obj.ops[0].param1="3field"
        transform_obj.ops[0].param2="field_6|field_9"
        initial_value= "Medicare Summary #012AR56L-1"
        result_datatype= "string"
        expval="REC1"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",lkup=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        transform_obj.ops[0].param1="3field"
        initial_value= "Medicare Summary #12AR56L-1"
        result_datatype= "string"
        expval="REC2"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",lkup=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        transform_obj.ops[0].param1="lookup_3field"
        initial_value= "Medicare Summary #012AR56L-1"
        result_datatype= "string"
        expval="REC1"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",lkup=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        transform_obj.ops[0].param1="lookup_3field"
        initial_value= "Medicare Summary #12AR56L-1"
        result_datatype= "string"
        expval="REC2"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",lkup=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        transform_obj.ops[0].param1="FIPS_State_County"
        transform_obj.ops[0].param2="field_8"
        initial_value= "48"
        result_datatype= "string"
        expval="Collin"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",lkup=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        transform_obj.ops[0].param1="FIPS_State_County"
        transform_obj.ops[0].param2="field_8"
        initial_value= "51"
        result_datatype= "string"
        expval="Hanover"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",lkup=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        transform_obj.ops[0].param1="USStatesNormalize"
        initial_value= "newhampshore"
        result_datatype= "string"
        expval="New Hampshire"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",lkup=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        transform_obj.ops[0].param1="USStatesNormalize"
        initial_value= "p.rico"
        result_datatype= "string"
        expval="Puerto Rico"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",lkup=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        transform_obj.ops[0].param1="USStatesNormalize"
        initial_value= "texarkana"
        result_datatype= "string"
        expval="Texas"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",lkup=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)



    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR: " + str(err))



if __name__ == '__main__':
    do_test_lookupfuncs()
