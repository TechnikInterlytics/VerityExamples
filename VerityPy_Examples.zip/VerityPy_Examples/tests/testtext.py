#!/usr/bin/env python
"""
Test Text functions

Run variety of tests with exectransform.py
"""


__all__ = ['do_test_transforms_text']

__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240614'

from VerityPy.processing import datefuncs, exectransform
from VerityPy.transforms import transform


def do_test_transforms_text():
    """
    Test Transform Text Functions

    Do variety of test cases and check results for expected versus actual
    """


    fields:list=[]
    hash_fields:dict={}
    field_datatypes:list=[]
    field_values:list=[]
    lookup_dicts:list=[]
    hash_lookup_dicts:dict={}
    func:str=""
    transform_obj:transform.Transform= transform.Transform("test_transform")
    initial_value:str=""
    result_datatype:str=""
    expval:str=""
    actval:str=""
    status:str=""
    try :
        print("TEST TEXT TRANSFORMS")
        print("Current dateTime= " + datefuncs.get_current_iso_datetime(True))

        # make field names
        for i in range(10):
            fields.append("field_" + str(i))
            hash_fields[fields[i]]=i

        field_values.clear()
        field_datatypes.clear()
        field_values.clear()
        field_values.append("0.16")
        field_datatypes.append("integer")
        field_values.append("-1")
        field_datatypes.append("integer")
        field_values.append("3.56789")
        field_datatypes.append("real")
        field_values.append("-mathpi-")
        field_datatypes.append("real")
        field_values.append("5.4e3")
        field_datatypes.append("integer")
        field_values.append("newhampshore")
        field_datatypes.append("integer")
        field_values.append("BLue paper")
        field_datatypes.append("string")
        field_values.append("Technik Interlytics," + "\r\n" + "Fairview, TX 75069")
        field_datatypes.append("string")
        field_values.append("85")
        field_datatypes.append("string")
        field_values.append("123mh9A")
        field_datatypes.append("string")

        transform_obj.ops.append(transform.Op(""))
        transform_obj.ops[0].order=0

        func="Trim"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= "Technik Interlytics"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="LTrim"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= "Technik Interlytics  "
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="RTrim"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= " Technik Interlytics"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="ToLower"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= " technik interlytics  "
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="ToUpper"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= " TECHNIK INTERLYTICS  "
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Front"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= " Technik Interlytics  "
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Front"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="echni"
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= " Techni"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="End"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="echni"
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= "echnik Interlytics  "
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="Before"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="echni"
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= " T"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="After"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="echni"
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= "k Interlytics  "
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="FrontN"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="4"
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= " Tec"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="EndN"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="6"
        initial_value= " Technik Interlytics "
        result_datatype= ""
        expval= "ytics "
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Mid"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="nik"
        transform_obj.ops[0].param2="lyt"
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= "nik Inter"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Mid"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="nik"
        transform_obj.ops[0].param2="zzz"
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= "nik Interlytics  "
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="MidN"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="1"
        transform_obj.ops[0].param2="7"
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= "Technik"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="CharAt"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="3"
        initial_value= " Technik Interlytics  "
        result_datatype= ""
        expval= "c"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetLength"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="3"
        transform_obj.ops[0].param2="left"
        initial_value= "Technik"
        result_datatype= ""
        expval= "nik"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetLength"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="9"
        transform_obj.ops[0].param2="left"
        transform_obj.ops[0].param3="-"
        initial_value= "Technik"
        result_datatype= ""
        expval= "--Technik"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="SetLength"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="9"
        transform_obj.ops[0].param2=""
        transform_obj.ops[0].param3="-"
        initial_value= "Technik"
        result_datatype= ""
        expval= "Technik--"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Prepend"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="We are: "
        initial_value= "Technik"
        result_datatype= ""
        expval= "We are: Technik"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Append"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=": Our Name"
        initial_value= "Technik"
        result_datatype= ""
        expval= "Technik: Our Name"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Remove"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="e"
        initial_value= "Technik Interlytics"
        result_datatype= ""
        expval= "Tchnik Intrlytics"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Remove"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=" "
        initial_value= "Technik Interlytics"
        result_datatype= ""
        expval= "TechnikInterlytics"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Replace"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=" "
        transform_obj.ops[0].param2="_"
        initial_value= "Technik Interlytics"
        result_datatype= ""
        expval= "Technik_Interlytics"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="Replace"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="Inter"
        transform_obj.ops[0].param2="AI"
        initial_value= "Technik Interlytics"
        result_datatype= ""
        expval= "Technik AIlytics"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR: " + str(err))


if __name__ == '__main__':
    do_test_transforms_text()
