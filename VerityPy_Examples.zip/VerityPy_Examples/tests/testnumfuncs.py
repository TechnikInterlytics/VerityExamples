#!/usr/bin/env python
"""
Test Number Functions

Run variety of tests to functions in numfuncs module
"""


__all__ = ['do_test_numfuncs']

__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240614'

import datetime
from VerityPy.processing import numfuncs

def do_test_numfuncs():
    """
    Test Number Functions

    Do variety of test cases and check results for expected versus actual
    """


    print("TEST NUMBER FUNCTIONS\n")

    # note: for import to work while doing local debugging there should be launch.json with setting for:
    # "env": {"PYTHONPATH": "${workspaceRoot}"}, within the configuration used

    val:str=""
    resexp:str=""
    resact:str=""
    status:str=""
    p1:str=""
    flag:bool=False

    print("Current dateTime= " + str(datetime.datetime.now()))

    print("\nTest: is_int")
    for i in range(5):
        if i==0:
            val="071175"
            resexp="True"
        elif i==1:
            val="111.924"
            resexp="False"
        elif i==2:
            val="$123"
            resexp="False"
        elif i==3:
            val="(456)"
            resexp="True"
        elif i==4:
            val="-456"
            resexp="True"
        resact= str(numfuncs.is_int(val))
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: is_real")
    for i in range(5):
        if i==0:
            val="071175"
            resexp="True"
        elif i==1:
            val="111.924"
            resexp="True"
        elif i==2:
            val="$123.34"
            resexp="False"
        elif i==3:
            val="(456)"
            resexp="True"
        elif i==4:
            val="-456.01"
            resexp="True"
        resact= str(numfuncs.is_real(val))
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: is_int_get")
    for i in range(11):
        flag=False
        if i==0:
            val="071175"
            resexp="71175"
            p1="number"
        elif i==1:
            val="111.924"
            resexp="false"
            p1="string"
        elif i==2:
            val="$123"
            resexp="123"
            p1="string"
            flag=True
        elif i==3:
            val="(456)"
            resexp="-456"
            p1="string"
        elif i==4:
            val="-456"
            resexp="-456"
            p1="string"
        elif i==5:
            val="x$456xx"
            resexp="false"
            p1="string"
        elif i==6:
            val="xx"
            resexp="false"
            p1="string"
        elif i==7:
            val=""
            resexp="false"
            p1="string"
        elif i==8:
            val="111.924"
            resexp="-999999"
            p1="number"
        elif i==9:
            val="$123"
            resexp="false"
            p1="bool"
        elif i==10:
            val="$123"
            resexp="true"
            p1="bool"
            flag=True

        resact= str(numfuncs.is_int_get(val,p1,flag)).lower()
        if resexp=="false" and resact.startswith("false:"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: is_real_get")
    for i in range(8):
        flag=False
        if i==0:
            val="071175"
            resexp="71175.0"
            p1="string"
        elif i==1:
            val="111.924"
            resexp="111.924"
            p1="number"
        elif i==2:
            val="$123"
            resexp="123.0"
            p1="string"
            flag=True
        elif i==3:
            val="(456.56)"
            resexp="-456.56"
            p1="string"
        elif i==4:
            val="-456"
            resexp="-456.0"
            p1="string"
        elif i==5:
            val="x$456.23xx.56"
            resexp="false"
            p1="string"
        elif i==6:
            val="x$ xx THREE"
            resexp="false"
            p1="string"
        elif i==7:
            val="x$xx"
            resexp="false"
            p1="bool"
        resact= str(numfuncs.is_real_get(val,p1,flag)).lower()
        if resexp=="false" and resact.startswith("false:"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: convert_mainframe")
    for i in range(8):
        if i==0:
            val="071175"
            resexp=val
        elif i==1:
            val="12345{"
            resexp="1234.50"
        elif i==2:
            val="12345}"
            resexp="-1234.50"
        elif i==3:
            val="12345a"
            resexp="1234.51"
        elif i==4:
            val="12345l"
            resexp="-1234.53"
        elif i==5:
            val="12345o"
            resexp="-1234.56"
        elif i==6:
            val="12345h"
            resexp="1234.58"
        elif i==7:
            val="12345i"
            resexp="1234.59"
        resact= numfuncs.convert_mainframe(val)
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: get_value_from_suspect_exp")
    for i in range(8):
        if i==0:
            val="71175e2"
            resexp="7117500"
        elif i==1:
            val="1.2345e4"
            resexp="12345"
        elif i==2:
            val="1.2345e-3"
            resexp="0.0012345"
        elif i==3:
            val="-12345"
            resexp=val
        elif i==4:
            val="(12345e-2)"
            resexp="-123.45"
        elif i==5:
            val="-12345e-2"
            resexp="-123.45"
        elif i==6:
            val="e"
            resexp=val
        elif i==7:
            val="10name"
            resexp= val
        resact= numfuncs.get_value_from_suspect_exp(val)
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

    print("\nTest: clean_number")
    for i in range(4):
        if i==0:
            val="$55.6"
            resexp="55.6"
        elif i==1:
            val="(55)"
            resexp="-55"
        elif i==2:
            val="#345.678~"
            resexp="345.678"
        elif i==3:
            val="$-12345678.90USD"
            resexp= "-12345678.90"
        resact= numfuncs.clean_number(val)
        if resexp=="notok" and resact.startswith("notok"):
            status="OK"
        elif resexp==resact:
            status="OK"
        else:
            status="FAIL"
        print("value=" + val + ", Result [" + resexp + "]=" + resact + " -->" + status)

if __name__ == '__main__':
    do_test_numfuncs()
