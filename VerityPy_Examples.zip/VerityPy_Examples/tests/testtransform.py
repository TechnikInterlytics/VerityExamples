#!/usr/bin/env python
"""
Test Transforms

Run variety of tests with exectransform.py
"""


__all__ = ['do_test_transforms_chain', 'do_test_transform_io']
__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240725'

import math
from pathlib import Path
from VerityPy.processing import datefuncs, exectransform
from VerityPy.transforms import transform

CURDIR:str=""
DATADIR:str=""
DIRDELIM:str=""

def do_test_transform_io():
    """
    Test Writing and Reading transforms to file
    """

    transform_list:list=[]
    transform_list_read:list=[]
    file_uri:str=""
    nop:int=-1
    msg:str=""
    try:
        transform_list.append(transform.Transform("Get Log"))
        nop=0
        transform_list[0].ops.append(transform.Op("SetToRef"))
        transform_list[0].ops[nop].param1="field_4"
        nop +=1
        transform_list[0].ops.append(transform.Op("ConvertFromExp"))
        nop +=1
        transform_list[0].ops.append(transform.Op("MultByRef"))
        transform_list[0].ops[nop].param1="field_0"
        nop +=1
        transform_list[0].ops.append(transform.Op("Log"))
        nop +=1
        transform_list[0].ops.append(transform.Op("Round"))
        transform_list[0].ops[nop].param1="3"

        transform_list.append(transform.Transform("Get Color"))
        nop=0
        transform_list[1].ops.append(transform.Op("SetToRef"))
        transform_list[1].ops[nop].param1="field_3"
        nop +=1
        transform_list[1].ops.append(transform.Op("IfGt"))
        transform_list[1].ops[nop].param1="3"
        nop +=1
        transform_list[1].ops.append(transform.Op("SetToValue"))
        transform_list[1].ops[nop].param1="NA"
        nop +=1
        transform_list[1].ops.append(transform.Op("SetToFreqList"))
        transform_list[1].ops[nop].param1="2|7|.5|9"
        transform_list[1].ops[nop].param2="BLUE|rEd|Yellow|oranGE"
        transform_list[1].ops[nop].param3="field_0"  # at 0.16 should have 'rEd'
        nop +=1
        transform_list[1].ops.append(transform.Op("Prepend"))
        transform_list[1].ops[nop].param1="Selected color is: "

        file_uri= DATADIR + "do_test_transform_io_output.txt"
        msg= transform.write_transforms_to_file(file_uri, transform_list)
        if msg.startswith("notok:"):
            raise ValueError("writing transforms error: " + msg[6:])
        transform_list_read = transform.read_transforms_from_file(file_uri)
        if len(transform_list_read)==0:
            raise ValueError("reading transforms error: nothing returned")
        elif len(transform_list_read)!=2:
            raise ValueError("reading transforms error: number transforms != 2 but "+ str(len(transform_list_read)))
        elif not isinstance(transform_list_read[0], transform.Transform):
            raise ValueError("reading transforms error: transform_list_read[0] is not a Transform")
        elif transform_list_read[0].title.startswith("notok:"):
            raise ValueError("reading transforms error: " + transform_list_read[0].title[6:])
        elif not isinstance(transform_list_read[1], transform.Transform):
            raise ValueError("reading transforms error: transform_list_read[1] is not a Transform")
        elif transform_list_read[1].title.startswith("notok:"):
            raise ValueError("reading transforms error: " + transform_list_read[1].title[6:])

        for i in range(len(transform_list)):
            if transform_list[i].title != transform_list_read[i].title:
                raise ValueError("transform read # " + str(i) + " has incorrect title: correct="
                                + transform_list[i].title + " actual=" + transform_list_read[i].title)
            if len(transform_list[i].ops) != len(transform_list_read[i].ops):
                raise ValueError("transform read # " + str(i) + " has incorrect #ops: correct="
                                + str(len(transform_list[i].ops)) + " actual=" + str(len(transform_list_read[i].ops)))
            for j in range(len(transform_list[i].ops)):
                if transform_list[i].ops[j].title != transform_list_read[i].ops[j].title:
                    raise ValueError("transform read # " + str(i)+ ", #op " + str(j) + " has incorrect title: correct="
                                    + transform_list[i].ops[j].title + " actual=" + transform_list_read[i].ops[j].title)
                elif transform_list[i].ops[j].category != transform_list_read[i].ops[j].category:
                    raise ValueError("transform read # " + str(i)+ ", #op " + str(j) + " has incorrect category: correct="
                                    + transform_list[i].ops[j].category + " actual=" + transform_list_read[i].ops[j].category)
                elif transform_list[i].ops[j].order != transform_list_read[i].ops[j].order:
                    raise ValueError("transform read # " + str(i)+ ", #op " + str(j) + " has incorrect order: correct="
                                    + str(transform_list[i].ops[j].order) + " actual=" + str(transform_list_read[i].ops[j].order))
                elif transform_list[i].ops[j].param1 != transform_list_read[i].ops[j].param1:
                    raise ValueError("transform read # " + str(i)+ ", #op " + str(j) + " has incorrect param1: correct="
                                    + transform_list[i].ops[j].param1 + " actual=" + transform_list_read[i].ops[j].param1)
                elif transform_list[i].ops[j].param2 != transform_list_read[i].ops[j].param2:
                    raise ValueError("transform read # " + str(i)+ ", #op " + str(j) + " has incorrect param2: correct="
                                    + transform_list[i].ops[j].param2 + " actual=" + transform_list_read[i].ops[j].param2)
                elif transform_list[i].ops[j].param3 != transform_list_read[i].ops[j].param3:
                    raise ValueError("transform read # " + str(i)+ ", #op " + str(j) + " has incorrect param3: correct="
                                    + transform_list[i].ops[j].param3 + " actual=" + transform_list_read[i].ops[j].param3)

        print(f"Write and Read transform file {file_uri} --> OK")
    except (ValueError, RuntimeError, IOError, OSError) as err:
        print("do_test_transform_io error:" + str(err))

def do_test_transform_helpers():
    """
    Test transform helper functions extract_lookup_title, set_lookup_fields, extract_refs
    """

    transform_list:list=[]
    transform_list_new:list=[]
    lklup_titles:list=[]
    lklup_titles_extracted:list=[]
    nop:int=-1
    didfind:bool=False
    try:
        print("TEST TRANSFORM HELPERS")
        print("Current dateTime= " + datefuncs.get_current_iso_datetime(True))

        transform_list.append(transform.Transform("Get Log"))
        nop=0
        transform_list[0].ops.append(transform.Op("SetToRef"))
        transform_list[0].ops[nop].param1="field_4"
        nop +=1
        transform_list[0].ops.append(transform.Op("ConvertFromExp"))
        nop +=1
        transform_list[0].ops.append(transform.Op("MultByRef"))
        transform_list[0].ops[nop].param1="field_0"
        nop +=1
        transform_list[0].ops.append(transform.Op("Log"))
        nop +=1
        transform_list[0].ops.append(transform.Op("Round"))
        transform_list[0].ops[nop].param1="3"

        transform_list.append(transform.Transform("Get Color"))
        nop=0
        transform_list[1].ops.append(transform.Op("SetToRef"))
        transform_list[1].ops[nop].param1="field_3"
        nop +=1
        transform_list[1].ops.append(transform.Op("IfGt"))
        transform_list[1].ops[nop].param1="3"
        nop +=1
        transform_list[1].ops.append(transform.Op("SetToValue"))
        transform_list[1].ops[nop].param1="NA"
        nop +=1
        transform_list[1].ops.append(transform.Op("SetToFreqList"))
        transform_list[1].ops[nop].param1="2|7|.5|9"
        transform_list[1].ops[nop].param2="BLUE|rEd|Yellow|oranGE"
        transform_list[1].ops[nop].param3="field_0"  # at 0.16 should have 'rEd'
        nop +=1
        transform_list[1].ops.append(transform.Op("Prepend"))
        transform_list[1].ops[nop].param1="Selected color is: "

        transform_list.append(transform.Transform("test_lookup_1"))
        transform_list[2].ops.append(transform.Op("Lookup"))
        transform_list[2].ops[0].order=0
        transform_list[2].ops[0].param1="3field"
        transform_list[2].ops[0].param2="field_6|field_9"

        transform_list.append(transform.Transform("test_lookup_2"))
        transform_list[3].ops.append(transform.Op("Lookup"))
        transform_list[3].ops[0].order=0
        transform_list[3].ops[0].param1="3field"
        transform_list[3].ops[0].param2="field_3|field_8"

        transform_list.append(transform.Transform("test_lookup_3"))
        transform_list[4].ops.append(transform.Op("Lookup"))
        transform_list[4].ops[0].order=0
        transform_list[4].ops[0].param1="lookup_3field"
        transform_list[4].ops[0].param2="field_1|field_2"

        lklup_titles.append("3field")
        lklup_titles.append("lookup_3field")

        lklup_titles_extracted= transform.extract_lookup_titles(transform_list)
        if len(lklup_titles_extracted)==0:
            raise ValueError("nothing returned extract_lookup_titles")
        elif lklup_titles_extracted[0].startswith("notok:"):
            raise ValueError("error: " + lklup_titles_extracted[0][6:] + "   extract_lookup_titles")
        elif len(lklup_titles_extracted)!=2:
            raise ValueError("incorrect #entries " + str(len(lklup_titles_extracted)) + "/2  extract_lookup_titles")

        for i in range(len(lklup_titles)):
            didfind=False
            for j in range(len(lklup_titles_extracted)):
                if lklup_titles[i]== lklup_titles_extracted[j]:
                    didfind=True
                    break
            if not didfind:
                raise ValueError("did not find lookup title in extracted: " + lklup_titles[i] + "  extract_lookup_titles")

        print("extract_lookup_titles --> OK")


        transform_list_new= transform.set_lookup_fields(transform_list)
        if len(transform_list_new)==0:
            raise ValueError("nothing returned set_lookup_fields")
        elif len(transform_list_new)!=len(transform_list):
            raise ValueError("incorrect #entries " + str(len(transform_list_new))
                             + "/" + str(len(transform_list)) + "  set_lookup_fields")

        if len(transform_list_new[2].ops[0].p2list)!=2:
            raise ValueError("incorrect transform 2 #p2list "
                             + str(len(transform_list_new[2].ops[0].p2list)) + "/2" + "  set_lookup_fields")
        elif not all(x in transform_list_new[2].ops[0].p2list for x in ["field_6","field_9"]):
            raise ValueError("incorrect transform 2 #p2list missing field_6 and/or field_9: "
                             + "|".join(transform_list_new[2].ops[0].p2list) + "  set_lookup_fields")

        if len(transform_list_new[3].ops[0].p2list)!=2:
            raise ValueError("incorrect transform 3 #p2list "
                             + str(len(transform_list_new[3].ops[0].p2list)) + "/2" + "  set_lookup_fields")
        elif not all(x in transform_list_new[3].ops[0].p2list for x in ["field_3","field_8"]):
            raise ValueError("incorrect transform 3 #p2list missing field_3 and/or field_8: "
                             + "|".join(transform_list_new[3].ops[0].p2list) + "  set_lookup_fields")

        if len(transform_list_new[4].ops[0].p2list)!=2:
            raise ValueError("incorrect transform 4 #p2list "
                             + str(len(transform_list_new[4].ops[0].p2list)) + "/2" + "  set_lookup_fields")
        elif not all(x in transform_list_new[4].ops[0].p2list for x in ["field_1","field_2"]):
            raise ValueError("incorrect transform 4 #p2list missing field_1 and/or field_2: "
                             + "|".join(transform_list_new[4].ops[0].p2list) + "  set_lookup_fields")

        print("set_lookup_fields --> OK")


        hash_fields={}
        hash_fields= transform.extract_refs(transform_list)
        if len(hash_fields)==0:
            raise ValueError("nothing returned extract_refs")

        if "field_0" not in hash_fields:
            raise ValueError("field_0 not in refs")
        elif hash_fields["field_0"]!=2:
            raise ValueError("field_0 instance should=2 but =" + str(hash_fields["field_0"]))
        if "field_1" not in hash_fields:
            raise ValueError("field_1 not in refs")
        elif hash_fields["field_1"]!=1:
            raise ValueError("field_1 instance should=1 but =" + str(hash_fields["field_1"]))
        if "field_2" not in hash_fields:
            raise ValueError("field_2 not in refs")
        elif hash_fields["field_2"]!=1:
            raise ValueError("field_2 instance should=1 but =" + str(hash_fields["field_2"]))
        if "field_3" not in hash_fields:
            raise ValueError("field_3 not in refs")
        elif hash_fields["field_3"]!=2:
            raise ValueError("field_3 instance should=2 but =" + str(hash_fields["field_3"]))
        if "field_4" not in hash_fields:
            raise ValueError("field_4 not in refs")
        elif hash_fields["field_4"]!=1:
            raise ValueError("field_4 instance should=1 but =" + str(hash_fields["field_4"]))
        if "field_6" not in hash_fields:
            raise ValueError("field_6 not in refs")
        elif hash_fields["field_6"]!=1:
            raise ValueError("field_6 instance should=1 but =" + str(hash_fields["field_6"]))
        if "field_8" not in hash_fields:
            raise ValueError("field_8 not in refs")
        elif hash_fields["field_8"]!=1:
            raise ValueError("field_8 instance should=1 but =" + str(hash_fields["field_8"]))
        if "field_0" not in hash_fields:
            raise ValueError("field_9 not in refs")
        elif hash_fields["field_9"]!=1:
            raise ValueError("field_9 instance should=1 but =" + str(hash_fields["field_9"]))

        print("extract_refs --> OK")
    except (ValueError, RuntimeError, IOError, OSError) as err:
        print(str(err) + "   -->  FAIL")

def do_test_transforms_chain():
    """
    Test Chained Transforms
    """


    nop:int=-1
    fields:list=[]
    hash_fields:dict={}
    field_datatypes:list=[]
    field_values:list=[]
    lookup_dicts:list=[]
    hash_lookup_dicts:dict={}
    func:str=""
    transform_obj:transform.Transform= transform.Transform("test_transform")
    initial_value:str=""
    result_datatype:str=""
    expval:str=""
    actval:str=""
    status:str=""
    try:
        print("TEST CHAINED TRANSFORMS")
        print("Current dateTime= " + datefuncs.get_current_iso_datetime(True))

        # make field names
        for i in range(11):
            fields.append("field_" + str(i))
            hash_fields[fields[i]]=i

        field_values.append("0.16")
        field_datatypes.append("integer")
        field_values.append("-1")
        field_datatypes.append("integer")
        field_values.append("3.56789")
        field_datatypes.append("real")
        field_values.append("-mathpi-")
        field_datatypes.append("real")
        field_values.append("5.4e3")
        field_datatypes.append("integer")
        field_values.append("newhampshore")
        field_datatypes.append("integer")
        field_values.append("BLue paper")
        field_datatypes.append("string")
        field_values.append("Technik Interlytics," + "\r\n" + "Fairview, TX 75069")
        field_datatypes.append("string")
        field_values.append("85")
        field_datatypes.append("string")
        field_values.append("123mh9A")
        field_datatypes.append("string")
        field_values.append("AL Total Migration-US and Foreign")
        field_datatypes.append("string")

        # multi-step transform that uses Ref for initial value and then does math ops
        func="Get Log"
        transform_obj.ops.clear()
        nop +=1
        transform_obj.ops.append(transform.Op("SetToRef"))
        transform_obj.ops[nop].param1="field_4"
        nop +=1
        transform_obj.ops.append(transform.Op("ConvertFromExp"))
        nop +=1
        transform_obj.ops.append(transform.Op("MultByRef"))
        transform_obj.ops[nop].param1="field_0"
        nop +=1
        transform_obj.ops.append(transform.Op("Log"))
        nop +=1
        transform_obj.ops.append(transform.Op("Round"))
        transform_obj.ops[nop].param1="3"
        expval= str(round(math.log10(5400*0.16),3))
        result_datatype= "real"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",initial=" + initial_value + ",#ops=" + str(nop)
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        # multi-step transform that uses Ref for initial value and then does conditional to
        # determine if use to frequency distribution to get value
        nop=-1
        func="Get Color"
        transform_obj.ops.clear()
        nop +=1
        transform_obj.ops.append(transform.Op("SetToRef"))
        transform_obj.ops[nop].param1="field_3"
        nop +=1
        transform_obj.ops.append(transform.Op("IfGt"))
        transform_obj.ops[nop].param1="3"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="NA"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToFreqList"))
        transform_obj.ops[nop].param1="2|7|.5|9"
        transform_obj.ops[nop].param2="BLUE|rEd|Yellow|oranGE"
        transform_obj.ops[nop].param3="field_0"  # at 0.16 should have 'rEd'
        nop +=1
        transform_obj.ops.append(transform.Op("Prepend"))
        transform_obj.ops[nop].param1="Selected color is: "
        expval= "Selected color is: rEd"
        result_datatype= "string"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",initial=" + initial_value + ",#ops=" + str(nop)
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        # multi-step transform that uses Ref for initial value and then does 2 conditionals to
        # populate output field with bool
        nop=-1
        func="2 Ifs for bool: has Migra"
        transform_obj.ops.clear()
        nop +=1
        transform_obj.ops.append(transform.Op("SetToRef"))
        transform_obj.ops[nop].param1="field_10"
        nop +=1
        transform_obj.ops.append(transform.Op("IfNotEq"))
        transform_obj.ops[nop].param1="-1"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="false"
        nop +=1
        transform_obj.ops.append(transform.Op("ifStrContains"))
        transform_obj.ops[nop].param1="migra"
        transform_obj.ops[nop].param2="false"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="true"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="false"
        expval= "false"
        result_datatype= "string"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",initial=" + initial_value + ",#ops=" + str(nop)
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        # multi-step transform that uses Ref for initial value and then does 2 conditionals to
        # populate output field with bool
        nop=-1
        func="2 Ifs for bool: case sens"
        transform_obj.ops.clear()
        nop +=1
        transform_obj.ops.append(transform.Op("SetToRef"))
        transform_obj.ops[nop].param1="field_10"
        nop +=1
        transform_obj.ops.append(transform.Op("IfNotEq"))
        transform_obj.ops[nop].param1="-1"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="false"
        nop +=1
        transform_obj.ops.append(transform.Op("ifStrContains"))
        transform_obj.ops[nop].param1="migra"
        transform_obj.ops[nop].param2="true"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="true"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="false"
        expval= "true"
        result_datatype= "string"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",initial=" + initial_value + ",#ops=" + str(nop)
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        # multi-step transform that uses Ref for initial value and then does 2 conditionals to
        # populate output field with bool
        nop=-1
        func="2 Ifs for bool: is -1"
        transform_obj.ops.clear()
        nop +=1
        transform_obj.ops.append(transform.Op("SetToRef"))
        transform_obj.ops[nop].param1="field_1"
        nop +=1
        transform_obj.ops.append(transform.Op("IfNotEq"))
        transform_obj.ops[nop].param1="-1"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="false"
        nop +=1
        transform_obj.ops.append(transform.Op("ifStrContains"))
        transform_obj.ops[nop].param1="migra"
        transform_obj.ops[nop].param2=""
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="true"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="false"
        expval= "false"
        result_datatype= "string"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",initial=" + initial_value + ",#ops=" + str(nop)
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        # multi-step transform that uses Ref for initial value and then does 2 conditionals to
        # populate output field with bool
        nop=-1
        func="2 Ifs for bool: is pos real"
        transform_obj.ops.clear()
        nop +=1
        transform_obj.ops.append(transform.Op("SetToRef"))
        transform_obj.ops[nop].param1="field_4"
        nop +=1
        transform_obj.ops.append(transform.Op("IfNotEq"))
        transform_obj.ops[nop].param1="-1"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="false"
        nop +=1
        transform_obj.ops.append(transform.Op("ifStrContains"))
        transform_obj.ops[nop].param1="migra"
        transform_obj.ops[nop].param2=""
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="true"
        nop +=1
        transform_obj.ops.append(transform.Op("SetToValue"))
        transform_obj.ops[nop].param1="false"
        expval= "true"
        result_datatype= "string"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("func=" + func + ",initial=" + initial_value + ",#ops=" + str(nop)
              + ", Result [" + expval + "]=" + actval + " -->" + status)

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR:" + str(err))


if __name__ == '__main__':
    CURDIR= str(Path.cwd())
    if "\\" in CURDIR:
        DIRDELIM="\\"
    else:
        DIRDELIM="/"
    if not CURDIR.endswith(DIRDELIM):
        CURDIR += DIRDELIM
    print(f"current dir={CURDIR}")
    DATADIR= CURDIR + "files" + DIRDELIM
    print(f"data dir={DATADIR}")
    do_test_transform_io()
    do_test_transform_helpers()
    do_test_transforms_chain()
