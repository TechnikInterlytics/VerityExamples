#!/usr/bin/env python
"""
Test RemediateParsing functions
"""


__all__ = []
__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240807'

import datetime
from VerityPy.processing import field, datefuncs, remediateparsing

DQ:str="\""

def do_shiftarray():
    """Test Shifting Array to fix too many parsed fields

    Various combinations of datatypes and formats are used to feed 
    algorithm determining how best to adjust value placement.
    """

    delim_char:str=","
    txt:str=""
    txt1:str=""
    title:str=""
    dtype:str=""
    strcase:str=""
    datefmt:str=""
    resexp:str=""
    resact:str=""
    temp:list=[]
    srcfields:list=[]
    srcrecs:list=[]
    srcfields2:list=[]
    srcrecs2:list=[]
    hashflds:dict={}
    hashflds2:dict={}
    strlen:int=-1
    numdec:int=-1
    n1:int=0
    origvals:list=[]
    newvals:list=[]
    pinflds:list=[]
    srcrecs:list=[]
    srcrecs2:list=[]
    try:
        print("TEST SHIFT ARRAY DATA\n")
        print("Current dateTime= " + str(datetime.date.today()))

        srcfields.append(field.Field("y2_statefips"))
        srcfields.append(field.Field("y1_statefips"))
        srcfields.append(field.Field("y1_state"))
        srcfields.append(field.Field("y1_state_name"))
        srcfields.append(field.Field("n1"))
        srcfields.append(field.Field("n2"))
        srcfields.append(field.Field("AGI"))

        for i in range(len(srcfields)):
            txt= srcfields[i].title.lower()
            hashflds[txt]=i
            dtype=""
            strcase=""
            strlen=-1
            numdec=-1
            datefmt=""
            if txt in ("y1_state","y1_state_name"):
                dtype="string"
                if txt=="y1_state":
                    strcase="upper"
                    strlen=2
            elif txt in ("y1_statefips","y2_statefips"):
                dtype="string"
                strlen=2
            elif txt in ("n1","n2"):
                dtype="int"
            elif txt=="agi":
                dtype="real"
                numdec=0
            srcfields[i].datatype=dtype
            srcfields[i].fmt_date=datefmt
            srcfields[i].fmt_decimal=numdec
            srcfields[i].fmt_strcase=strcase
            srcfields[i].fmt_strlen=strlen

        srcrecs.append("01,96,AL,AL Total Migration-US and Foreign,33716,67747,1515297")
        srcrecs.append("01,97,AL,AL Total Migration-US,32868,x65647,1467218")
        srcrecs.append("01,98,AL,\"AL Total Migration,Foreign\",848,2100,48079")
        srcrecs.append("01,97,AL,AL Total Migration-Same ")
        srcrecs.append("State,46630,95832,1.871804e+6")
        srcrecs.append("01,01,AL,AL ")
        srcrecs.append("Non-")
        srcrecs.append("migrants,1598458,3579600,96406319")
        srcrecs.append("1,51,VA,Virginia,819,1624,$48796")
        srcrecs.append("01,18,IN,Indiana,457,895,21821►")


        print("---------------- TEST 1: SHIFT RECORDS --------------------")
        print("Rec 2 too big, 3-7 too small")

        for i in range(len(srcrecs)):
            print("Record " + str(i))
            temp= srcrecs[i].split(delim_char)
            if len(temp)==0:
                raise ValueError("no split values srcRec {0}".format(str(i)))
            elif temp[0].startswith("notok:"):
                raise ValueError("error split values srcRec {0}:{1}".format(str(i), temp[0][6:]))
            origvals=[]
            for j in range(len(temp)):
                origvals.append(temp[j])
            newvals= remediateparsing.shift_array_entries(origvals, srcfields, hashflds, pinflds)
            print("origVals={0}, newVals={1}".format(len(origvals), len(newvals)))
            for j in range(len(origvals)):
                txt="" if j>= len(origvals) else origvals[j]
                txt1="" if j>= len(newvals) else newvals[j]
                print("{0}.     orig={1},    new={2}".format(str(j), txt, txt1))


        print("---------------- TEST 2: DATATYPES and FORMATS --------------------")
        for i in range(1,7):
            srcfields2.append(field.Field("f" + str(i)))
            hashflds2[srcfields2[i-1].title.lower()]=i-1
            if i==1:
                srcfields2[i-1].datatype="int"
            elif i==2:
                srcfields2[i-1].datatype="string"
            elif i==3:
                srcfields2[i-1].datatype="string"
                srcfields2[i-1].fmt_strlen=3
            elif i==4:
                srcfields2[i-1].datatype="date"
                srcfields2[i-1].fmt_date="mmddyyyy"
            elif i==5:
                srcfields2[i-1].datatype="real"
                srcfields2[i-1].fmt_decimal=2
            elif i==6:
                srcfields2[i-1].datatype="string"
                srcfields2[i-1].fmt_strcase="upper"

        txt = "41,Abc dEf ,data,GHI,07/03/2024,1701.56,GPM"
        srcrecs2.append(txt)
        origvals= txt.split(delim_char)

        newvals= remediateparsing.shift_array_entries(origvals, srcfields2, hashflds2, pinflds)
        resexp = "41|Abc dEf data|GHI|07/03/2024|1701.56|GPM"
        print("#shiftedFlds={0}, pinFlds={1}".format(len(newvals), ",".join(pinflds)))
        resact = "|".join(newvals)
        txt="OK" if resexp==resact else "FAIL"
        print("{0}     ---->   {1}".format(resact, txt))

        pinflds.append("f3")
        newvals= remediateparsing.shift_array_entries(origvals, srcfields2, hashflds2, pinflds)
        resexp = "41|Abc dEf |dataGHI|07/03/2024|1701.56|GPM"
        print("#shiftedFlds={0}, pinFlds={1}".format(len(newvals), ",".join(pinflds)))
        resact = "|".join(newvals)
        txt="OK" if resexp==resact else "FAIL"
        print("{0}     ---->   {1}".format(resact, txt))

        pinflds=[]
        srcfields2[2].fmt_strlen=-1
        srcfields2[2].fmt_strcase="upper"
        srcfields2[4].fmt_decimal=-1
        srcfields2[5].fmt_strcase= ""
        newvals= remediateparsing.shift_array_entries(origvals, srcfields2, hashflds2, pinflds)
        resexp = "41|Abc dEf data|GHI|07/03/2024|1701.56|GPM"
        print("#shiftedFlds={0}, pinFlds={1}".format(len(newvals), ",".join(pinflds)))
        resact = "|".join(newvals)
        txt="OK" if resexp==resact else "FAIL"
        print("{0}     ---->   {1}".format(resact, txt))

        pinflds.append("f3")
        newvals= remediateparsing.shift_array_entries(origvals, srcfields2, hashflds2, pinflds)
        resexp = "41|Abc dEf |dataGHI|07/03/2024|1701.56|GPM"
        print("#shiftedFlds={0}, pinFlds={1}".format(len(newvals), ",".join(pinflds)))
        resact = "|".join(newvals)
        txt="OK" if resexp==resact else "FAIL"
        print("{0}     ---->   {1}".format(resact, txt))

        pinflds=[]
        srcfields2[2].fmt_strlen= 7
        srcfields2[2].fmt_strcase=""
        srcfields2[4].fmt_decimal= 2
        srcfields2[5].fmt_strcase= "upper"
        srcfields2[5].fmt_strlen= 3
        newvals= remediateparsing.shift_array_entries(origvals, srcfields2, hashflds2, pinflds)
        resexp = "41|Abc dEf |dataGHI|07/03/2024|1701.56|GPM"
        print("#shiftedFlds={0}, pinFlds={1}".format(len(newvals), ",".join(pinflds)))
        resact = "|".join(newvals)
        txt="OK" if resexp==resact else "FAIL"
        print("{0}     ---->   {1}".format(resact, txt))

        srcfields2[2].fmt_strlen= -1
        newvals= remediateparsing.shift_array_entries(origvals, srcfields2, hashflds2, pinflds)
        resexp = "41|Abc dEf data|GHI|07/03/2024|1701.56|GPM"
        print("#shiftedFlds={0}, pinFlds={1}".format(len(newvals), ",".join(pinflds)))
        resact = "|".join(newvals)
        txt="OK" if resexp==resact else "FAIL"
        print("{0}     ---->   {1}".format(resact, txt))

        pinflds.append("f3")
        newvals= remediateparsing.shift_array_entries(origvals, srcfields2, hashflds2, pinflds)
        resexp = "41|Abc dEf |dataGHI|07/03/2024|1701.56|GPM"
        print("#shiftedFlds={0}, pinFlds={1}".format(len(newvals), ",".join(pinflds)))
        resact = "|".join(newvals)
        txt="OK" if resexp==resact else "FAIL"
        print("{0}     ---->   {1}".format(resact, txt))

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR: " + str(err))


def do_fixrecordsplit():
    """Test RemediateParsing Fix Record Split function
    """

    settings:dict={}
    delim_char:str=","
    txt:str=""
    txt1:str=""
    title:str=""
    dtype:str=""
    strcase:str=""
    datefmt:str=""
    resexp:str=""
    resact:str=""
    temp:list=[]
    srcfields:list=[]
    srcrecs:list=[]
    outrecs:list=[]
    strlen:int=-1
    numdec:int=-1
    n1:int=0
    try:
        settings["allow_last_empty"] = "false"
        settings["is_quoted"] = "true"
        settings["has_header"] = "true"
        settings["ignore_empty"] = "true"
        settings["pin_fields"] = ""
        settings["ignore_start_str"] = "#|//"
        settings["delim"] = "comma"
        settings["join_char"] = "_"

        print("\n\nTEST FixRecordSplit: " + datefuncs.get_current_iso_datetime(True))

        srcfields.append(field.Field("y2_statefips"))
        srcfields.append(field.Field("y1_statefips"))
        srcfields.append(field.Field("y1_state"))
        srcfields.append(field.Field("y1_state_name"))
        srcfields.append(field.Field("n1"))
        srcfields.append(field.Field("n2"))
        srcfields.append(field.Field("AGI"))

        for i in range(len(srcfields)):
            txt=srcfields[i].title.lower()
            dtype=""
            if txt in ("y1_state","y1_state_name"):
                dtype="string"
            elif txt in ("y1_statefips","y2_statefips"):
                dtype="string"
            elif txt in ("n1","n2"):
                dtype="int"
            elif txt =="agi":
                dtype="real"
            
            strcase=""
            strlen=-1
            numdec=-1
            datefmt=""

            if txt in ("y1_statefips","y2_statefips"):
                strlen=2
            elif txt =="y1_state":
                strcase="upper"
                strlen=2
            elif txt =="agi":
                numdec=0

            srcfields[i].datatype=dtype
            srcfields[i].fmt_date=datefmt
            srcfields[i].fmt_strcase=strcase
            srcfields[i].fmt_strlen=strlen
            srcfields[i].fmt_decimal=numdec

        srcrecs.append("// test records from IRS data")
        srcrecs.append("")
        srcrecs.append("y2_statefips,y1_statefips,y1_state,y1_state_name,n1,n2,AGI")
        srcrecs.append("01,96,AL,AL Total Migration-US and Foreign,33716,67747,1515297")
        srcrecs.append("01,97,AL,AL Total Migration-US,32868,x65647,1467218")
        srcrecs.append("01,98,AL,\"AL Total Migration,Foreign\",848,2100,48079")
        srcrecs.append("01,97,AL,AL Total Migration-Same ")
        srcrecs.append("State,46630,95832,1.871804e+6")
        srcrecs.append("01,01,AL,AL ")
        srcrecs.append("Non-")
        srcrecs.append("migrants,1598458,3579600,96406319")
        srcrecs.append("1,51,VA,Virginia,819,1624,$48796")
        srcrecs.append("01,18,IN,Indiana,457,895,21821►")

        stats = "" 
        hdr = ""
        outrecs= remediateparsing.fix_record_field_split(settings, srcfields, srcrecs)
        if len(outrecs)>0 and outrecs[0].startswith("notok:"):
            raise ValueError(outrecs[0][6:])
        if outrecs[0].startswith("ok:"):
            stats=outrecs[0]
            outrecs.pop(0)
            hdr=outrecs[0]
            outrecs.pop(0)

        print("stats:{0}".format(stats))
        if len(hdr)>0:
            print("header:{0}".format(hdr))
        for s in outrecs:
            print("[{0}]".format(s))

        txt= "OK" if len(outrecs)==7 else ("WRONG=" + str(len(outrecs)) + "/7")
        print("#outrecs is {0}".format(txt))

        if len(outrecs)==7:
                resexp = "01,97,AL,AL Total Migration-US,32868,x65647,1467218"
                resact = outrecs[1]
                txt= "OK" if resexp==resact else "FAIL"
                print("rec[1]  --->  {0}".format(txt))

                resexp = "01,98,AL,\"AL Total Migration,Foreign\",848,2100,48079"
                resact = outrecs[2]
                txt= "OK" if resexp==resact else "FAIL"
                print("rec[2]  --->  {0}".format(txt))

                resexp = "01,18,IN,Indiana,457,895,21821►"
                resact = outrecs[6]
                txt= "OK" if resexp==resact else "FAIL"
                print("rec[6]  --->  {0}".format(txt))

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR: " + str(err))



if __name__=="__main__":
    do_shiftarray()
    do_fixrecordsplit()
