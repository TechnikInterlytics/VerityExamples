#!/usr/bin/env python
"""
Test Conditional Transforms

Run variety of tests with exectransform.py
"""


__all__ = ['do_test_transforms_conditional']
__version__ = '1.0'
__author__ = 'Geoffrey Malafsky'
__email__ = 'gmalafsky@technikinterlytics.com'
__date__ = '20240722'

from VerityPy.processing import datefuncs, exectransform
from VerityPy.transforms import transform

def do_test_transforms_conditional():
    """
    Test conditional transforms
    """

    fields:list=[]
    hash_fields:dict={}
    field_datatypes:list=[]
    field_values:list=[]
    lookup_dicts:list=[]
    hash_lookup_dicts:dict={}
    func:str=""
    transform_obj:transform.Transform= transform.Transform("test_transform")
    initial_value:str=""
    result_datatype:str=""
    expval:str=""
    actval:str=""
    status:str=""
    try:
        print("TEST CONDITIONAL TRANSFORMS")
        print("Current dateTime= " + datefuncs.get_current_iso_datetime(True))

        # make field names
        for i in range(10):
            fields.append("field_" + str(i))
            hash_fields[fields[i]]=i

        field_values.clear()
        field_datatypes.clear()
        field_values.clear()
        field_values.append("0.16")
        field_datatypes.append("integer")
        field_values.append("-1")
        field_datatypes.append("integer")
        field_values.append("3.56789")
        field_datatypes.append("real")
        field_values.append("-mathpi-")
        field_datatypes.append("real")
        field_values.append("5.4e3")
        field_datatypes.append("integer")
        field_values.append("newhampshore")
        field_datatypes.append("integer")
        field_values.append("BLue paper")
        field_datatypes.append("string")
        field_values.append("Technik Interlytics," + "\r\n" + "Fairview, TX 75069")
        field_datatypes.append("string")
        field_values.append("85")
        field_datatypes.append("string")
        field_values.append("123mh9A")
        field_datatypes.append("string")

        transform_obj.ops.clear()
        transform_obj.ops.append(transform.Op(""))
        transform_obj.ops[0].order=0

        func="IfGte"
        print("----" + func + "----")
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="-35"
        initial_value= "31.25"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfGte"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "31.25"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfGte"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="31.25"
        initial_value= "31.25"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfGte"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="35"
        initial_value= "31.25"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfGteRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_0"
        initial_value= "31.25"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfGteRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_4"
        initial_value= "31.25"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfGt"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="31.25"
        initial_value= "31.25"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfLte"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="31.25"
        initial_value= "31.25"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfLt"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="31.25"
        initial_value= "31.25"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfEq"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="31.25"
        initial_value= "31.25"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfEq"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="31.24"
        initial_value= "31.25"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfEqRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_0"
        initial_value= "31.25"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotEqRef"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="field_0"
        initial_value= "31.25"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotLt"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="31.25"
        initial_value= "31.25"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfEmpty"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= ""
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfEmpty"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "as"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="IfNotEmpty"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "a"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfStrEq"
        print("----" + func + "----")
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="a Dog"
        transform_obj.ops[0].param2="true"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfStrEq"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="a dog"
        transform_obj.ops[0].param2="true"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotStrEq"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="a dog"
        transform_obj.ops[0].param2="true"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotStrEq"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="a dog"
        transform_obj.ops[0].param2="false"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfStrStarts"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="a d"
        transform_obj.ops[0].param2="true"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotStrStarts"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="a d"
        transform_obj.ops[0].param2="true"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfStrStarts"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="a d"
        transform_obj.ops[0].param2="false"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotStrStarts"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="a d"
        transform_obj.ops[0].param2="false"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfStrEnds"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="Dog"
        transform_obj.ops[0].param2="true"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotStrEnds"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="Dog"
        transform_obj.ops[0].param2="true"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfStrEnds"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="dog"
        transform_obj.ops[0].param2="false"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotStrEnds"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="dog"
        transform_obj.ops[0].param2="false"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="IfStrContains"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=" d"
        transform_obj.ops[0].param2="false"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotStrContains"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=" d"
        transform_obj.ops[0].param2="false"
        initial_value= "a Dog"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",ref=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfInt"
        print("----" + func + "----")
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "-12"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfInt"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "-12.2"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfInt"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="positive"
        initial_value= "-12"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotInt"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="positive"
        initial_value= "-12"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotInt"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="negative"
        initial_value= "-12"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfReal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "12"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfReal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "12.2"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfReal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="positive"
        initial_value= "-12.2"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotReal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="positive"
        initial_value= "-12.2"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotReal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="negative"
        initial_value= "-12"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotReal"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="negative"
        initial_value= "-12.2"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfIsoDate"
        print("----" + func + "----")
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "12.2"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "2024"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "202407"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "20240711"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "20240711T"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "20240711T103000"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "20240011"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "20240751"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotIsoDate"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=""
        initial_value= "20240751"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfDateFormat"
        print("----" + func + "----")
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="mmddyyyy"
        initial_value= "04/18/2024"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="ddmmyyyy"
        initial_value= "04/18/2024"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="mmddyyyy"
        initial_value= "04182024"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="mmddyyyy"
        initial_value= "4182024"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="mddyyyy"
        initial_value= "4182024"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="mddyyyy"
        initial_value= "4382024"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="mmddyyyy"
        initial_value= "14082024"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="mmddyyyy"
        initial_value= "20240408"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="yyyymmdd"
        initial_value= "20240408"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="yyyymmdd"
        initial_value= "20240408"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="yymmdd"
        initial_value= "20240408"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="yymmdd"
        initial_value= "20240408"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="yymmdd"
        initial_value= "240408"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="yymmdd"
        initial_value= "240408"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfDateFormat"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="yymmdd"
        initial_value= "241408"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)


        func="IfMatch"
        print("----" + func + "----")
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="tech*"
        initial_value= "Technik Interlytics"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfMatch"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=" Inter"
        initial_value= "Technik Interlytics"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfNotMatch"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=" Inter"
        initial_value= "Technik Interlytics"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfMatch"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1=" Inter*"
        initial_value= "Technik Interlytics"
        result_datatype= ""
        expval= "false"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

        func="IfMatch"
        transform_obj.ops[0].title=func
        transform_obj.ops[0].param1="* Inter*"
        initial_value= "Technik Interlytics"
        result_datatype= ""
        expval= "true"
        actval= exectransform.do_transform(transform_obj, initial_value, result_datatype,
            hash_fields, field_values,lookup_dicts, hash_lookup_dicts)
        if ":" in actval:
            actval=actval[:actval.find(":")]
        if expval==actval:
            status="OK"
        else:
            status="FAIL"
        print("initial=" + initial_value + ",func=" + func + ",parma1=" + transform_obj.ops[0].param1
              + ", Result [" + expval + "]=" + actval + " -->" + status)

    except (RuntimeError, OSError, ValueError) as err:
        print("ERROR: " + str(err))


if __name__ == '__main__':
    do_test_transforms_conditional()
